package org.apache.commons.codec.net;

abstract interface StringEncodings
{
  public static final String US_ASCII = "US-ASCII";
  public static final String UTF8 = "UTF-8";
}