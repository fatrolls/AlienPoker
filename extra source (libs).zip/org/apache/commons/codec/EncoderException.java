package org.apache.commons.codec;

public class EncoderException extends Exception
{
  public EncoderException(String pMessage)
  {
    super(pMessage);
  }
}