package org.apache.commons.codec;

public class DecoderException extends Exception
{
  public DecoderException(String pMessage)
  {
    super(pMessage);
  }
}