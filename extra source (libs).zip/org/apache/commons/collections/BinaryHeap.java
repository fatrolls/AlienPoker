package org.apache.commons.collections;

import java.util.AbstractCollection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/** @deprecated */
public final class BinaryHeap extends AbstractCollection
  implements PriorityQueue, Buffer
{
  private static final int DEFAULT_CAPACITY = 13;
  int m_size;
  Object[] m_elements;
  boolean m_isMinHeap;
  Comparator m_comparator;

  public BinaryHeap()
  {
    this(13, true);
  }

  public BinaryHeap(Comparator comparator)
  {
    this();
    m_comparator = comparator;
  }

  public BinaryHeap(int capacity)
  {
    this(capacity, true);
  }

  public BinaryHeap(int capacity, Comparator comparator)
  {
    this(capacity);
    m_comparator = comparator;
  }

  public BinaryHeap(boolean isMinHeap)
  {
    this(13, isMinHeap);
  }

  public BinaryHeap(boolean isMinHeap, Comparator comparator)
  {
    this(isMinHeap);
    m_comparator = comparator;
  }

  public BinaryHeap(int capacity, boolean isMinHeap)
  {
    if (capacity <= 0) {
      throw new IllegalArgumentException("invalid capacity");
    }
    m_isMinHeap = isMinHeap;

    m_elements = new Object[capacity + 1];
  }

  public BinaryHeap(int capacity, boolean isMinHeap, Comparator comparator)
  {
    this(capacity, isMinHeap);
    m_comparator = comparator;
  }

  public void clear()
  {
    m_elements = new Object[m_elements.length];
    m_size = 0;
  }

  public boolean isEmpty()
  {
    return m_size == 0;
  }

  public boolean isFull()
  {
    return m_elements.length == m_size + 1;
  }

  public void insert(Object element)
  {
    if (isFull()) {
      grow();
    }

    if (m_isMinHeap)
      percolateUpMinHeap(element);
    else
      percolateUpMaxHeap(element);
  }

  public Object peek()
    throws NoSuchElementException
  {
    if (isEmpty()) {
      throw new NoSuchElementException();
    }
    return m_elements[1];
  }

  public Object pop()
    throws NoSuchElementException
  {
    Object result = peek();
    m_elements[1] = m_elements[(m_size--)];

    m_elements[(m_size + 1)] = null;

    if (m_size != 0)
    {
      if (m_isMinHeap)
        percolateDownMinHeap(1);
      else {
        percolateDownMaxHeap(1);
      }
    }

    return result;
  }

  protected void percolateDownMinHeap(int index)
  {
    Object element = m_elements[index];
    int hole = index;

    while (hole * 2 <= m_size) {
      int child = hole * 2;

      if ((child != m_size) && (compare(m_elements[(child + 1)], m_elements[child]) < 0)) {
        child++;
      }

      if (compare(m_elements[child], element) >= 0)
      {
        break;
      }
      m_elements[hole] = m_elements[child];
      hole = child;
    }

    m_elements[hole] = element;
  }

  protected void percolateDownMaxHeap(int index)
  {
    Object element = m_elements[index];
    int hole = index;

    while (hole * 2 <= m_size) {
      int child = hole * 2;

      if ((child != m_size) && (compare(m_elements[(child + 1)], m_elements[child]) > 0)) {
        child++;
      }

      if (compare(m_elements[child], element) <= 0)
      {
        break;
      }
      m_elements[hole] = m_elements[child];
      hole = child;
    }

    m_elements[hole] = element;
  }

  protected void percolateUpMinHeap(int index)
  {
    int hole = index;
    Object element = m_elements[hole];
    while ((hole > 1) && (compare(element, m_elements[(hole / 2)]) < 0))
    {
      int next = hole / 2;
      m_elements[hole] = m_elements[next];
      hole = next;
    }
    m_elements[hole] = element;
  }

  protected void percolateUpMinHeap(Object element)
  {
    m_elements[(++m_size)] = element;
    percolateUpMinHeap(m_size);
  }

  protected void percolateUpMaxHeap(int index)
  {
    int hole = index;
    Object element = m_elements[hole];

    while ((hole > 1) && (compare(element, m_elements[(hole / 2)]) > 0))
    {
      int next = hole / 2;
      m_elements[hole] = m_elements[next];
      hole = next;
    }

    m_elements[hole] = element;
  }

  protected void percolateUpMaxHeap(Object element)
  {
    m_elements[(++m_size)] = element;
    percolateUpMaxHeap(m_size);
  }

  private int compare(Object a, Object b)
  {
    if (m_comparator != null) {
      return m_comparator.compare(a, b);
    }
    return ((Comparable)a).compareTo(b);
  }

  protected void grow()
  {
    Object[] elements = new Object[m_elements.length * 2];
    System.arraycopy(m_elements, 0, elements, 0, m_elements.length);
    m_elements = elements;
  }

  public String toString()
  {
    StringBuffer sb = new StringBuffer();

    sb.append("[ ");

    for (int i = 1; i < m_size + 1; i++) {
      if (i != 1) {
        sb.append(", ");
      }
      sb.append(m_elements[i]);
    }

    sb.append(" ]");

    return sb.toString();
  }

  public Iterator iterator()
  {
    return new Iterator()
    {
      private int index = 1;
      private int lastReturnedIndex = -1;

      public boolean hasNext() {
        return index <= m_size;
      }

      public Object next() {
        if (!hasNext()) throw new NoSuchElementException();
        lastReturnedIndex = index;
        index += 1;
        return m_elements[lastReturnedIndex];
      }

      public void remove() {
        if (lastReturnedIndex == -1) {
          throw new IllegalStateException();
        }
        m_elements[lastReturnedIndex] = m_elements[m_size];
        m_elements[m_size] = null;
        m_size -= 1;
        if ((m_size != 0) && (lastReturnedIndex <= m_size)) {
          int compareToParent = 0;
          if (lastReturnedIndex > 1) {
            compareToParent = BinaryHeap.this.compare(m_elements[lastReturnedIndex], m_elements[(lastReturnedIndex / 2)]);
          }

          if (m_isMinHeap) {
            if ((lastReturnedIndex > 1) && (compareToParent < 0))
              percolateUpMinHeap(lastReturnedIndex);
            else {
              percolateDownMinHeap(lastReturnedIndex);
            }
          }
          else if ((lastReturnedIndex > 1) && (compareToParent > 0))
            percolateUpMaxHeap(lastReturnedIndex);
          else {
            percolateDownMaxHeap(lastReturnedIndex);
          }
        }

        index -= 1;
        lastReturnedIndex = -1;
      }
    };
  }

  public boolean add(Object object)
  {
    insert(object);
    return true;
  }

  public Object get()
  {
    try
    {
      return peek(); } catch (NoSuchElementException e) {
    }
    throw new BufferUnderflowException();
  }

  public Object remove()
  {
    try
    {
      return pop(); } catch (NoSuchElementException e) {
    }
    throw new BufferUnderflowException();
  }

  public int size()
  {
    return m_size;
  }
}