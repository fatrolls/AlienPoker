package org.apache.commons.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.collections.set.UnmodifiableSet;

/** @deprecated */
public abstract class DefaultMapBag
  implements Bag
{
  private Map _map = null;
  private int _total = 0;
  private int _mods = 0;

  public DefaultMapBag()
  {
  }

  protected DefaultMapBag(Map map)
  {
    setMap(map);
  }

  public boolean add(Object object)
  {
    return add(object, 1);
  }

  public boolean add(Object object, int nCopies)
  {
    _mods += 1;
    if (nCopies > 0) {
      int count = nCopies + getCount(object);
      _map.put(object, new Integer(count));
      _total += nCopies;
      return count == nCopies;
    }
    return false;
  }

  public boolean addAll(Collection coll)
  {
    boolean changed = false;
    Iterator i = coll.iterator();
    while (i.hasNext()) {
      boolean added = add(i.next());
      changed = (changed) || (added);
    }
    return changed;
  }

  public void clear()
  {
    _mods += 1;
    _map.clear();
    _total = 0;
  }

  public boolean contains(Object object)
  {
    return _map.containsKey(object);
  }

  public boolean containsAll(Collection coll)
  {
    return containsAll(new HashBag(coll));
  }

  public boolean containsAll(Bag other)
  {
    boolean result = true;
    Iterator i = other.uniqueSet().iterator();
    while (i.hasNext()) {
      Object current = i.next();
      boolean contains = getCount(current) >= other.getCount(current);
      result = (result) && (contains);
    }
    return result;
  }

  public boolean equals(Object object)
  {
    if (object == this) {
      return true;
    }
    if (!(object instanceof Bag)) {
      return false;
    }
    Bag other = (Bag)object;
    if (other.size() != size()) {
      return false;
    }
    for (Iterator it = _map.keySet().iterator(); it.hasNext(); ) {
      Object element = it.next();
      if (other.getCount(element) != getCount(element)) {
        return false;
      }
    }
    return true;
  }

  public int hashCode()
  {
    return _map.hashCode();
  }

  public boolean isEmpty()
  {
    return _map.isEmpty();
  }

  public Iterator iterator() {
    return new BagIterator(this, extractList().iterator());
  }

  public boolean remove(Object object)
  {
    return remove(object, getCount(object));
  }

  public boolean remove(Object object, int nCopies) {
    _mods += 1;
    boolean result = false;
    int count = getCount(object);
    if (nCopies <= 0) {
      result = false;
    } else if (count > nCopies) {
      _map.put(object, new Integer(count - nCopies));
      result = true;
      _total -= nCopies;
    }
    else {
      result = _map.remove(object) != null;
      _total -= count;
    }
    return result;
  }

  public boolean removeAll(Collection coll) {
    boolean result = false;
    if (coll != null) {
      Iterator i = coll.iterator();
      while (i.hasNext()) {
        boolean changed = remove(i.next(), 1);
        result = (result) || (changed);
      }
    }
    return result;
  }

  public boolean retainAll(Collection coll)
  {
    return retainAll(new HashBag(coll));
  }

  public boolean retainAll(Bag other)
  {
    boolean result = false;
    Bag excess = new HashBag();
    Iterator i = uniqueSet().iterator();
    while (i.hasNext()) {
      Object current = i.next();
      int myCount = getCount(current);
      int otherCount = other.getCount(current);
      if ((1 <= otherCount) && (otherCount <= myCount))
        excess.add(current, myCount - otherCount);
      else {
        excess.add(current, myCount);
      }
    }
    if (!excess.isEmpty()) {
      result = removeAll(excess);
    }
    return result;
  }

  public Object[] toArray()
  {
    return extractList().toArray();
  }

  public Object[] toArray(Object[] array)
  {
    return extractList().toArray(array);
  }

  public int getCount(Object object)
  {
    int result = 0;
    Integer count = MapUtils.getInteger(_map, object);
    if (count != null) {
      result = count.intValue();
    }
    return result;
  }

  public Set uniqueSet()
  {
    return UnmodifiableSet.decorate(_map.keySet());
  }

  public int size()
  {
    return _total;
  }

  protected int calcTotalSize()
  {
    _total = extractList().size();
    return _total;
  }

  protected void setMap(Map map)
  {
    if ((map == null) || (!map.isEmpty())) {
      throw new IllegalArgumentException("The map must be non-null and empty");
    }
    _map = map;
  }

  protected Map getMap()
  {
    return _map;
  }

  private List extractList()
  {
    List result = new ArrayList();
    Iterator i = uniqueSet().iterator();
    while (i.hasNext()) {
      Object current = i.next();
      for (int index = getCount(current); index > 0; index--) {
        result.add(current);
      }
    }
    return result;
  }

  private int modCount()
  {
    return _mods;
  }

  public String toString()
  {
    StringBuffer buf = new StringBuffer();
    buf.append("[");
    Iterator i = uniqueSet().iterator();
    while (i.hasNext()) {
      Object current = i.next();
      int count = getCount(current);
      buf.append(count);
      buf.append(":");
      buf.append(current);
      if (i.hasNext()) {
        buf.append(",");
      }
    }
    buf.append("]");
    return buf.toString();
  }

  static class BagIterator
    implements Iterator
  {
    private DefaultMapBag _parent = null;
    private Iterator _support = null;
    private Object _current = null;
    private int _mods = 0;

    public BagIterator(DefaultMapBag parent, Iterator support) {
      _parent = parent;
      _support = support;
      _current = null;
      _mods = parent.modCount();
    }

    public boolean hasNext() {
      return _support.hasNext();
    }

    public Object next() {
      if (_parent.modCount() != _mods) {
        throw new ConcurrentModificationException();
      }
      _current = _support.next();
      return _current;
    }

    public void remove() {
      if (_parent.modCount() != _mods) {
        throw new ConcurrentModificationException();
      }
      _support.remove();
      _parent.remove(_current, 1);
      _mods += 1;
    }
  }
}