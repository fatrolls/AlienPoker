package org.apache.commons.collections;

public class BufferOverflowException extends RuntimeException
{
  private final Throwable throwable;

  public BufferOverflowException()
  {
    throwable = null;
  }

  public BufferOverflowException(String message)
  {
    this(message, null);
  }

  public BufferOverflowException(String message, Throwable exception)
  {
    super(message);
    throwable = exception;
  }

  public final Throwable getCause()
  {
    return throwable;
  }
}