package org.apache.commons.collections;

class DoubleOrderedMap$4 extends DoubleOrderedMap.DoubleOrderedMapIterator
{
  private final DoubleOrderedMap.3 this$1;

  protected Object doGetNext()
  {
    return DoubleOrderedMap.Node.access$200(lastReturnedNode, 0);
  }
}