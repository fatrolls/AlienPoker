package org.apache.commons.collections;

import java.util.AbstractCollection;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

/** @deprecated */
public class BoundedFifoBuffer extends AbstractCollection
  implements Buffer, BoundedCollection
{
  private final Object[] m_elements;
  private int m_start = 0;
  private int m_end = 0;
  private boolean m_full = false;
  private final int maxElements;

  public BoundedFifoBuffer()
  {
    this(32);
  }

  public BoundedFifoBuffer(int size)
  {
    if (size <= 0) {
      throw new IllegalArgumentException("The size must be greater than 0");
    }
    m_elements = new Object[size];
    maxElements = m_elements.length;
  }

  public BoundedFifoBuffer(Collection coll)
  {
    this(coll.size());
    addAll(coll);
  }

  public int size()
  {
    int size = 0;

    if (m_end < m_start)
      size = maxElements - m_start + m_end;
    else if (m_end == m_start)
      size = m_full ? maxElements : 0;
    else {
      size = m_end - m_start;
    }

    return size;
  }

  public boolean isEmpty()
  {
    return size() == 0;
  }

  public boolean isFull()
  {
    return size() == maxElements;
  }

  public int maxSize()
  {
    return maxElements;
  }

  public void clear()
  {
    m_full = false;
    m_start = 0;
    m_end = 0;
    Arrays.fill(m_elements, null);
  }

  public boolean add(Object element)
  {
    if (null == element) {
      throw new NullPointerException("Attempted to add null object to buffer");
    }

    if (m_full) {
      throw new BufferOverflowException("The buffer cannot hold more than " + maxElements + " objects.");
    }

    m_elements[(m_end++)] = element;

    if (m_end >= maxElements) {
      m_end = 0;
    }

    if (m_end == m_start) {
      m_full = true;
    }

    return true;
  }

  public Object get()
  {
    if (isEmpty()) {
      throw new BufferUnderflowException("The buffer is already empty");
    }

    return m_elements[m_start];
  }

  public Object remove()
  {
    if (isEmpty()) {
      throw new BufferUnderflowException("The buffer is already empty");
    }

    Object element = m_elements[m_start];

    if (null != element) {
      m_elements[(m_start++)] = null;

      if (m_start >= maxElements) {
        m_start = 0;
      }

      m_full = false;
    }

    return element;
  }

  private int increment(int index)
  {
    index++;
    if (index >= maxElements) {
      index = 0;
    }
    return index;
  }

  private int decrement(int index)
  {
    index--;
    if (index < 0) {
      index = maxElements - 1;
    }
    return index;
  }

  public Iterator iterator()
  {
    return new Iterator()
    {
      private int index = m_start;
      private int lastReturnedIndex = -1;
      private boolean isFirst = m_full;

      public boolean hasNext() {
        return (isFirst) || (index != m_end);
      }

      public Object next()
      {
        if (!hasNext()) throw new NoSuchElementException();
        isFirst = false;
        lastReturnedIndex = index;
        index = BoundedFifoBuffer.this.increment(index);
        return m_elements[lastReturnedIndex];
      }

      public void remove() {
        if (lastReturnedIndex == -1) throw new IllegalStateException();

        if (lastReturnedIndex == m_start) {
          remove();
          lastReturnedIndex = -1;
          return;
        }

        int i = lastReturnedIndex + 1;
        while (i != m_end) {
          if (i >= maxElements) {
            m_elements[(i - 1)] = BoundedFifoBuffer.access$400(BoundedFifoBuffer.this)[0];
            i = 0;
          } else {
            m_elements[(i - 1)] = BoundedFifoBuffer.access$400(BoundedFifoBuffer.this)[i];
            i++;
          }
        }

        lastReturnedIndex = -1;
        BoundedFifoBuffer.access$202(BoundedFifoBuffer.this, BoundedFifoBuffer.this.decrement(m_end));
        m_elements[m_end] = null;
        BoundedFifoBuffer.access$102(BoundedFifoBuffer.this, false);
        index = BoundedFifoBuffer.this.decrement(index);
      }
    };
  }
}