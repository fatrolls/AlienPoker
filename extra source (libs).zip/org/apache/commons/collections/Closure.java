package org.apache.commons.collections;

public abstract interface Closure
{
  public abstract void execute(Object paramObject);
}