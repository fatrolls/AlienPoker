package org.apache.commons.collections.bag;

import java.util.Comparator;
import org.apache.commons.collections.SortedBag;
import org.apache.commons.collections.collection.AbstractCollectionDecorator;

public abstract class AbstractSortedBagDecorator extends AbstractBagDecorator
  implements SortedBag
{
  protected AbstractSortedBagDecorator()
  {
  }

  protected AbstractSortedBagDecorator(SortedBag bag)
  {
    super(bag);
  }

  protected SortedBag getSortedBag()
  {
    return (SortedBag)getCollection();
  }

  public Object first()
  {
    return getSortedBag().first();
  }

  public Object last() {
    return getSortedBag().last();
  }

  public Comparator comparator() {
    return getSortedBag().comparator();
  }
}