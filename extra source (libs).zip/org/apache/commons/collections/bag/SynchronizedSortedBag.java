package org.apache.commons.collections.bag;

import java.util.Comparator;
import org.apache.commons.collections.Bag;
import org.apache.commons.collections.SortedBag;
import org.apache.commons.collections.collection.SynchronizedCollection;

public class SynchronizedSortedBag extends SynchronizedBag
  implements SortedBag
{
  private static final long serialVersionUID = 722374056718497858L;

  public static SortedBag decorate(SortedBag bag)
  {
    return new SynchronizedSortedBag(bag);
  }

  protected SynchronizedSortedBag(SortedBag bag)
  {
    super(bag);
  }

  protected SynchronizedSortedBag(Bag bag, Object lock)
  {
    super(bag, lock);
  }

  protected SortedBag getSortedBag()
  {
    return (SortedBag)collection;
  }

  public synchronized Object first()
  {
    synchronized (lock) {
      return getSortedBag().first();
    }
  }

  public synchronized Object last() {
    synchronized (lock) {
      return getSortedBag().last();
    }
  }

  public synchronized Comparator comparator() {
    synchronized (lock) {
      return getSortedBag().comparator();
    }
  }
}