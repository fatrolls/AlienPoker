package org.apache.commons.collections.bag;

import java.util.Comparator;
import org.apache.commons.collections.SortedBag;
import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.collection.AbstractCollectionDecorator;

public class TransformedSortedBag extends TransformedBag
  implements SortedBag
{
  private static final long serialVersionUID = -251737742649401930L;

  public static SortedBag decorate(SortedBag bag, Transformer transformer)
  {
    return new TransformedSortedBag(bag, transformer);
  }

  protected TransformedSortedBag(SortedBag bag, Transformer transformer)
  {
    super(bag, transformer);
  }

  protected SortedBag getSortedBag()
  {
    return (SortedBag)collection;
  }

  public Object first()
  {
    return getSortedBag().first();
  }

  public Object last() {
    return getSortedBag().last();
  }

  public Comparator comparator() {
    return getSortedBag().comparator();
  }
}