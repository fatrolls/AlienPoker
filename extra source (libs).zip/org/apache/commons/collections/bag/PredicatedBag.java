package org.apache.commons.collections.bag;

import java.util.Set;
import org.apache.commons.collections.Bag;
import org.apache.commons.collections.Predicate;
import org.apache.commons.collections.collection.AbstractCollectionDecorator;
import org.apache.commons.collections.collection.PredicatedCollection;

public class PredicatedBag extends PredicatedCollection
  implements Bag
{
  private static final long serialVersionUID = -2575833140344736876L;

  public static Bag decorate(Bag bag, Predicate predicate)
  {
    return new PredicatedBag(bag, predicate);
  }

  protected PredicatedBag(Bag bag, Predicate predicate)
  {
    super(bag, predicate);
  }

  protected Bag getBag()
  {
    return (Bag)getCollection();
  }

  public boolean add(Object object, int count)
  {
    validate(object);
    return getBag().add(object, count);
  }

  public boolean remove(Object object, int count) {
    return getBag().remove(object, count);
  }

  public Set uniqueSet() {
    return getBag().uniqueSet();
  }

  public int getCount(Object object) {
    return getBag().getCount(object);
  }
}