package org.apache.commons.collections;

import java.util.AbstractCollection;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Set;

/** @deprecated */
public final class DoubleOrderedMap extends AbstractMap
{
  private static final int KEY = 0;
  private static final int VALUE = 1;
  private static final int SUM_OF_INDICES = 1;
  private static final int FIRST_INDEX = 0;
  private static final int NUMBER_OF_INDICES = 2;
  private static final String[] dataName = { "key", "value" };

  private Node[] rootNode = { null, null };
  private int nodeCount = 0;
  private int modifications = 0;
  private Set[] setOfKeys = { null, null };
  private Set[] setOfEntries = { null, null };
  private Collection[] collectionOfValues = { null, null };

  public DoubleOrderedMap()
  {
  }

  public DoubleOrderedMap(Map map)
    throws ClassCastException, NullPointerException, IllegalArgumentException
  {
    putAll(map);
  }

  public Object getKeyForValue(Object value)
    throws ClassCastException, NullPointerException
  {
    return doGet((Comparable)value, 1);
  }

  public Object removeValue(Object value)
  {
    return doRemove((Comparable)value, 1);
  }

  public Set entrySetByValue()
  {
    if (setOfEntries[1] == null) {
      setOfEntries[1] = new AbstractSet()
      {
        public Iterator iterator()
        {
          return new DoubleOrderedMap.2(this, 1);
        }

        public boolean contains(Object o)
        {
          if (!(o instanceof Map.Entry)) {
            return false;
          }

          Map.Entry entry = (Map.Entry)o;
          Object key = entry.getKey();
          DoubleOrderedMap.Node node = DoubleOrderedMap.this.lookup((Comparable)entry.getValue(), 1);

          return (node != null) && (node.getData(0).equals(key));
        }

        public boolean remove(Object o)
        {
          if (!(o instanceof Map.Entry)) {
            return false;
          }

          Map.Entry entry = (Map.Entry)o;
          Object key = entry.getKey();
          DoubleOrderedMap.Node node = DoubleOrderedMap.this.lookup((Comparable)entry.getValue(), 1);

          if ((node != null) && (node.getData(0).equals(key))) {
            DoubleOrderedMap.this.doRedBlackDelete(node);

            return true;
          }

          return false;
        }

        public int size() {
          return DoubleOrderedMap.this.size();
        }

        public void clear() {
          DoubleOrderedMap.this.clear();
        }
      };
    }
    return setOfEntries[1];
  }

  public Set keySetByValue()
  {
    if (setOfKeys[1] == null) {
      setOfKeys[1] = new AbstractSet()
      {
        public Iterator iterator()
        {
          return new DoubleOrderedMap.4(this, 1);
        }

        public int size()
        {
          return DoubleOrderedMap.this.size();
        }

        public boolean contains(Object o) {
          return containsKey(o);
        }

        public boolean remove(Object o)
        {
          int oldnodeCount = nodeCount;

          remove(o);

          return nodeCount != oldnodeCount;
        }

        public void clear() {
          DoubleOrderedMap.this.clear();
        }
      };
    }
    return setOfKeys[1];
  }

  public Collection valuesByValue()
  {
    if (collectionOfValues[1] == null) {
      collectionOfValues[1] = new AbstractCollection()
      {
        public Iterator iterator()
        {
          return new DoubleOrderedMap.6(this, 1);
        }

        public int size()
        {
          return DoubleOrderedMap.this.size();
        }

        public boolean contains(Object o) {
          return containsValue(o);
        }

        public boolean remove(Object o)
        {
          int oldnodeCount = nodeCount;

          removeValue(o);

          return nodeCount != oldnodeCount;
        }

        public boolean removeAll(Collection c)
        {
          boolean modified = false;
          Iterator iter = c.iterator();

          while (iter.hasNext()) {
            if (removeValue(iter.next()) != null) {
              modified = true;
            }
          }

          return modified;
        }

        public void clear() {
          DoubleOrderedMap.this.clear();
        }
      };
    }
    return collectionOfValues[1];
  }

  private Object doRemove(Comparable o, int index)
  {
    Node node = lookup(o, index);
    Object rval = null;

    if (node != null) {
      rval = node.getData(oppositeIndex(index));

      doRedBlackDelete(node);
    }

    return rval;
  }

  private Object doGet(Comparable o, int index)
  {
    checkNonNullComparable(o, index);

    Node node = lookup(o, index);

    return node == null ? null : node.getData(oppositeIndex(index));
  }

  private int oppositeIndex(int index)
  {
    return 1 - index;
  }

  private Node lookup(Comparable data, int index)
  {
    Node rval = null;
    Node node = rootNode[index];

    while (node != null) {
      int cmp = compare(data, node.getData(index));

      if (cmp == 0) {
        rval = node;

        break;
      }
      node = cmp < 0 ? node.getLeft(index) : node.getRight(index);
    }

    return rval;
  }

  private static int compare(Comparable o1, Comparable o2)
  {
    return o1.compareTo(o2);
  }

  private static Node leastNode(Node node, int index)
  {
    Node rval = node;

    if (rval != null) {
      while (rval.getLeft(index) != null) {
        rval = rval.getLeft(index);
      }
    }

    return rval;
  }

  private Node nextGreater(Node node, int index)
  {
    Node rval = null;

    if (node == null) {
      rval = null;
    } else if (node.getRight(index) != null)
    {
      rval = leastNode(node.getRight(index), index);
    }
    else
    {
      Node parent = node.getParent(index);
      Node child = node;

      while ((parent != null) && (child == parent.getRight(index))) {
        child = parent;
        parent = parent.getParent(index);
      }

      rval = parent;
    }

    return rval;
  }

  private static void copyColor(Node from, Node to, int index)
  {
    if (to != null)
      if (from == null)
      {
        to.setBlack(index);
      }
      else to.copyColor(from, index);
  }

  private static boolean isRed(Node node, int index)
  {
    return node == null ? false : node.isRed(index);
  }

  private static boolean isBlack(Node node, int index)
  {
    return node == null ? true : node.isBlack(index);
  }

  private static void makeRed(Node node, int index)
  {
    if (node != null)
      node.setRed(index);
  }

  private static void makeBlack(Node node, int index)
  {
    if (node != null)
      node.setBlack(index);
  }

  private static Node getGrandParent(Node node, int index)
  {
    return getParent(getParent(node, index), index);
  }

  private static Node getParent(Node node, int index)
  {
    return node == null ? null : node.getParent(index);
  }

  private static Node getRightChild(Node node, int index)
  {
    return node == null ? null : node.getRight(index);
  }

  private static Node getLeftChild(Node node, int index)
  {
    return node == null ? null : node.getLeft(index);
  }

  private static boolean isLeftChild(Node node, int index)
  {
    return node == null;
  }

  private static boolean isRightChild(Node node, int index)
  {
    return node == null;
  }

  private void rotateLeft(Node node, int index)
  {
    Node rightChild = node.getRight(index);

    node.setRight(Node.access$700(rightChild, index), index);

    if (rightChild.getLeft(index) != null) {
      Node.access$700(rightChild, index).setParent(node, index);
    }

    rightChild.setParent(Node.access$900(node, index), index);

    if (node.getParent(index) == null)
    {
      rootNode[index] = rightChild;
    } else if (Node.access$900(node, index).getLeft(index) == node)
      Node.access$900(node, index).setLeft(rightChild, index);
    else {
      Node.access$900(node, index).setRight(rightChild, index);
    }

    rightChild.setLeft(node, index);
    node.setParent(rightChild, index);
  }

  private void rotateRight(Node node, int index)
  {
    Node leftChild = node.getLeft(index);

    node.setLeft(Node.access$800(leftChild, index), index);

    if (leftChild.getRight(index) != null) {
      Node.access$800(leftChild, index).setParent(node, index);
    }

    leftChild.setParent(Node.access$900(node, index), index);

    if (node.getParent(index) == null)
    {
      rootNode[index] = leftChild;
    } else if (Node.access$900(node, index).getRight(index) == node)
      Node.access$900(node, index).setRight(leftChild, index);
    else {
      Node.access$900(node, index).setLeft(leftChild, index);
    }

    leftChild.setRight(node, index);
    node.setParent(leftChild, index);
  }

  private void doRedBlackInsert(Node insertedNode, int index)
  {
    Node currentNode = insertedNode;

    makeRed(currentNode, index);

    while ((currentNode != null) && (currentNode != rootNode[index]) && (isRed(currentNode.getParent(index), index))) {
      if (isLeftChild(getParent(currentNode, index), index)) {
        Node y = getRightChild(getGrandParent(currentNode, index), index);

        if (isRed(y, index)) {
          makeBlack(getParent(currentNode, index), index);
          makeBlack(y, index);
          makeRed(getGrandParent(currentNode, index), index);

          currentNode = getGrandParent(currentNode, index);
        } else {
          if (isRightChild(currentNode, index)) {
            currentNode = getParent(currentNode, index);

            rotateLeft(currentNode, index);
          }

          makeBlack(getParent(currentNode, index), index);
          makeRed(getGrandParent(currentNode, index), index);

          if (getGrandParent(currentNode, index) != null) {
            rotateRight(getGrandParent(currentNode, index), index);
          }
        }

      }
      else
      {
        Node y = getLeftChild(getGrandParent(currentNode, index), index);

        if (isRed(y, index)) {
          makeBlack(getParent(currentNode, index), index);
          makeBlack(y, index);
          makeRed(getGrandParent(currentNode, index), index);

          currentNode = getGrandParent(currentNode, index);
        } else {
          if (isLeftChild(currentNode, index)) {
            currentNode = getParent(currentNode, index);

            rotateRight(currentNode, index);
          }

          makeBlack(getParent(currentNode, index), index);
          makeRed(getGrandParent(currentNode, index), index);

          if (getGrandParent(currentNode, index) != null) {
            rotateLeft(getGrandParent(currentNode, index), index);
          }
        }
      }
    }

    makeBlack(rootNode[index], index);
  }

  private void doRedBlackDelete(Node deletedNode)
  {
    for (int index = 0; index < 2; index++)
    {
      if ((deletedNode.getLeft(index) != null) && (deletedNode.getRight(index) != null))
      {
        swapPosition(nextGreater(deletedNode, index), deletedNode, index);
      }

      Node replacement = deletedNode.getLeft(index) != null ? deletedNode.getLeft(index) : deletedNode.getRight(index);

      if (replacement != null) {
        replacement.setParent(Node.access$900(deletedNode, index), index);

        if (deletedNode.getParent(index) == null)
          rootNode[index] = replacement;
        else if (deletedNode == Node.access$900(deletedNode, index).getLeft(index))
        {
          Node.access$900(deletedNode, index).setLeft(replacement, index);
        }
        else Node.access$900(deletedNode, index).setRight(replacement, index);

        deletedNode.setLeft(null, index);
        deletedNode.setRight(null, index);
        deletedNode.setParent(null, index);

        if (isBlack(deletedNode, index)) {
          doRedBlackDeleteFixup(replacement, index);
        }

      }
      else if (deletedNode.getParent(index) == null)
      {
        rootNode[index] = null;
      }
      else
      {
        if (isBlack(deletedNode, index)) {
          doRedBlackDeleteFixup(deletedNode, index);
        }

        if (deletedNode.getParent(index) != null) {
          if (deletedNode == Node.access$900(deletedNode, index).getLeft(index))
          {
            Node.access$900(deletedNode, index).setLeft(null, index);
          }
          else Node.access$900(deletedNode, index).setRight(null, index);

          deletedNode.setParent(null, index);
        }
      }

    }

    shrink();
  }

  private void doRedBlackDeleteFixup(Node replacementNode, int index)
  {
    Node currentNode = replacementNode;

    while ((currentNode != rootNode[index]) && (isBlack(currentNode, index))) {
      if (isLeftChild(currentNode, index)) {
        Node siblingNode = getRightChild(getParent(currentNode, index), index);

        if (isRed(siblingNode, index)) {
          makeBlack(siblingNode, index);
          makeRed(getParent(currentNode, index), index);
          rotateLeft(getParent(currentNode, index), index);

          siblingNode = getRightChild(getParent(currentNode, index), index);
        }

        if ((isBlack(getLeftChild(siblingNode, index), index)) && (isBlack(getRightChild(siblingNode, index), index)))
        {
          makeRed(siblingNode, index);

          currentNode = getParent(currentNode, index);
        } else {
          if (isBlack(getRightChild(siblingNode, index), index)) {
            makeBlack(getLeftChild(siblingNode, index), index);
            makeRed(siblingNode, index);
            rotateRight(siblingNode, index);

            siblingNode = getRightChild(getParent(currentNode, index), index);
          }

          copyColor(getParent(currentNode, index), siblingNode, index);

          makeBlack(getParent(currentNode, index), index);
          makeBlack(getRightChild(siblingNode, index), index);
          rotateLeft(getParent(currentNode, index), index);

          currentNode = rootNode[index];
        }
      } else {
        Node siblingNode = getLeftChild(getParent(currentNode, index), index);

        if (isRed(siblingNode, index)) {
          makeBlack(siblingNode, index);
          makeRed(getParent(currentNode, index), index);
          rotateRight(getParent(currentNode, index), index);

          siblingNode = getLeftChild(getParent(currentNode, index), index);
        }

        if ((isBlack(getRightChild(siblingNode, index), index)) && (isBlack(getLeftChild(siblingNode, index), index)))
        {
          makeRed(siblingNode, index);

          currentNode = getParent(currentNode, index);
        } else {
          if (isBlack(getLeftChild(siblingNode, index), index)) {
            makeBlack(getRightChild(siblingNode, index), index);
            makeRed(siblingNode, index);
            rotateLeft(siblingNode, index);

            siblingNode = getLeftChild(getParent(currentNode, index), index);
          }

          copyColor(getParent(currentNode, index), siblingNode, index);

          makeBlack(getParent(currentNode, index), index);
          makeBlack(getLeftChild(siblingNode, index), index);
          rotateRight(getParent(currentNode, index), index);

          currentNode = rootNode[index];
        }
      }
    }

    makeBlack(currentNode, index);
  }

  private void swapPosition(Node x, Node y, int index)
  {
    Node xFormerParent = x.getParent(index);
    Node xFormerLeftChild = x.getLeft(index);
    Node xFormerRightChild = x.getRight(index);
    Node yFormerParent = y.getParent(index);
    Node yFormerLeftChild = y.getLeft(index);
    Node yFormerRightChild = y.getRight(index);
    boolean xWasLeftChild = (x.getParent(index) != null) && (x == Node.access$900(x, index).getLeft(index));

    boolean yWasLeftChild = (y.getParent(index) != null) && (y == Node.access$900(y, index).getLeft(index));

    if (x == yFormerParent) {
      x.setParent(y, index);

      if (yWasLeftChild) {
        y.setLeft(x, index);
        y.setRight(xFormerRightChild, index);
      } else {
        y.setRight(x, index);
        y.setLeft(xFormerLeftChild, index);
      }
    } else {
      x.setParent(yFormerParent, index);

      if (yFormerParent != null) {
        if (yWasLeftChild)
          yFormerParent.setLeft(x, index);
        else {
          yFormerParent.setRight(x, index);
        }
      }

      y.setLeft(xFormerLeftChild, index);
      y.setRight(xFormerRightChild, index);
    }

    if (y == xFormerParent) {
      y.setParent(x, index);

      if (xWasLeftChild) {
        x.setLeft(y, index);
        x.setRight(yFormerRightChild, index);
      } else {
        x.setRight(y, index);
        x.setLeft(yFormerLeftChild, index);
      }
    } else {
      y.setParent(xFormerParent, index);

      if (xFormerParent != null) {
        if (xWasLeftChild)
          xFormerParent.setLeft(y, index);
        else {
          xFormerParent.setRight(y, index);
        }
      }

      x.setLeft(yFormerLeftChild, index);
      x.setRight(yFormerRightChild, index);
    }

    if (x.getLeft(index) != null) {
      Node.access$700(x, index).setParent(x, index);
    }

    if (x.getRight(index) != null) {
      Node.access$800(x, index).setParent(x, index);
    }

    if (y.getLeft(index) != null) {
      Node.access$700(y, index).setParent(y, index);
    }

    if (y.getRight(index) != null) {
      Node.access$800(y, index).setParent(y, index);
    }

    x.swapColors(y, index);

    if (rootNode[index] == x)
      rootNode[index] = y;
    else if (rootNode[index] == y)
      rootNode[index] = x;
  }

  private static void checkNonNullComparable(Object o, int index)
  {
    if (o == null) {
      throw new NullPointerException(dataName[index] + " cannot be null");
    }

    if (!(o instanceof Comparable))
      throw new ClassCastException(dataName[index] + " must be Comparable");
  }

  private static void checkKey(Object key)
  {
    checkNonNullComparable(key, 0);
  }

  private static void checkValue(Object value)
  {
    checkNonNullComparable(value, 1);
  }

  private static void checkKeyAndValue(Object key, Object value)
  {
    checkKey(key);
    checkValue(value);
  }

  private void modify()
  {
    modifications += 1;
  }

  private void grow()
  {
    modify();

    nodeCount += 1;
  }

  private void shrink()
  {
    modify();

    nodeCount -= 1;
  }

  private void insertValue(Node newNode)
    throws IllegalArgumentException
  {
    Node node = rootNode[1];
    while (true)
    {
      int cmp = compare(newNode.getData(1), node.getData(1));

      if (cmp == 0) {
        throw new IllegalArgumentException("Cannot store a duplicate value (\"" + newNode.getData(1) + "\") in this Map");
      }

      if (cmp < 0) {
        if (node.getLeft(1) != null) {
          node = node.getLeft(1);
        } else {
          node.setLeft(newNode, 1);
          newNode.setParent(node, 1);
          doRedBlackInsert(newNode, 1);

          break;
        }
      }
      else if (node.getRight(1) != null) {
        node = node.getRight(1);
      } else {
        node.setRight(newNode, 1);
        newNode.setParent(node, 1);
        doRedBlackInsert(newNode, 1);

        break;
      }
    }
  }

  public int size()
  {
    return nodeCount;
  }

  public boolean containsKey(Object key)
    throws ClassCastException, NullPointerException
  {
    checkKey(key);

    return lookup((Comparable)key, 0) != null;
  }

  public boolean containsValue(Object value)
  {
    checkValue(value);

    return lookup((Comparable)value, 1) != null;
  }

  public Object get(Object key)
    throws ClassCastException, NullPointerException
  {
    return doGet((Comparable)key, 0);
  }

  public Object put(Object key, Object value)
    throws ClassCastException, NullPointerException, IllegalArgumentException
  {
    checkKeyAndValue(key, value);

    Node node = rootNode[0];

    if (node == null) {
      Node root = new Node((Comparable)key, (Comparable)value);

      rootNode[0] = root;
      rootNode[1] = root;

      grow();
    } else {
      while (true) {
        int cmp = compare((Comparable)key, node.getData(0));

        if (cmp == 0) {
          throw new IllegalArgumentException("Cannot store a duplicate key (\"" + key + "\") in this Map");
        }

        if (cmp < 0) {
          if (node.getLeft(0) != null) {
            node = node.getLeft(0);
          } else {
            Node newNode = new Node((Comparable)key, (Comparable)value);

            insertValue(newNode);
            node.setLeft(newNode, 0);
            newNode.setParent(node, 0);
            doRedBlackInsert(newNode, 0);
            grow();

            break;
          }
        }
        else if (node.getRight(0) != null) {
          node = node.getRight(0);
        } else {
          Node newNode = new Node((Comparable)key, (Comparable)value);

          insertValue(newNode);
          node.setRight(newNode, 0);
          newNode.setParent(node, 0);
          doRedBlackInsert(newNode, 0);
          grow();

          break;
        }
      }

    }

    return null;
  }

  public Object remove(Object key)
  {
    return doRemove((Comparable)key, 0);
  }

  public void clear()
  {
    modify();

    nodeCount = 0;
    rootNode[0] = null;
    rootNode[1] = null;
  }

  public Set keySet()
  {
    if (setOfKeys[0] == null) {
      setOfKeys[0] = new AbstractSet()
      {
        public Iterator iterator()
        {
          return new DoubleOrderedMap.8(this, 0);
        }

        public int size()
        {
          return DoubleOrderedMap.this.size();
        }

        public boolean contains(Object o) {
          return containsKey(o);
        }

        public boolean remove(Object o)
        {
          int oldNodeCount = nodeCount;

          remove(o);

          return nodeCount != oldNodeCount;
        }

        public void clear() {
          DoubleOrderedMap.this.clear();
        }
      };
    }
    return setOfKeys[0];
  }

  public Collection values()
  {
    if (collectionOfValues[0] == null) {
      collectionOfValues[0] = new AbstractCollection()
      {
        public Iterator iterator()
        {
          return new DoubleOrderedMap.10(this, 0);
        }

        public int size()
        {
          return DoubleOrderedMap.this.size();
        }

        public boolean contains(Object o) {
          return containsValue(o);
        }

        public boolean remove(Object o)
        {
          int oldNodeCount = nodeCount;

          removeValue(o);

          return nodeCount != oldNodeCount;
        }

        public boolean removeAll(Collection c)
        {
          boolean modified = false;
          Iterator iter = c.iterator();

          while (iter.hasNext()) {
            if (removeValue(iter.next()) != null) {
              modified = true;
            }
          }

          return modified;
        }

        public void clear() {
          DoubleOrderedMap.this.clear();
        }
      };
    }
    return collectionOfValues[0];
  }

  public Set entrySet()
  {
    if (setOfEntries[0] == null) {
      setOfEntries[0] = new AbstractSet()
      {
        public Iterator iterator()
        {
          return new DoubleOrderedMap.12(this, 0);
        }

        public boolean contains(Object o)
        {
          if (!(o instanceof Map.Entry)) {
            return false;
          }

          Map.Entry entry = (Map.Entry)o;
          Object value = entry.getValue();
          DoubleOrderedMap.Node node = DoubleOrderedMap.this.lookup((Comparable)entry.getKey(), 0);

          return (node != null) && (node.getData(1).equals(value));
        }

        public boolean remove(Object o)
        {
          if (!(o instanceof Map.Entry)) {
            return false;
          }

          Map.Entry entry = (Map.Entry)o;
          Object value = entry.getValue();
          DoubleOrderedMap.Node node = DoubleOrderedMap.this.lookup((Comparable)entry.getKey(), 0);

          if ((node != null) && (node.getData(1).equals(value))) {
            DoubleOrderedMap.this.doRedBlackDelete(node);

            return true;
          }

          return false;
        }

        public int size() {
          return DoubleOrderedMap.this.size();
        }

        public void clear() {
          DoubleOrderedMap.this.clear();
        }
      };
    }
    return setOfEntries[0];
  }

  private static final class Node
    implements Map.Entry, KeyValue
  {
    private Comparable[] data;
    private Node[] leftNode;
    private Node[] rightNode;
    private Node[] parentNode;
    private boolean[] blackColor;
    private int hashcodeValue;
    private boolean calculatedHashCode;

    Node(Comparable key, Comparable value)
    {
      data = new Comparable[] { key, value };
      leftNode = new Node[] { null, null };
      rightNode = new Node[] { null, null };
      parentNode = new Node[] { null, null };
      blackColor = new boolean[] { true, true };
      calculatedHashCode = false;
    }

    private Comparable getData(int index)
    {
      return data[index];
    }

    private void setLeft(Node node, int index)
    {
      leftNode[index] = node;
    }

    private Node getLeft(int index)
    {
      return leftNode[index];
    }

    private void setRight(Node node, int index)
    {
      rightNode[index] = node;
    }

    private Node getRight(int index)
    {
      return rightNode[index];
    }

    private void setParent(Node node, int index)
    {
      parentNode[index] = node;
    }

    private Node getParent(int index)
    {
      return parentNode[index];
    }

    private void swapColors(Node node, int index)
    {
      blackColor[index] ^= node.blackColor[index];
      node.blackColor[index] ^= blackColor[index];
      blackColor[index] ^= node.blackColor[index];
    }

    private boolean isBlack(int index)
    {
      return blackColor[index];
    }

    private boolean isRed(int index)
    {
      return blackColor[index] == 0;
    }

    private void setBlack(int index)
    {
      blackColor[index] = true;
    }

    private void setRed(int index)
    {
      blackColor[index] = false;
    }

    private void copyColor(Node node, int index)
    {
      blackColor[index] = node.blackColor[index];
    }

    public Object getKey()
    {
      return data[0];
    }

    public Object getValue()
    {
      return data[1];
    }

    public Object setValue(Object ignored)
      throws UnsupportedOperationException
    {
      throw new UnsupportedOperationException("Map.Entry.setValue is not supported");
    }

    public boolean equals(Object o)
    {
      if (this == o) {
        return true;
      }

      if (!(o instanceof KeyValue)) {
        return false;
      }

      Map.Entry e = (KeyValue)o;

      return (data[0].equals(e.getKey())) && (data[1].equals(e.getValue()));
    }

    public int hashCode()
    {
      if (!calculatedHashCode) {
        hashcodeValue = (data[0].hashCode() ^ data[1].hashCode());

        calculatedHashCode = true;
      }

      return hashcodeValue;
    }
  }

  private abstract class DoubleOrderedMapIterator
    implements Iterator
  {
    private int expectedModifications;
    protected DoubleOrderedMap.Node lastReturnedNode;
    private DoubleOrderedMap.Node nextNode;
    private int iteratorType;

    DoubleOrderedMapIterator(int type)
    {
      iteratorType = type;
      expectedModifications = modifications;
      lastReturnedNode = null;
      nextNode = DoubleOrderedMap.access$2400(rootNode[iteratorType], iteratorType);
    }

    protected abstract Object doGetNext();

    public final boolean hasNext()
    {
      return nextNode != null;
    }

    public final Object next()
      throws NoSuchElementException, ConcurrentModificationException
    {
      if (nextNode == null) {
        throw new NoSuchElementException();
      }

      if (modifications != expectedModifications) {
        throw new ConcurrentModificationException();
      }

      lastReturnedNode = nextNode;
      nextNode = DoubleOrderedMap.this.nextGreater(nextNode, iteratorType);

      return doGetNext();
    }

    public final void remove()
      throws IllegalStateException, ConcurrentModificationException
    {
      if (lastReturnedNode == null) {
        throw new IllegalStateException();
      }

      if (modifications != expectedModifications) {
        throw new ConcurrentModificationException();
      }

      DoubleOrderedMap.this.doRedBlackDelete(lastReturnedNode);

      expectedModifications += 1;

      lastReturnedNode = null;
    }
  }
}