package org.apache.commons.collections;

import java.util.Collection;

public abstract interface Buffer extends Collection
{
  public abstract Object remove();

  public abstract Object get();
}