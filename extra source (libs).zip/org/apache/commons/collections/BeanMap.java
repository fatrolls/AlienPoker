package org.apache.commons.collections;

import java.beans.BeanInfo;
import java.beans.FeatureDescriptor;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import org.apache.commons.collections.keyvalue.AbstractKeyValue;
import org.apache.commons.collections.keyvalue.AbstractMapEntry;
import org.apache.commons.collections.list.UnmodifiableList;
import org.apache.commons.collections.set.UnmodifiableSet;

public class BeanMap extends AbstractMap
  implements Cloneable
{
  private transient Object bean;
  private transient HashMap readMethods = new HashMap();
  private transient HashMap writeMethods = new HashMap();
  private transient HashMap types = new HashMap();

  public static final Object[] NULL_ARGUMENTS = new Object[0];

  public static HashMap defaultTransformers = new HashMap();

  public BeanMap()
  {
  }

  public BeanMap(Object bean)
  {
    this.bean = bean;
    initialise();
  }

  public String toString()
  {
    return "BeanMap<" + String.valueOf(bean) + ">";
  }

  public Object clone()
    throws CloneNotSupportedException
  {
    BeanMap newMap = (BeanMap)super.clone();

    if (bean == null)
    {
      return newMap;
    }

    Object newBean = null;
    Class beanClass = null;
    try {
      beanClass = bean.getClass();
      newBean = beanClass.newInstance();
    }
    catch (Exception e) {
      throw new CloneNotSupportedException("Unable to instantiate the underlying bean \"" + beanClass.getName() + "\": " + e);
    }

    try
    {
      newMap.setBean(newBean);
    } catch (Exception exception) {
      throw new CloneNotSupportedException("Unable to set bean in the cloned bean map: " + exception);
    }

    try
    {
      Iterator readableKeys = readMethods.keySet().iterator();
      while (readableKeys.hasNext()) {
        Object key = readableKeys.next();
        if (getWriteMethod(key) != null)
          newMap.put(key, get(key));
      }
    }
    catch (Exception exception) {
      throw new CloneNotSupportedException("Unable to copy bean values to cloned bean map: " + exception);
    }

    return newMap;
  }

  public void putAllWriteable(BeanMap map)
  {
    Iterator readableKeys = map.readMethods.keySet().iterator();
    while (readableKeys.hasNext()) {
      Object key = readableKeys.next();
      if (getWriteMethod(key) != null)
        put(key, map.get(key));
    }
  }

  public void clear()
  {
    if (bean == null) return;

    Class beanClass = null;
    try {
      beanClass = bean.getClass();
      bean = beanClass.newInstance();
    }
    catch (Exception e) {
      throw new UnsupportedOperationException("Could not create new instance of class: " + beanClass);
    }
  }

  public boolean containsKey(Object name)
  {
    Method method = getReadMethod(name);
    return method != null;
  }

  public boolean containsValue(Object value)
  {
    return super.containsValue(value);
  }

  public Object get(Object name)
  {
    if (bean != null) {
      Method method = getReadMethod(name);
      if (method != null) {
        try {
          return method.invoke(bean, NULL_ARGUMENTS);
        }
        catch (IllegalAccessException e) {
          logWarn(e);
        }
        catch (IllegalArgumentException e) {
          logWarn(e);
        }
        catch (InvocationTargetException e) {
          logWarn(e);
        }
        catch (NullPointerException e) {
          logWarn(e);
        }
      }
    }
    return null;
  }

  public Object put(Object name, Object value)
    throws IllegalArgumentException, ClassCastException
  {
    if (bean != null) {
      Object oldValue = get(name);
      Method method = getWriteMethod(name);
      if (method == null)
        throw new IllegalArgumentException("The bean of type: " + bean.getClass().getName() + " has no property called: " + name);
      try
      {
        Object[] arguments = createWriteMethodArguments(method, value);
        method.invoke(bean, arguments);

        Object newValue = get(name);
        firePropertyChange(name, oldValue, newValue);
      }
      catch (InvocationTargetException e) {
        logInfo(e);
        throw new IllegalArgumentException(e.getMessage());
      }
      catch (IllegalAccessException e) {
        logInfo(e);
        throw new IllegalArgumentException(e.getMessage());
      }
      return oldValue;
    }
    return null;
  }

  public int size()
  {
    return readMethods.size();
  }

  public Set keySet()
  {
    return UnmodifiableSet.decorate(readMethods.keySet());
  }

  public Set entrySet()
  {
    return UnmodifiableSet.decorate(new AbstractSet() {
      public Iterator iterator() {
        return entryIterator();
      }
      public int size() {
        return readMethods.size();
      }
    });
  }

  public Collection values()
  {
    ArrayList answer = new ArrayList(readMethods.size());
    for (Iterator iter = valueIterator(); iter.hasNext(); ) {
      answer.add(iter.next());
    }
    return UnmodifiableList.decorate(answer);
  }

  public Class getType(String name)
  {
    return (Class)types.get(name);
  }

  public Iterator keyIterator()
  {
    return readMethods.keySet().iterator();
  }

  public Iterator valueIterator()
  {
    Iterator iter = keyIterator();
    return new Iterator(iter) { private final Iterator val$iter;

      public boolean hasNext() { return val$iter.hasNext(); }

      public Object next() {
        Object key = val$iter.next();
        return get(key);
      }
      public void remove() {
        throw new UnsupportedOperationException("remove() not supported for BeanMap");
      }
    };
  }

  public Iterator entryIterator()
  {
    Iterator iter = keyIterator();
    return new Iterator(iter) { private final Iterator val$iter;

      public boolean hasNext() { return val$iter.hasNext(); }

      public Object next() {
        Object key = val$iter.next();
        Object value = get(key);
        return new BeanMap.MyMapEntry(BeanMap.this, key, value);
      }
      public void remove() {
        throw new UnsupportedOperationException("remove() not supported for BeanMap");
      }
    };
  }

  public Object getBean()
  {
    return bean;
  }

  public void setBean(Object newBean)
  {
    bean = newBean;
    reinitialise();
  }

  public Method getReadMethod(String name)
  {
    return (Method)readMethods.get(name);
  }

  public Method getWriteMethod(String name)
  {
    return (Method)writeMethods.get(name);
  }

  protected Method getReadMethod(Object name)
  {
    return (Method)readMethods.get(name);
  }

  protected Method getWriteMethod(Object name)
  {
    return (Method)writeMethods.get(name);
  }

  protected void reinitialise()
  {
    readMethods.clear();
    writeMethods.clear();
    types.clear();
    initialise();
  }

  private void initialise() {
    if (getBean() == null) return;

    Class beanClass = getBean().getClass();
    try
    {
      BeanInfo beanInfo = Introspector.getBeanInfo(beanClass);
      PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
      if (propertyDescriptors != null)
        for (int i = 0; i < propertyDescriptors.length; i++) {
          PropertyDescriptor propertyDescriptor = propertyDescriptors[i];
          if (propertyDescriptor != null) {
            String name = propertyDescriptor.getName();
            Method readMethod = propertyDescriptor.getReadMethod();
            Method writeMethod = propertyDescriptor.getWriteMethod();
            Class aType = propertyDescriptor.getPropertyType();

            if (readMethod != null) {
              readMethods.put(name, readMethod);
            }
            if (writeMethods != null) {
              writeMethods.put(name, writeMethod);
            }
            types.put(name, aType);
          }
        }
    }
    catch (IntrospectionException e)
    {
      logWarn(e);
    }
  }

  protected void firePropertyChange(Object key, Object oldValue, Object newValue)
  {
  }

  protected Object[] createWriteMethodArguments(Method method, Object value)
    throws IllegalAccessException, ClassCastException
  {
    try
    {
      if (value != null) {
        Class[] types = method.getParameterTypes();
        if ((types != null) && (types.length > 0)) {
          Class paramType = types[0];
          if (!paramType.isAssignableFrom(value.getClass())) {
            value = convertType(paramType, value);
          }
        }
      }
      Object[] answer = { value };
      return answer;
    }
    catch (InvocationTargetException e) {
      logInfo(e);
      throw new IllegalArgumentException(e.getMessage());
    }
    catch (InstantiationException e) {
      logInfo(e);
    }throw new IllegalArgumentException(e.getMessage());
  }

  protected Object convertType(Class newType, Object value)
    throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
  {
    Class[] types = { value.getClass() };
    try {
      Constructor constructor = newType.getConstructor(types);
      Object[] arguments = { value };
      return constructor.newInstance(arguments);
    }
    catch (NoSuchMethodException e)
    {
      Transformer transformer = getTypeTransformer(newType);
      if (transformer != null)
        return transformer.transform(value);
    }
    return value;
  }

  protected Transformer getTypeTransformer(Class aType)
  {
    return (Transformer)defaultTransformers.get(aType);
  }

  protected void logInfo(Exception ex)
  {
    System.out.println("INFO: Exception: " + ex);
  }

  protected void logWarn(Exception ex)
  {
    System.out.println("WARN: Exception: " + ex);
    ex.printStackTrace();
  }

  static
  {
    defaultTransformers.put(Boolean.TYPE, new Transformer()
    {
      public Object transform(Object input)
      {
        return Boolean.valueOf(input.toString());
      }
    });
    defaultTransformers.put(Character.TYPE, new Transformer()
    {
      public Object transform(Object input)
      {
        return new Character(input.toString().charAt(0));
      }
    });
    defaultTransformers.put(Byte.TYPE, new Transformer()
    {
      public Object transform(Object input)
      {
        return Byte.valueOf(input.toString());
      }
    });
    defaultTransformers.put(Short.TYPE, new Transformer()
    {
      public Object transform(Object input)
      {
        return Short.valueOf(input.toString());
      }
    });
    defaultTransformers.put(Integer.TYPE, new Transformer()
    {
      public Object transform(Object input)
      {
        return Integer.valueOf(input.toString());
      }
    });
    defaultTransformers.put(Long.TYPE, new Transformer()
    {
      public Object transform(Object input)
      {
        return Long.valueOf(input.toString());
      }
    });
    defaultTransformers.put(Float.TYPE, new Transformer()
    {
      public Object transform(Object input)
      {
        return Float.valueOf(input.toString());
      }
    });
    defaultTransformers.put(Double.TYPE, new Transformer()
    {
      public Object transform(Object input)
      {
        return Double.valueOf(input.toString());
      }
    });
  }

  protected static class MyMapEntry extends AbstractMapEntry
  {
    private BeanMap owner;

    protected MyMapEntry(BeanMap owner, Object key, Object value)
    {
      super(value);
      this.owner = owner;
    }

    public Object setValue(Object value)
    {
      Object key = getKey();
      Object oldValue = owner.get(key);

      owner.put(key, value);
      Object newValue = owner.get(key);
      super.setValue(newValue);
      return oldValue;
    }
  }
}