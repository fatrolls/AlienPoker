package org.apache.commons.collections;

import java.util.Collection;

public abstract interface BoundedCollection extends Collection
{
  public abstract boolean isFull();

  public abstract int maxSize();
}