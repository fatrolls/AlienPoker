package org.apache.commons.collections.bidimap;

import org.apache.commons.collections.OrderedBidiMap;
import org.apache.commons.collections.OrderedMap;
import org.apache.commons.collections.OrderedMapIterator;
import org.apache.commons.collections.map.AbstractMapDecorator;

public abstract class AbstractOrderedBidiMapDecorator extends AbstractBidiMapDecorator
  implements OrderedBidiMap
{
  protected AbstractOrderedBidiMapDecorator(OrderedBidiMap map)
  {
    super(map);
  }

  protected OrderedBidiMap getOrderedBidiMap()
  {
    return (OrderedBidiMap)map;
  }

  public OrderedMapIterator orderedMapIterator()
  {
    return getOrderedBidiMap().orderedMapIterator();
  }

  public Object firstKey() {
    return getOrderedBidiMap().firstKey();
  }

  public Object lastKey() {
    return getOrderedBidiMap().lastKey();
  }

  public Object nextKey(Object key) {
    return getOrderedBidiMap().nextKey(key);
  }

  public Object previousKey(Object key) {
    return getOrderedBidiMap().previousKey(key);
  }

  public OrderedBidiMap inverseOrderedBidiMap() {
    return getOrderedBidiMap().inverseOrderedBidiMap();
  }
}