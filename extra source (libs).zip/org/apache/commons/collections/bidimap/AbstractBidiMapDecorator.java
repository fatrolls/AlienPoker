package org.apache.commons.collections.bidimap;

import org.apache.commons.collections.BidiMap;
import org.apache.commons.collections.MapIterator;
import org.apache.commons.collections.map.AbstractMapDecorator;

public abstract class AbstractBidiMapDecorator extends AbstractMapDecorator
  implements BidiMap
{
  protected AbstractBidiMapDecorator(BidiMap map)
  {
    super(map);
  }

  protected BidiMap getBidiMap()
  {
    return (BidiMap)map;
  }

  public MapIterator mapIterator()
  {
    return getBidiMap().mapIterator();
  }

  public Object getKey(Object value) {
    return getBidiMap().getKey(value);
  }

  public Object removeValue(Object value) {
    return getBidiMap().removeValue(value);
  }

  public BidiMap inverseBidiMap() {
    return getBidiMap().inverseBidiMap();
  }
}