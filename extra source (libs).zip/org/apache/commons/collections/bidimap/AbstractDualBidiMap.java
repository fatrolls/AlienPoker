package org.apache.commons.collections.bidimap;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.commons.collections.BidiMap;
import org.apache.commons.collections.MapIterator;
import org.apache.commons.collections.ResettableIterator;
import org.apache.commons.collections.collection.AbstractCollectionDecorator;
import org.apache.commons.collections.iterators.AbstractIteratorDecorator;
import org.apache.commons.collections.keyvalue.AbstractMapEntryDecorator;

public abstract class AbstractDualBidiMap
  implements BidiMap
{
  protected final transient Map[] maps = new Map[2];

  protected transient BidiMap inverseBidiMap = null;

  protected transient Set keySet = null;

  protected transient Collection values = null;

  protected transient Set entrySet = null;

  protected AbstractDualBidiMap()
  {
    maps[0] = createMap();
    maps[1] = createMap();
  }

  protected AbstractDualBidiMap(Map normalMap, Map reverseMap)
  {
    maps[0] = normalMap;
    maps[1] = reverseMap;
  }

  protected AbstractDualBidiMap(Map normalMap, Map reverseMap, BidiMap inverseBidiMap)
  {
    maps[0] = normalMap;
    maps[1] = reverseMap;
    this.inverseBidiMap = inverseBidiMap;
  }

  /** @deprecated */
  protected Map createMap()
  {
    return null;
  }

  protected abstract BidiMap createBidiMap(Map paramMap1, Map paramMap2, BidiMap paramBidiMap);

  public Object get(Object key)
  {
    return maps[0].get(key);
  }

  public int size() {
    return maps[0].size();
  }

  public boolean isEmpty() {
    return maps[0].isEmpty();
  }

  public boolean containsKey(Object key) {
    return maps[0].containsKey(key);
  }

  public boolean equals(Object obj) {
    return maps[0].equals(obj);
  }

  public int hashCode() {
    return maps[0].hashCode();
  }

  public String toString() {
    return maps[0].toString();
  }

  public Object put(Object key, Object value)
  {
    if (maps[0].containsKey(key)) {
      maps[1].remove(maps[0].get(key));
    }
    if (maps[1].containsKey(value)) {
      maps[0].remove(maps[1].get(value));
    }
    Object obj = maps[0].put(key, value);
    maps[1].put(value, key);
    return obj;
  }

  public void putAll(Map map) {
    for (Iterator it = map.entrySet().iterator(); it.hasNext(); ) {
      Map.Entry entry = (Map.Entry)it.next();
      put(entry.getKey(), entry.getValue());
    }
  }

  public Object remove(Object key) {
    Object value = null;
    if (maps[0].containsKey(key)) {
      value = maps[0].remove(key);
      maps[1].remove(value);
    }
    return value;
  }

  public void clear() {
    maps[0].clear();
    maps[1].clear();
  }

  public boolean containsValue(Object value) {
    return maps[1].containsKey(value);
  }

  public MapIterator mapIterator()
  {
    return new BidiMapIterator(this);
  }

  public Object getKey(Object value) {
    return maps[1].get(value);
  }

  public Object removeValue(Object value) {
    Object key = null;
    if (maps[1].containsKey(value)) {
      key = maps[1].remove(value);
      maps[0].remove(key);
    }
    return key;
  }

  public BidiMap inverseBidiMap() {
    if (inverseBidiMap == null) {
      inverseBidiMap = createBidiMap(maps[1], maps[0], this);
    }
    return inverseBidiMap;
  }

  public Set keySet()
  {
    if (keySet == null) {
      keySet = new KeySet(this);
    }
    return keySet;
  }

  protected Iterator createKeySetIterator(Iterator iterator)
  {
    return new KeySetIterator(iterator, this);
  }

  public Collection values()
  {
    if (values == null) {
      values = new Values(this);
    }
    return values;
  }

  protected Iterator createValuesIterator(Iterator iterator)
  {
    return new ValuesIterator(iterator, this);
  }

  public Set entrySet()
  {
    if (entrySet == null) {
      entrySet = new EntrySet(this);
    }
    return entrySet;
  }

  protected Iterator createEntrySetIterator(Iterator iterator)
  {
    return new EntrySetIterator(iterator, this);
  }

  protected static class BidiMapIterator
    implements MapIterator, ResettableIterator
  {
    protected final AbstractDualBidiMap parent;
    protected Iterator iterator;
    protected Map.Entry last = null;

    protected boolean canRemove = false;

    protected BidiMapIterator(AbstractDualBidiMap parent)
    {
      this.parent = parent;
      iterator = parent.maps[0].entrySet().iterator();
    }

    public boolean hasNext() {
      return iterator.hasNext();
    }

    public Object next() {
      last = ((Map.Entry)iterator.next());
      canRemove = true;
      return last.getKey();
    }

    public void remove() {
      if (!canRemove) {
        throw new IllegalStateException("Iterator remove() can only be called once after next()");
      }

      Object value = last.getValue();
      iterator.remove();
      parent.maps[1].remove(value);
      last = null;
      canRemove = false;
    }

    public Object getKey() {
      if (last == null) {
        throw new IllegalStateException("Iterator getKey() can only be called after next() and before remove()");
      }
      return last.getKey();
    }

    public Object getValue() {
      if (last == null) {
        throw new IllegalStateException("Iterator getValue() can only be called after next() and before remove()");
      }
      return last.getValue();
    }

    public Object setValue(Object value) {
      if (last == null) {
        throw new IllegalStateException("Iterator setValue() can only be called after next() and before remove()");
      }
      if ((parent.maps[1].containsKey(value)) && (parent.maps[1].get(value) != last.getKey()))
      {
        throw new IllegalArgumentException("Cannot use setValue() when the object being set is already in the map");
      }
      return parent.put(last.getKey(), value);
    }

    public void reset() {
      iterator = parent.maps[0].entrySet().iterator();
      last = null;
      canRemove = false;
    }

    public String toString() {
      if (last != null) {
        return "MapIterator[" + getKey() + "=" + getValue() + "]";
      }
      return "MapIterator[]";
    }
  }

  protected static class MapEntry extends AbstractMapEntryDecorator
  {
    protected final AbstractDualBidiMap parent;

    protected MapEntry(Map.Entry entry, AbstractDualBidiMap parent)
    {
      super();
      this.parent = parent;
    }

    public Object setValue(Object value) {
      Object key = getKey();
      if ((parent.maps[1].containsKey(value)) && (parent.maps[1].get(value) != key))
      {
        throw new IllegalArgumentException("Cannot use setValue() when the object being set is already in the map");
      }
      parent.put(key, value);
      Object oldValue = super.setValue(value);
      return oldValue;
    }
  }

  protected static class EntrySetIterator extends AbstractIteratorDecorator
  {
    protected final AbstractDualBidiMap parent;
    protected Map.Entry last = null;

    protected boolean canRemove = false;

    protected EntrySetIterator(Iterator iterator, AbstractDualBidiMap parent)
    {
      super();
      this.parent = parent;
    }

    public Object next() {
      last = new AbstractDualBidiMap.MapEntry((Map.Entry)super.next(), parent);
      canRemove = true;
      return last;
    }

    public void remove() {
      if (!canRemove) {
        throw new IllegalStateException("Iterator remove() can only be called once after next()");
      }

      Object value = last.getValue();
      super.remove();
      parent.maps[1].remove(value);
      last = null;
      canRemove = false;
    }
  }

  protected static class EntrySet extends AbstractDualBidiMap.View
    implements Set
  {
    protected EntrySet(AbstractDualBidiMap parent)
    {
      super(parent);
    }

    public Iterator iterator() {
      return parent.createEntrySetIterator(super.iterator());
    }

    public boolean remove(Object obj) {
      if (!(obj instanceof Map.Entry)) {
        return false;
      }
      Map.Entry entry = (Map.Entry)obj;
      Object key = entry.getKey();
      if (parent.containsKey(key)) {
        Object value = parent.maps[0].get(key);
        if ((value == null ? false : entry.getValue() == null ? true : value.equals(entry.getValue()))) {
          parent.maps[0].remove(key);
          parent.maps[1].remove(value);
          return true;
        }
      }
      return false;
    }
  }

  protected static class ValuesIterator extends AbstractIteratorDecorator
  {
    protected final AbstractDualBidiMap parent;
    protected Object lastValue = null;

    protected boolean canRemove = false;

    protected ValuesIterator(Iterator iterator, AbstractDualBidiMap parent)
    {
      super();
      this.parent = parent;
    }

    public Object next() {
      lastValue = super.next();
      canRemove = true;
      return lastValue;
    }

    public void remove() {
      if (!canRemove) {
        throw new IllegalStateException("Iterator remove() can only be called once after next()");
      }
      super.remove();
      parent.maps[1].remove(lastValue);
      lastValue = null;
      canRemove = false;
    }
  }

  protected static class Values extends AbstractDualBidiMap.View
    implements Set
  {
    protected Values(AbstractDualBidiMap parent)
    {
      super(parent);
    }

    public Iterator iterator() {
      return parent.createValuesIterator(super.iterator());
    }

    public boolean contains(Object value) {
      return parent.maps[1].containsKey(value);
    }

    public boolean remove(Object value) {
      if (parent.maps[1].containsKey(value)) {
        Object key = parent.maps[1].remove(value);
        parent.maps[0].remove(key);
        return true;
      }
      return false;
    }
  }

  protected static class KeySetIterator extends AbstractIteratorDecorator
  {
    protected final AbstractDualBidiMap parent;
    protected Object lastKey = null;

    protected boolean canRemove = false;

    protected KeySetIterator(Iterator iterator, AbstractDualBidiMap parent)
    {
      super();
      this.parent = parent;
    }

    public Object next() {
      lastKey = super.next();
      canRemove = true;
      return lastKey;
    }

    public void remove() {
      if (!canRemove) {
        throw new IllegalStateException("Iterator remove() can only be called once after next()");
      }
      Object value = parent.maps[0].get(lastKey);
      super.remove();
      parent.maps[1].remove(value);
      lastKey = null;
      canRemove = false;
    }
  }

  protected static class KeySet extends AbstractDualBidiMap.View
    implements Set
  {
    protected KeySet(AbstractDualBidiMap parent)
    {
      super(parent);
    }

    public Iterator iterator() {
      return parent.createKeySetIterator(super.iterator());
    }

    public boolean contains(Object key) {
      return parent.maps[0].containsKey(key);
    }

    public boolean remove(Object key) {
      if (parent.maps[0].containsKey(key)) {
        Object value = parent.maps[0].remove(key);
        parent.maps[1].remove(value);
        return true;
      }
      return false;
    }
  }

  protected static abstract class View extends AbstractCollectionDecorator
  {
    protected final AbstractDualBidiMap parent;

    protected View(Collection coll, AbstractDualBidiMap parent)
    {
      super();
      this.parent = parent;
    }

    public boolean removeAll(Collection coll) {
      if ((parent.isEmpty()) || (coll.isEmpty())) {
        return false;
      }
      boolean modified = false;
      Iterator it = iterator();
      while (it.hasNext()) {
        if (coll.contains(it.next())) {
          it.remove();
          modified = true;
        }
      }
      return modified;
    }

    public boolean retainAll(Collection coll) {
      if (parent.isEmpty()) {
        return false;
      }
      if (coll.isEmpty()) {
        parent.clear();
        return true;
      }
      boolean modified = false;
      Iterator it = iterator();
      while (it.hasNext()) {
        if (!coll.contains(it.next())) {
          it.remove();
          modified = true;
        }
      }
      return modified;
    }

    public void clear() {
      parent.clear();
    }
  }
}