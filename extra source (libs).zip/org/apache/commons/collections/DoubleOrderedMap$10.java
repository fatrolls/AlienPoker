package org.apache.commons.collections;

class DoubleOrderedMap$10 extends DoubleOrderedMap.DoubleOrderedMapIterator
{
  private final DoubleOrderedMap.9 this$1;

  protected Object doGetNext()
  {
    return DoubleOrderedMap.Node.access$200(lastReturnedNode, 1);
  }
}