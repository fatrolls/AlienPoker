package org.apache.commons.collections;

import java.util.AbstractMap;
import java.util.Collection;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

public class FastTreeMap extends TreeMap
{
  protected TreeMap map = null;

  protected boolean fast = false;

  public FastTreeMap()
  {
    map = new TreeMap();
  }

  public FastTreeMap(Comparator comparator)
  {
    map = new TreeMap(comparator);
  }

  public FastTreeMap(Map map)
  {
    this.map = new TreeMap(map);
  }

  public FastTreeMap(SortedMap map)
  {
    this.map = new TreeMap(map);
  }

  public boolean getFast()
  {
    return fast;
  }

  public void setFast(boolean fast)
  {
    this.fast = fast;
  }

  public Object get(Object key)
  {
    if (fast) {
      return map.get(key);
    }
    synchronized (map) {
      return map.get(key);
    }
  }

  public int size()
  {
    if (fast) {
      return map.size();
    }
    synchronized (map) {
      return map.size();
    }
  }

  public boolean isEmpty()
  {
    if (fast) {
      return map.isEmpty();
    }
    synchronized (map) {
      return map.isEmpty();
    }
  }

  public boolean containsKey(Object key)
  {
    if (fast) {
      return map.containsKey(key);
    }
    synchronized (map) {
      return map.containsKey(key);
    }
  }

  public boolean containsValue(Object value)
  {
    if (fast) {
      return map.containsValue(value);
    }
    synchronized (map) {
      return map.containsValue(value);
    }
  }

  public Comparator comparator()
  {
    if (fast) {
      return map.comparator();
    }
    synchronized (map) {
      return map.comparator();
    }
  }

  public Object firstKey()
  {
    if (fast) {
      return map.firstKey();
    }
    synchronized (map) {
      return map.firstKey();
    }
  }

  public Object lastKey()
  {
    if (fast) {
      return map.lastKey();
    }
    synchronized (map) {
      return map.lastKey();
    }
  }

  public Object put(Object key, Object value)
  {
    TreeMap temp;
    if (fast) {
      synchronized (this) {
        temp = (TreeMap)map.clone();
        Object result = temp.put(key, value);
        map = temp;
        return result;
      }
    }
    synchronized (map) {
      return map.put(key, value);
    }
  }

  public void putAll(Map in)
  {
    if (fast) {
      synchronized (this) {
        TreeMap temp = (TreeMap)map.clone();
        temp.putAll(in);
        map = temp;
      }
    }
    synchronized (map) {
      map.putAll(in);
    }
  }

  public Object remove(Object key)
  {
    TreeMap temp;
    if (fast) {
      synchronized (this) {
        temp = (TreeMap)map.clone();
        Object result = temp.remove(key);
        map = temp;
        return result;
      }
    }
    synchronized (map) {
      return map.remove(key);
    }
  }

  public void clear()
  {
    if (fast) {
      synchronized (this) {
        map = new TreeMap();
      }
    }
    synchronized (map) {
      map.clear();
    }
  }

  public boolean equals(Object o)
  {
    if (o == this)
      return true;
    if (!(o instanceof Map)) {
      return false;
    }
    Map mo = (Map)o;
    Map.Entry e;
    if (fast) {
      if (mo.size() != map.size()) {
        return false;
      }
      ??? = map.entrySet().iterator();
      while (???.hasNext()) {
        e = (Map.Entry)???.next();
        Object key = e.getKey();
        Object value = e.getValue();
        if (value == null) {
          if ((mo.get(key) != null) || (!mo.containsKey(key))) {
            return false;
          }
        }
        else if (!value.equals(mo.get(key))) {
          return false;
        }
      }

      return true;
    }
    synchronized (map) {
      if (mo.size() != map.size()) {
        return 0;
      }
      Iterator i = map.entrySet().iterator();
      Map.Entry e;
      while (i.hasNext()) {
        e = (Map.Entry)i.next();
        Object key = e.getKey();
        Object value = e.getValue();
        int i;
        if (value == null) {
          if ((mo.get(key) != null) || (!mo.containsKey(key))) {
            return 0;
          }
        }
        else if (!value.equals(mo.get(key))) {
          return 0;
        }
      }

      return 1;
    }
  }

  public int hashCode()
  {
    if (fast) {
      ??? = 0;
      Iterator i = map.entrySet().iterator();
      while (i.hasNext()) {
        ??? += i.next().hashCode();
      }
      return ???;
    }
    synchronized (map) {
      int h = 0;
      Iterator i = map.entrySet().iterator();
      while (i.hasNext()) {
        h += i.next().hashCode();
      }
      return h;
    }
  }

  public Object clone()
  {
    FastTreeMap results = null;
    if (fast)
      results = new FastTreeMap(map);
    else {
      synchronized (map) {
        results = new FastTreeMap(map);
      }
    }
    results.setFast(getFast());
    return results;
  }

  public SortedMap headMap(Object key)
  {
    if (fast) {
      return map.headMap(key);
    }
    synchronized (map) {
      return map.headMap(key);
    }
  }

  public SortedMap subMap(Object fromKey, Object toKey)
  {
    if (fast) {
      return map.subMap(fromKey, toKey);
    }
    synchronized (map) {
      return map.subMap(fromKey, toKey);
    }
  }

  public SortedMap tailMap(Object key)
  {
    if (fast) {
      return map.tailMap(key);
    }
    synchronized (map) {
      return map.tailMap(key);
    }
  }

  public Set entrySet()
  {
    return new EntrySet(null);
  }

  public Set keySet()
  {
    return new KeySet(null);
  }

  public Collection values()
  {
    return new Values(null);
  }

  private class EntrySet extends FastTreeMap.CollectionView
    implements Set
  {
    private final FastTreeMap this$0;

    private EntrySet()
    {
      super(); this.this$0 = this$0;
    }
    protected Collection get(Map map) {
      return map.entrySet();
    }

    protected Object iteratorNext(Map.Entry entry)
    {
      return entry;
    }

    EntrySet(FastTreeMap.1 x1)
    {
      this();
    }
  }

  private class Values extends FastTreeMap.CollectionView
  {
    private final FastTreeMap this$0;

    private Values()
    {
      super(); this.this$0 = this$0;
    }
    protected Collection get(Map map) {
      return map.values();
    }

    protected Object iteratorNext(Map.Entry entry) {
      return entry.getValue();
    }

    Values(FastTreeMap.1 x1)
    {
      this();
    }
  }

  private class KeySet extends FastTreeMap.CollectionView
    implements Set
  {
    private final FastTreeMap this$0;

    private KeySet()
    {
      super(); this.this$0 = this$0;
    }
    protected Collection get(Map map) {
      return map.keySet();
    }

    protected Object iteratorNext(Map.Entry entry) {
      return entry.getKey();
    }

    KeySet(FastTreeMap.1 x1)
    {
      this();
    }
  }

  private abstract class CollectionView
    implements Collection
  {
    public CollectionView()
    {
    }

    protected abstract Collection get(Map paramMap);

    protected abstract Object iteratorNext(Map.Entry paramEntry);

    public void clear()
    {
      if (fast) {
        synchronized (FastTreeMap.this) {
          map = new TreeMap();
        }
      }
      synchronized (map) {
        get(map).clear();
      }
    }

    public boolean remove(Object o)
    {
      TreeMap temp;
      if (fast) {
        synchronized (FastTreeMap.this) {
          temp = (TreeMap)map.clone();
          boolean r = get(temp).remove(o);
          map = temp;
          return r;
        }
      }
      synchronized (map) {
        return get(map).remove(o);
      }
    }

    public boolean removeAll(Collection o)
    {
      TreeMap temp;
      if (fast) {
        synchronized (FastTreeMap.this) {
          temp = (TreeMap)map.clone();
          boolean r = get(temp).removeAll(o);
          map = temp;
          return r;
        }
      }
      synchronized (map) {
        return get(map).removeAll(o);
      }
    }

    public boolean retainAll(Collection o)
    {
      TreeMap temp;
      if (fast) {
        synchronized (FastTreeMap.this) {
          temp = (TreeMap)map.clone();
          boolean r = get(temp).retainAll(o);
          map = temp;
          return r;
        }
      }
      synchronized (map) {
        return get(map).retainAll(o);
      }
    }

    public int size()
    {
      if (fast) {
        return get(map).size();
      }
      synchronized (map) {
        return get(map).size();
      }
    }

    public boolean isEmpty()
    {
      if (fast) {
        return get(map).isEmpty();
      }
      synchronized (map) {
        return get(map).isEmpty();
      }
    }

    public boolean contains(Object o)
    {
      if (fast) {
        return get(map).contains(o);
      }
      synchronized (map) {
        return get(map).contains(o);
      }
    }

    public boolean containsAll(Collection o)
    {
      if (fast) {
        return get(map).containsAll(o);
      }
      synchronized (map) {
        return get(map).containsAll(o);
      }
    }

    public Object[] toArray(Object[] o)
    {
      if (fast) {
        return get(map).toArray(o);
      }
      synchronized (map) {
        return get(map).toArray(o);
      }
    }

    public Object[] toArray()
    {
      if (fast) {
        return get(map).toArray();
      }
      synchronized (map) {
        return get(map).toArray();
      }
    }

    public boolean equals(Object o)
    {
      if (o == this) return true;
      if (fast) {
        return get(map).equals(o);
      }
      synchronized (map) {
        return get(map).equals(o);
      }
    }

    public int hashCode()
    {
      if (fast) {
        return get(map).hashCode();
      }
      synchronized (map) {
        return get(map).hashCode();
      }
    }

    public boolean add(Object o)
    {
      throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection c) {
      throw new UnsupportedOperationException();
    }

    public Iterator iterator() {
      return new CollectionViewIterator();
    }
    private class CollectionViewIterator implements Iterator {
      private Map expected;
      private Map.Entry lastReturned = null;
      private Iterator iterator;

      public CollectionViewIterator() { expected = map;
        iterator = expected.entrySet().iterator(); }

      public boolean hasNext()
      {
        if (expected != map) {
          throw new ConcurrentModificationException();
        }
        return iterator.hasNext();
      }

      public Object next() {
        if (expected != map) {
          throw new ConcurrentModificationException();
        }
        lastReturned = ((Map.Entry)iterator.next());
        return iteratorNext(lastReturned);
      }

      public void remove() {
        if (lastReturned == null) {
          throw new IllegalStateException();
        }
        if (fast) {
          synchronized (FastTreeMap.this) {
            if (expected != map) {
              throw new ConcurrentModificationException();
            }
            remove(lastReturned.getKey());
            lastReturned = null;
            expected = map;
          }
        }
        iterator.remove();
        lastReturned = null;
      }
    }
  }
}