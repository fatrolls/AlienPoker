package org.apache.commons.collections.comparators;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class ComparatorChain
  implements Comparator, Serializable
{
  private static final long serialVersionUID = -721644942746081630L;
  protected List comparatorChain = null;

  protected BitSet orderingBits = null;

  protected boolean isLocked = false;

  public ComparatorChain()
  {
    this(new ArrayList(), new BitSet());
  }

  public ComparatorChain(Comparator comparator)
  {
    this(comparator, false);
  }

  public ComparatorChain(Comparator comparator, boolean reverse)
  {
    comparatorChain = new ArrayList();
    comparatorChain.add(comparator);
    orderingBits = new BitSet(1);
    if (reverse == true)
      orderingBits.set(0);
  }

  public ComparatorChain(List list)
  {
    this(list, new BitSet(list.size()));
  }

  public ComparatorChain(List list, BitSet bits)
  {
    comparatorChain = list;
    orderingBits = bits;
  }

  public void addComparator(Comparator comparator)
  {
    addComparator(comparator, false);
  }

  public void addComparator(Comparator comparator, boolean reverse)
  {
    checkLocked();

    comparatorChain.add(comparator);
    if (reverse == true)
      orderingBits.set(comparatorChain.size() - 1);
  }

  public void setComparator(int index, Comparator comparator)
    throws IndexOutOfBoundsException
  {
    setComparator(index, comparator, false);
  }

  public void setComparator(int index, Comparator comparator, boolean reverse)
  {
    checkLocked();

    comparatorChain.set(index, comparator);
    if (reverse == true)
      orderingBits.set(index);
    else
      orderingBits.clear(index);
  }

  public void setForwardSort(int index)
  {
    checkLocked();
    orderingBits.clear(index);
  }

  public void setReverseSort(int index)
  {
    checkLocked();
    orderingBits.set(index);
  }

  public int size()
  {
    return comparatorChain.size();
  }

  public boolean isLocked()
  {
    return isLocked;
  }

  private void checkLocked()
  {
    if (isLocked == true)
      throw new UnsupportedOperationException("Comparator ordering cannot be changed after the first comparison is performed");
  }

  private void checkChainIntegrity()
  {
    if (comparatorChain.size() == 0)
      throw new UnsupportedOperationException("ComparatorChains must contain at least one Comparator");
  }

  public int compare(Object o1, Object o2)
    throws UnsupportedOperationException
  {
    if (!isLocked) {
      checkChainIntegrity();
      isLocked = true;
    }

    Iterator comparators = comparatorChain.iterator();
    for (int comparatorIndex = 0; comparators.hasNext(); comparatorIndex++)
    {
      Comparator comparator = (Serializable)comparators.next();
      int retval = comparator.compare(o1, o2);
      if (retval == 0)
        continue;
      if (orderingBits.get(comparatorIndex) == true) {
        if (-2147483648 == retval)
          retval = 2147483647;
        else {
          retval *= -1;
        }
      }

      return retval;
    }

    return 0;
  }

  public int hashCode()
  {
    int hash = 0;
    if (null != comparatorChain) {
      hash ^= comparatorChain.hashCode();
    }
    if (null != orderingBits) {
      hash ^= orderingBits.hashCode();
    }
    return hash;
  }

  public boolean equals(Object object)
  {
    if (this == object)
      return true;
    if (null == object)
      return false;
    if (object.getClass().equals(getClass())) {
      ComparatorChain chain = (ComparatorChain)object;
      if ((null == orderingBits ? false : null == chain.orderingBits ? true : orderingBits.equals(chain.orderingBits)));
      return (null == comparatorChain ? false : null == chain.comparatorChain ? true : comparatorChain.equals(chain.comparatorChain));
    }

    return false;
  }
}