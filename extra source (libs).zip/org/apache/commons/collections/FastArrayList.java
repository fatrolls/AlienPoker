package org.apache.commons.collections;

import java.util.AbstractCollection;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class FastArrayList extends ArrayList
{
  protected ArrayList list = null;

  protected boolean fast = false;

  public FastArrayList()
  {
    list = new ArrayList();
  }

  public FastArrayList(int capacity)
  {
    list = new ArrayList(capacity);
  }

  public FastArrayList(Collection collection)
  {
    list = new ArrayList(collection);
  }

  public boolean getFast()
  {
    return fast;
  }

  public void setFast(boolean fast)
  {
    this.fast = fast;
  }

  public boolean add(Object element)
  {
    ArrayList temp;
    if (fast) {
      synchronized (this) {
        temp = (ArrayList)list.clone();
        boolean result = temp.add(element);
        list = temp;
        return result;
      }
    }
    synchronized (list) {
      return list.add(element);
    }
  }

  public void add(int index, Object element)
  {
    if (fast) {
      synchronized (this) {
        ArrayList temp = (ArrayList)list.clone();
        temp.add(index, element);
        list = temp;
      }
    }
    synchronized (list) {
      list.add(index, element);
    }
  }

  public boolean addAll(Collection collection)
  {
    ArrayList temp;
    if (fast) {
      synchronized (this) {
        temp = (ArrayList)list.clone();
        boolean result = temp.addAll(collection);
        list = temp;
        return result;
      }
    }
    synchronized (list) {
      return list.addAll(collection);
    }
  }

  public boolean addAll(int index, Collection collection)
  {
    ArrayList temp;
    if (fast) {
      synchronized (this) {
        temp = (ArrayList)list.clone();
        boolean result = temp.addAll(index, collection);
        list = temp;
        return result;
      }
    }
    synchronized (list) {
      return list.addAll(index, collection);
    }
  }

  public void clear()
  {
    if (fast) {
      synchronized (this) {
        ArrayList temp = (ArrayList)list.clone();
        temp.clear();
        list = temp;
      }
    }
    synchronized (list) {
      list.clear();
    }
  }

  public Object clone()
  {
    FastArrayList results = null;
    if (fast)
      results = new FastArrayList(list);
    else {
      synchronized (list) {
        results = new FastArrayList(list);
      }
    }
    results.setFast(getFast());
    return results;
  }

  public boolean contains(Object element)
  {
    if (fast) {
      return list.contains(element);
    }
    synchronized (list) {
      return list.contains(element);
    }
  }

  public boolean containsAll(Collection collection)
  {
    if (fast) {
      return list.containsAll(collection);
    }
    synchronized (list) {
      return list.containsAll(collection);
    }
  }

  public void ensureCapacity(int capacity)
  {
    if (fast) {
      synchronized (this) {
        ArrayList temp = (ArrayList)list.clone();
        temp.ensureCapacity(capacity);
        list = temp;
      }
    }
    synchronized (list) {
      list.ensureCapacity(capacity);
    }
  }

  public boolean equals(Object o)
  {
    if (o == this)
      return true;
    if (!(o instanceof List))
      return false;
    List lo = (List)o;

    if (fast) {
      ??? = list.listIterator();
      ListIterator li2 = lo.listIterator();
      while ((???.hasNext()) && (li2.hasNext())) {
        Object o1 = ???.next();
        Object o2 = li2.next();
        if (!(o1 == null ? false : o2 == null ? true : o1.equals(o2)))
          return false;
      }
      return (!???.hasNext()) && (!li2.hasNext());
    }
    synchronized (list) {
      ListIterator li1 = list.listIterator();
      ListIterator li2 = lo.listIterator();
      Object o1;
      while ((li1.hasNext()) && (li2.hasNext())) {
        o1 = li1.next();
        Object o2 = li2.next();
        if (!(o1 == null ? false : o2 == null ? true : o1.equals(o2)))
          return 0;
      }
      return (!li1.hasNext()) && (!li2.hasNext()) ? 1 : 0;
    }
  }

  public Object get(int index)
  {
    if (fast) {
      return list.get(index);
    }
    synchronized (list) {
      return list.get(index);
    }
  }

  public int hashCode()
  {
    if (fast) {
      ??? = 1;
      Iterator i = list.iterator();
      while (i.hasNext()) {
        Object o = i.next();
        ??? = 31 * ??? + (o == null ? 0 : o.hashCode());
      }
      return ???;
    }
    synchronized (list) {
      int hashCode = 1;
      Iterator i = list.iterator();
      Object o;
      while (i.hasNext()) {
        o = i.next();
        hashCode = 31 * hashCode + (o == null ? 0 : o.hashCode());
      }
      return hashCode;
    }
  }

  public int indexOf(Object element)
  {
    if (fast) {
      return list.indexOf(element);
    }
    synchronized (list) {
      return list.indexOf(element);
    }
  }

  public boolean isEmpty()
  {
    if (fast) {
      return list.isEmpty();
    }
    synchronized (list) {
      return list.isEmpty();
    }
  }

  public Iterator iterator()
  {
    if (fast) {
      return new ListIter(0);
    }
    return list.iterator();
  }

  public int lastIndexOf(Object element)
  {
    if (fast) {
      return list.lastIndexOf(element);
    }
    synchronized (list) {
      return list.lastIndexOf(element);
    }
  }

  public ListIterator listIterator()
  {
    if (fast) {
      return new ListIter(0);
    }
    return list.listIterator();
  }

  public ListIterator listIterator(int index)
  {
    if (fast) {
      return new ListIter(index);
    }
    return list.listIterator(index);
  }

  public Object remove(int index)
  {
    ArrayList temp;
    if (fast) {
      synchronized (this) {
        temp = (ArrayList)list.clone();
        Object result = temp.remove(index);
        list = temp;
        return result;
      }
    }
    synchronized (list) {
      return list.remove(index);
    }
  }

  public boolean remove(Object element)
  {
    ArrayList temp;
    if (fast) {
      synchronized (this) {
        temp = (ArrayList)list.clone();
        boolean result = temp.remove(element);
        list = temp;
        return result;
      }
    }
    synchronized (list) {
      return list.remove(element);
    }
  }

  public boolean removeAll(Collection collection)
  {
    ArrayList temp;
    if (fast) {
      synchronized (this) {
        temp = (ArrayList)list.clone();
        boolean result = temp.removeAll(collection);
        list = temp;
        return result;
      }
    }
    synchronized (list) {
      return list.removeAll(collection);
    }
  }

  public boolean retainAll(Collection collection)
  {
    ArrayList temp;
    if (fast) {
      synchronized (this) {
        temp = (ArrayList)list.clone();
        boolean result = temp.retainAll(collection);
        list = temp;
        return result;
      }
    }
    synchronized (list) {
      return list.retainAll(collection);
    }
  }

  public Object set(int index, Object element)
  {
    if (fast) {
      return list.set(index, element);
    }
    synchronized (list) {
      return list.set(index, element);
    }
  }

  public int size()
  {
    if (fast) {
      return list.size();
    }
    synchronized (list) {
      return list.size();
    }
  }

  public List subList(int fromIndex, int toIndex)
  {
    if (fast) {
      return new SubList(fromIndex, toIndex);
    }
    return list.subList(fromIndex, toIndex);
  }

  public Object[] toArray()
  {
    if (fast) {
      return list.toArray();
    }
    synchronized (list) {
      return list.toArray();
    }
  }

  public Object[] toArray(Object[] array)
  {
    if (fast) {
      return list.toArray(array);
    }
    synchronized (list) {
      return list.toArray(array);
    }
  }

  public String toString()
  {
    StringBuffer sb = new StringBuffer("FastArrayList[");
    sb.append(list.toString());
    sb.append("]");
    return sb.toString();
  }

  public void trimToSize()
  {
    if (fast) {
      synchronized (this) {
        ArrayList temp = (ArrayList)list.clone();
        temp.trimToSize();
        list = temp;
      }
    }
    synchronized (list) {
      list.trimToSize();
    }
  }

  private class ListIter
    implements ListIterator
  {
    private List expected;
    private ListIterator iter;
    private int lastReturnedIndex = -1;

    public ListIter(int i)
    {
      expected = list;
      iter = get().listIterator(i);
    }

    private void checkMod() {
      if (list != expected)
        throw new ConcurrentModificationException();
    }

    List get()
    {
      return expected;
    }

    public boolean hasNext() {
      checkMod();
      return iter.hasNext();
    }

    public Object next() {
      checkMod();
      lastReturnedIndex = iter.nextIndex();
      return iter.next();
    }

    public boolean hasPrevious() {
      checkMod();
      return iter.hasPrevious();
    }

    public Object previous() {
      checkMod();
      lastReturnedIndex = iter.previousIndex();
      return iter.previous();
    }

    public int previousIndex() {
      checkMod();
      return iter.previousIndex();
    }

    public int nextIndex() {
      checkMod();
      return iter.nextIndex();
    }

    public void remove() {
      checkMod();
      if (lastReturnedIndex < 0) {
        throw new IllegalStateException();
      }
      get().remove(lastReturnedIndex);
      expected = list;
      iter = get().listIterator(previousIndex());
      lastReturnedIndex = -1;
    }

    public void set(Object o) {
      checkMod();
      if (lastReturnedIndex < 0) {
        throw new IllegalStateException();
      }
      get().set(lastReturnedIndex, o);
      expected = list;
      iter = get().listIterator(previousIndex() + 1);
    }

    public void add(Object o) {
      checkMod();
      int i = nextIndex();
      get().add(i, o);
      iter = get().listIterator(i + 1);
      lastReturnedIndex = -1;
    }
  }

  private class SubList
    implements List
  {
    private int first;
    private int last;
    private List expected;

    public SubList(int first, int last)
    {
      this.first = first;
      this.last = last;
      expected = list;
    }

    private List get(List l) {
      if (list != expected) {
        throw new ConcurrentModificationException();
      }
      return l.subList(first, last);
    }

    public void clear() {
      if (fast) {
        synchronized (FastArrayList.this) {
          ArrayList temp = (ArrayList)list.clone();
          get(temp).clear();
          last = first;
          list = temp;
          expected = temp;
        }
      }
      synchronized (list) {
        get(expected).clear();
      }
    }

    public boolean remove(Object o)
    {
      ArrayList temp;
      if (fast) {
        synchronized (FastArrayList.this) {
          temp = (ArrayList)list.clone();
          boolean r = get(temp).remove(o);
          if (r) last -= 1;
          list = temp;
          expected = temp;
          return r;
        }
      }
      synchronized (list) {
        return get(expected).remove(o);
      }
    }

    public boolean removeAll(Collection o)
    {
      ArrayList temp;
      if (fast) {
        synchronized (FastArrayList.this) {
          temp = (ArrayList)list.clone();
          List sub = get(temp);
          boolean r = sub.removeAll(o);
          if (r) last = (first + sub.size());
          list = temp;
          expected = temp;
          return r;
        }
      }
      synchronized (list) {
        return get(expected).removeAll(o);
      }
    }

    public boolean retainAll(Collection o)
    {
      ArrayList temp;
      if (fast) {
        synchronized (FastArrayList.this) {
          temp = (ArrayList)list.clone();
          List sub = get(temp);
          boolean r = sub.retainAll(o);
          if (r) last = (first + sub.size());
          list = temp;
          expected = temp;
          return r;
        }
      }
      synchronized (list) {
        return get(expected).retainAll(o);
      }
    }

    public int size()
    {
      if (fast) {
        return get(expected).size();
      }
      synchronized (list) {
        return get(expected).size();
      }
    }

    public boolean isEmpty()
    {
      if (fast) {
        return get(expected).isEmpty();
      }
      synchronized (list) {
        return get(expected).isEmpty();
      }
    }

    public boolean contains(Object o)
    {
      if (fast) {
        return get(expected).contains(o);
      }
      synchronized (list) {
        return get(expected).contains(o);
      }
    }

    public boolean containsAll(Collection o)
    {
      if (fast) {
        return get(expected).containsAll(o);
      }
      synchronized (list) {
        return get(expected).containsAll(o);
      }
    }

    public Object[] toArray(Object[] o)
    {
      if (fast) {
        return get(expected).toArray(o);
      }
      synchronized (list) {
        return get(expected).toArray(o);
      }
    }

    public Object[] toArray()
    {
      if (fast) {
        return get(expected).toArray();
      }
      synchronized (list) {
        return get(expected).toArray();
      }
    }

    public boolean equals(Object o)
    {
      if (o == this) return true;
      if (fast) {
        return get(expected).equals(o);
      }
      synchronized (list) {
        return get(expected).equals(o);
      }
    }

    public int hashCode()
    {
      if (fast) {
        return get(expected).hashCode();
      }
      synchronized (list) {
        return get(expected).hashCode();
      }
    }

    public boolean add(Object o)
    {
      ArrayList temp;
      if (fast) {
        synchronized (FastArrayList.this) {
          temp = (ArrayList)list.clone();
          boolean r = get(temp).add(o);
          if (r) last += 1;
          list = temp;
          expected = temp;
          return r;
        }
      }
      synchronized (list) {
        return get(expected).add(o);
      }
    }

    public boolean addAll(Collection o)
    {
      ArrayList temp;
      if (fast) {
        synchronized (FastArrayList.this) {
          temp = (ArrayList)list.clone();
          boolean r = get(temp).addAll(o);
          if (r) last += o.size();
          list = temp;
          expected = temp;
          return r;
        }
      }
      synchronized (list) {
        return get(expected).addAll(o);
      }
    }

    public void add(int i, Object o)
    {
      if (fast) {
        synchronized (FastArrayList.this) {
          ArrayList temp = (ArrayList)list.clone();
          get(temp).add(i, o);
          last += 1;
          list = temp;
          expected = temp;
        }
      }
      synchronized (list) {
        get(expected).add(i, o);
      }
    }

    public boolean addAll(int i, Collection o)
    {
      ArrayList temp;
      if (fast) {
        synchronized (FastArrayList.this) {
          temp = (ArrayList)list.clone();
          boolean r = get(temp).addAll(i, o);
          list = temp;
          if (r) last += o.size();
          expected = temp;
          return r;
        }
      }
      synchronized (list) {
        return get(expected).addAll(i, o);
      }
    }

    public Object remove(int i)
    {
      ArrayList temp;
      if (fast) {
        synchronized (FastArrayList.this) {
          temp = (ArrayList)list.clone();
          Object o = get(temp).remove(i);
          last -= 1;
          list = temp;
          expected = temp;
          return o;
        }
      }
      synchronized (list) {
        return get(expected).remove(i);
      }
    }

    public Object set(int i, Object a)
    {
      ArrayList temp;
      if (fast) {
        synchronized (FastArrayList.this) {
          temp = (ArrayList)list.clone();
          Object o = get(temp).set(i, a);
          list = temp;
          expected = temp;
          return o;
        }
      }
      synchronized (list) {
        return get(expected).set(i, a);
      }
    }

    public Iterator iterator()
    {
      return new SubListIter(0);
    }

    public ListIterator listIterator() {
      return new SubListIter(0);
    }

    public ListIterator listIterator(int i) {
      return new SubListIter(i);
    }

    public Object get(int i)
    {
      if (fast) {
        return get(expected).get(i);
      }
      synchronized (list) {
        return get(expected).get(i);
      }
    }

    public int indexOf(Object o)
    {
      if (fast) {
        return get(expected).indexOf(o);
      }
      synchronized (list) {
        return get(expected).indexOf(o);
      }
    }

    public int lastIndexOf(Object o)
    {
      if (fast) {
        return get(expected).lastIndexOf(o);
      }
      synchronized (list) {
        return get(expected).lastIndexOf(o);
      }
    }

    public List subList(int f, int l)
    {
      if (list != expected) {
        throw new ConcurrentModificationException();
      }
      return new SubList(FastArrayList.this, first + f, f + l);
    }

    private class SubListIter
      implements ListIterator
    {
      private List expected;
      private ListIterator iter;
      private int lastReturnedIndex = -1;

      public SubListIter(int i)
      {
        expected = list;
        iter = FastArrayList.SubList.this.get(expected).listIterator(i);
      }

      private void checkMod() {
        if (list != expected)
          throw new ConcurrentModificationException();
      }

      List get()
      {
        return FastArrayList.SubList.this.get(expected);
      }

      public boolean hasNext() {
        checkMod();
        return iter.hasNext();
      }

      public Object next() {
        checkMod();
        lastReturnedIndex = iter.nextIndex();
        return iter.next();
      }

      public boolean hasPrevious() {
        checkMod();
        return iter.hasPrevious();
      }

      public Object previous() {
        checkMod();
        lastReturnedIndex = iter.previousIndex();
        return iter.previous();
      }

      public int previousIndex() {
        checkMod();
        return iter.previousIndex();
      }

      public int nextIndex() {
        checkMod();
        return iter.nextIndex();
      }

      public void remove() {
        checkMod();
        if (lastReturnedIndex < 0) {
          throw new IllegalStateException();
        }
        get().remove(lastReturnedIndex);
        FastArrayList.SubList.access$210(FastArrayList.SubList.this);
        expected = list;
        iter = get().listIterator(previousIndex());
        lastReturnedIndex = -1;
      }

      public void set(Object o) {
        checkMod();
        if (lastReturnedIndex < 0) {
          throw new IllegalStateException();
        }
        get().set(lastReturnedIndex, o);
        expected = list;
        iter = get().listIterator(previousIndex() + 1);
      }

      public void add(Object o) {
        checkMod();
        int i = nextIndex();
        get().add(i, o);
        FastArrayList.SubList.access$208(FastArrayList.SubList.this);
        iter = get().listIterator(i + 1);
        lastReturnedIndex = 1;
      }
    }
  }
}