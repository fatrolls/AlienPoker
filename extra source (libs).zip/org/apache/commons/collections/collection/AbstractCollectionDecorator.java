package org.apache.commons.collections.collection;

import java.util.Collection;
import java.util.Iterator;

public abstract class AbstractCollectionDecorator
  implements Collection
{
  protected Collection collection;

  protected AbstractCollectionDecorator()
  {
  }

  protected AbstractCollectionDecorator(Collection coll)
  {
    if (coll == null) {
      throw new IllegalArgumentException("Collection must not be null");
    }
    collection = coll;
  }

  protected Collection getCollection()
  {
    return collection;
  }

  public boolean add(Object object)
  {
    return collection.add(object);
  }

  public boolean addAll(Collection coll) {
    return collection.addAll(coll);
  }

  public void clear() {
    collection.clear();
  }

  public boolean contains(Object object) {
    return collection.contains(object);
  }

  public boolean isEmpty() {
    return collection.isEmpty();
  }

  public Iterator iterator() {
    return collection.iterator();
  }

  public boolean remove(Object object) {
    return collection.remove(object);
  }

  public int size() {
    return collection.size();
  }

  public Object[] toArray() {
    return collection.toArray();
  }

  public Object[] toArray(Object[] object) {
    return collection.toArray(object);
  }

  public boolean containsAll(Collection coll) {
    return collection.containsAll(coll);
  }

  public boolean removeAll(Collection coll) {
    return collection.removeAll(coll);
  }

  public boolean retainAll(Collection coll) {
    return collection.retainAll(coll);
  }

  public boolean equals(Object object) {
    if (object == this) {
      return true;
    }
    return collection.equals(object);
  }

  public int hashCode() {
    return collection.hashCode();
  }

  public String toString() {
    return collection.toString();
  }
}