package org.apache.commons.collections.collection;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;

public class SynchronizedCollection
  implements Collection, Serializable
{
  private static final long serialVersionUID = 2412805092710877986L;
  protected final Collection collection;
  protected final Object lock;

  public static Collection decorate(Collection coll)
  {
    return new SynchronizedCollection(coll);
  }

  protected SynchronizedCollection(Collection collection)
  {
    if (collection == null) {
      throw new IllegalArgumentException("Collection must not be null");
    }
    this.collection = collection;
    lock = this;
  }

  protected SynchronizedCollection(Collection collection, Object lock)
  {
    if (collection == null) {
      throw new IllegalArgumentException("Collection must not be null");
    }
    this.collection = collection;
    this.lock = lock;
  }

  public boolean add(Object object)
  {
    synchronized (lock) {
      return collection.add(object);
    }
  }

  public boolean addAll(Collection coll) {
    synchronized (lock) {
      return collection.addAll(coll);
    }
  }

  public void clear() {
    synchronized (lock) {
      collection.clear();
    }
  }

  public boolean contains(Object object) {
    synchronized (lock) {
      return collection.contains(object);
    }
  }

  public boolean containsAll(Collection coll) {
    synchronized (lock) {
      return collection.containsAll(coll);
    }
  }

  public boolean isEmpty() {
    synchronized (lock) {
      return collection.isEmpty();
    }
  }

  public Iterator iterator()
  {
    return collection.iterator();
  }

  public Object[] toArray() {
    synchronized (lock) {
      return collection.toArray();
    }
  }

  public Object[] toArray(Object[] object) {
    synchronized (lock) {
      return collection.toArray(object);
    }
  }

  public boolean remove(Object object) {
    synchronized (lock) {
      return collection.remove(object);
    }
  }

  public boolean removeAll(Collection coll) {
    synchronized (lock) {
      return collection.removeAll(coll);
    }
  }

  public boolean retainAll(Collection coll) {
    synchronized (lock) {
      return collection.retainAll(coll);
    }
  }

  public int size() {
    synchronized (lock) {
      return collection.size();
    }
  }

  public boolean equals(Object object) {
    synchronized (lock)
    {
      boolean bool;
      if (object == this) {
        return true;
      }
      return collection.equals(object);
    }
  }

  public int hashCode() {
    synchronized (lock) {
      return collection.hashCode();
    }
  }

  public String toString() {
    synchronized (lock) {
      return collection.toString();
    }
  }
}