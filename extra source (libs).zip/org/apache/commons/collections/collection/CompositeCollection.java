package org.apache.commons.collections.collection;

import java.lang.reflect.Array;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import org.apache.commons.collections.iterators.EmptyIterator;
import org.apache.commons.collections.iterators.IteratorChain;
import org.apache.commons.collections.list.UnmodifiableList;

public class CompositeCollection
  implements Collection
{
  protected CollectionMutator mutator;
  protected Collection[] all;

  public CompositeCollection()
  {
    all = new Collection[0];
  }

  public CompositeCollection(Collection coll)
  {
    this();
    addComposited(coll);
  }

  public CompositeCollection(Collection[] colls)
  {
    this();
    addComposited(colls);
  }

  public int size()
  {
    int size = 0;
    for (int i = all.length - 1; i >= 0; i--) {
      size += all[i].size();
    }
    return size;
  }

  public boolean isEmpty()
  {
    for (int i = all.length - 1; i >= 0; i--) {
      if (!all[i].isEmpty()) {
        return false;
      }
    }
    return true;
  }

  public boolean contains(Object obj)
  {
    for (int i = all.length - 1; i >= 0; i--) {
      if (all[i].contains(obj)) {
        return true;
      }
    }
    return false;
  }

  public Iterator iterator()
  {
    if (all.length == 0) {
      return EmptyIterator.INSTANCE;
    }
    IteratorChain chain = new IteratorChain();
    for (int i = 0; i < all.length; i++) {
      chain.addIterator(all[i].iterator());
    }
    return chain;
  }

  public Object[] toArray()
  {
    Object[] result = new Object[size()];
    int i = 0;
    for (Iterator it = iterator(); it.hasNext(); i++) {
      result[i] = it.next();
    }
    return result;
  }

  public Object[] toArray(Object[] array)
  {
    int size = size();
    Object[] result = null;
    if (array.length >= size) {
      result = array;
    }
    else {
      result = (Object[])Array.newInstance(array.getClass().getComponentType(), size);
    }

    int offset = 0;
    for (int i = 0; i < all.length; i++) {
      for (Iterator it = all[i].iterator(); it.hasNext(); ) {
        result[(offset++)] = it.next();
      }
    }
    if (result.length > size) {
      result[size] = null;
    }
    return result;
  }

  public boolean add(Object obj)
  {
    if (mutator == null) {
      throw new UnsupportedOperationException("add() is not supported on CompositeCollection without a CollectionMutator strategy");
    }

    return mutator.add(this, all, obj);
  }

  public boolean remove(Object obj)
  {
    if (mutator == null) {
      throw new UnsupportedOperationException("remove() is not supported on CompositeCollection without a CollectionMutator strategy");
    }

    return mutator.remove(this, all, obj);
  }

  public boolean containsAll(Collection coll)
  {
    for (Iterator it = coll.iterator(); it.hasNext(); ) {
      if (!contains(it.next())) {
        return false;
      }
    }
    return true;
  }

  public boolean addAll(Collection coll)
  {
    if (mutator == null) {
      throw new UnsupportedOperationException("addAll() is not supported on CompositeCollection without a CollectionMutator strategy");
    }

    return mutator.addAll(this, all, coll);
  }

  public boolean removeAll(Collection coll)
  {
    if (coll.size() == 0) {
      return false;
    }
    boolean changed = false;
    for (int i = all.length - 1; i >= 0; i--) {
      changed = (all[i].removeAll(coll)) || (changed);
    }
    return changed;
  }

  public boolean retainAll(Collection coll)
  {
    boolean changed = false;
    for (int i = all.length - 1; i >= 0; i--) {
      changed = (all[i].retainAll(coll)) || (changed);
    }
    return changed;
  }

  public void clear()
  {
    for (int i = 0; i < all.length; i++)
      all[i].clear();
  }

  public void setMutator(CollectionMutator mutator)
  {
    this.mutator = mutator;
  }

  public void addComposited(Collection[] comps)
  {
    ArrayList list = new ArrayList(Arrays.asList(all));
    list.addAll(Arrays.asList(comps));
    all = ((Collection[])list.toArray(new Collection[list.size()]));
  }

  public void addComposited(Collection c)
  {
    addComposited(new Collection[] { c });
  }

  public void addComposited(Collection c, Collection d)
  {
    addComposited(new Collection[] { c, d });
  }

  public void removeComposited(Collection coll)
  {
    ArrayList list = new ArrayList(all.length);
    list.addAll(Arrays.asList(all));
    list.remove(coll);
    all = ((Collection[])list.toArray(new Collection[list.size()]));
  }

  public Collection toCollection()
  {
    return new ArrayList(this);
  }

  public Collection getCollections()
  {
    return UnmodifiableList.decorate(Arrays.asList(all));
  }

  public static abstract interface CollectionMutator
  {
    public abstract boolean add(CompositeCollection paramCompositeCollection, Collection[] paramArrayOfCollection, Object paramObject);

    public abstract boolean addAll(CompositeCollection paramCompositeCollection, Collection[] paramArrayOfCollection, Collection paramCollection);

    public abstract boolean remove(CompositeCollection paramCompositeCollection, Collection[] paramArrayOfCollection, Object paramObject);
  }
}