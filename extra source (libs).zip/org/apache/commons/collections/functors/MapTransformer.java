package org.apache.commons.collections.functors;

import java.io.Serializable;
import java.util.Map;
import org.apache.commons.collections.Transformer;

public final class MapTransformer
  implements Transformer, Serializable
{
  static final long serialVersionUID = 862391807045468939L;
  private final Map iMap;

  public static Transformer getInstance(Map map)
  {
    if (map == null) {
      return ConstantTransformer.NULL_INSTANCE;
    }
    return new MapTransformer(map);
  }

  private MapTransformer(Map map)
  {
    iMap = map;
  }

  public Object transform(Object input)
  {
    return iMap.get(input);
  }

  public Map getMap()
  {
    return iMap;
  }
}