package org.apache.commons.collections.functors;

import java.io.Serializable;
import org.apache.commons.collections.Factory;

public class ConstantFactory
  implements Factory, Serializable
{
  static final long serialVersionUID = -3520677225766901240L;
  public static final Factory NULL_INSTANCE = new ConstantFactory(null);
  private final Object iConstant;

  public static Factory getInstance(Object constantToReturn)
  {
    if (constantToReturn == null) {
      return NULL_INSTANCE;
    }
    return new ConstantFactory(constantToReturn);
  }

  public ConstantFactory(Object constantToReturn)
  {
    iConstant = constantToReturn;
  }

  public Object create()
  {
    return iConstant;
  }

  public Object getConstant()
  {
    return iConstant;
  }
}