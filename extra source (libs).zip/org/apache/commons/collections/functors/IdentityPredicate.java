package org.apache.commons.collections.functors;

import java.io.Serializable;
import org.apache.commons.collections.Predicate;

public final class IdentityPredicate
  implements Predicate, Serializable
{
  static final long serialVersionUID = -89901658494523293L;
  private final Object iValue;

  public static Predicate getInstance(Object object)
  {
    if (object == null) {
      return NullPredicate.INSTANCE;
    }
    return new IdentityPredicate(object);
  }

  public IdentityPredicate(Object object)
  {
    iValue = object;
  }

  public boolean evaluate(Object object)
  {
    return iValue == object;
  }

  public Object getValue()
  {
    return iValue;
  }
}