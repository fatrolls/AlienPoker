package org.apache.commons.collections.functors;

import java.io.Serializable;
import org.apache.commons.collections.Predicate;

public final class EqualPredicate
  implements Predicate, Serializable
{
  static final long serialVersionUID = 5633766978029907089L;
  private final Object iValue;

  public static Predicate getInstance(Object object)
  {
    if (object == null) {
      return NullPredicate.INSTANCE;
    }
    return new EqualPredicate(object);
  }

  public EqualPredicate(Object object)
  {
    iValue = object;
  }

  public boolean evaluate(Object object)
  {
    return iValue.equals(object);
  }

  public Object getValue()
  {
    return iValue;
  }
}