package org.apache.commons.collections.functors;

import org.apache.commons.collections.Predicate;

public abstract interface PredicateDecorator extends Predicate
{
  public abstract Predicate[] getPredicates();
}