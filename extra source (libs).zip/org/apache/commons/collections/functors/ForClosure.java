package org.apache.commons.collections.functors;

import java.io.Serializable;
import org.apache.commons.collections.Closure;

public class ForClosure
  implements Closure, Serializable
{
  static final long serialVersionUID = -1190120533393621674L;
  private final int iCount;
  private final Closure iClosure;

  public static Closure getInstance(int count, Closure closure)
  {
    if ((count <= 0) || (closure == null)) {
      return NOPClosure.INSTANCE;
    }
    if (count == 1) {
      return closure;
    }
    return new ForClosure(count, closure);
  }

  public ForClosure(int count, Closure closure)
  {
    iCount = count;
    iClosure = closure;
  }

  public void execute(Object input)
  {
    for (int i = 0; i < iCount; i++)
      iClosure.execute(input);
  }

  public Closure getClosure()
  {
    return iClosure;
  }

  public int getCount()
  {
    return iCount;
  }
}