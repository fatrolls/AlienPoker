package org.apache.commons.collections.functors;

import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.collections.Factory;
import org.apache.commons.collections.FunctorException;

public class InstantiateFactory
  implements Factory, Serializable
{
  static final long serialVersionUID = -7732226881069447957L;
  private final Class iClassToInstantiate;
  private final Class[] iParamTypes;
  private final Object[] iArgs;
  private transient Constructor iConstructor = null;

  public static Factory getInstance(Class classToInstantiate, Class[] paramTypes, Object[] args)
  {
    if (classToInstantiate == null) {
      throw new IllegalArgumentException("Class to instantiate must not be null");
    }
    if (((paramTypes == null) && (args != null)) || ((paramTypes != null) && (args == null)) || ((paramTypes != null) && (args != null) && (paramTypes.length != args.length)))
    {
      throw new IllegalArgumentException("Parameter types must match the arguments");
    }

    if ((paramTypes == null) || (paramTypes.length == 0)) {
      return new InstantiateFactory(classToInstantiate);
    }
    paramTypes = (Class[])paramTypes.clone();
    args = (Object[])args.clone();
    return new InstantiateFactory(classToInstantiate, paramTypes, args);
  }

  public InstantiateFactory(Class classToInstantiate)
  {
    iClassToInstantiate = classToInstantiate;
    iParamTypes = null;
    iArgs = null;
    findConstructor();
  }

  public InstantiateFactory(Class classToInstantiate, Class[] paramTypes, Object[] args)
  {
    iClassToInstantiate = classToInstantiate;
    iParamTypes = paramTypes;
    iArgs = args;
    findConstructor();
  }

  private void findConstructor()
  {
    try
    {
      iConstructor = iClassToInstantiate.getConstructor(iParamTypes);
    }
    catch (NoSuchMethodException ex) {
      throw new IllegalArgumentException("InstantiateFactory: The constructor must exist and be public ");
    }
  }

  public Object create()
  {
    if (iConstructor == null) {
      findConstructor();
    }
    try
    {
      return iConstructor.newInstance(iArgs);
    }
    catch (InstantiationException ex) {
      throw new FunctorException("InstantiateFactory: InstantiationException", ex);
    } catch (IllegalAccessException ex) {
      throw new FunctorException("InstantiateFactory: Constructor must be public", ex); } catch (InvocationTargetException ex) {
    }
    throw new FunctorException("InstantiateFactory: Constructor threw an exception", ex);
  }
}