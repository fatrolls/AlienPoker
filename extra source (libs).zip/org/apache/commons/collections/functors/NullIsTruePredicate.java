package org.apache.commons.collections.functors;

import java.io.Serializable;
import org.apache.commons.collections.Predicate;

public final class NullIsTruePredicate
  implements Predicate, PredicateDecorator, Serializable
{
  static final long serialVersionUID = -7625133768987126273L;
  private final Predicate iPredicate;

  public static Predicate getInstance(Predicate predicate)
  {
    if (predicate == null) {
      throw new IllegalArgumentException("Predicate must not be null");
    }
    return new NullIsTruePredicate(predicate);
  }

  public NullIsTruePredicate(Predicate predicate)
  {
    iPredicate = predicate;
  }

  public boolean evaluate(Object object)
  {
    if (object == null) {
      return true;
    }
    return iPredicate.evaluate(object);
  }

  public Predicate[] getPredicates()
  {
    return new Serializable[] { iPredicate };
  }
}