package org.apache.commons.collections.functors;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.apache.commons.collections.Factory;
import org.apache.commons.collections.FunctorException;

public class PrototypeFactory
{
  public static Factory getInstance(Object prototype)
  {
    if (prototype == null)
      return ConstantFactory.NULL_INSTANCE;
    try
    {
      Method method = prototype.getClass().getMethod("clone", null);
      return new PrototypeCloneFactory(prototype, method, null);
    }
    catch (NoSuchMethodException ex) {
      try {
        prototype.getClass().getConstructor(new Class[] { prototype.getClass() });
        return new InstantiateFactory(prototype.getClass(), new Class[] { prototype.getClass() }, new Object[] { prototype });
      }
      catch (NoSuchMethodException ex2)
      {
        if ((prototype instanceof Serializable)) {
          return new PrototypeSerializationFactory((Serializable)prototype, null);
        }
      }
    }
    throw new IllegalArgumentException("The prototype must be cloneable via a public clone method");
  }

  static class PrototypeSerializationFactory
    implements Factory, Serializable
  {
    static final long serialVersionUID = -8704966966139178833L;
    private final Serializable iPrototype;

    private PrototypeSerializationFactory(Serializable prototype)
    {
      iPrototype = prototype;
    }

    public Object create()
    {
      ByteArrayOutputStream baos = new ByteArrayOutputStream(512);
      ByteArrayInputStream bais = null;
      try {
        ObjectOutputStream out = new ObjectOutputStream(baos);
        out.writeObject(iPrototype);

        bais = new ByteArrayInputStream(baos.toByteArray());
        ObjectInputStream in = new ObjectInputStream(bais);
        localObject1 = in.readObject();
      }
      catch (ClassNotFoundException ex)
      {
        Object localObject1;
        throw new FunctorException(ex);
      } catch (IOException ex) {
        throw new FunctorException(ex);
      } finally {
        try {
          if (bais != null)
            bais.close();
        }
        catch (IOException ex)
        {
        }
        try {
          if (baos != null)
            baos.close();
        }
        catch (IOException ex)
        {
        }
      }
    }

    PrototypeSerializationFactory(Serializable x0, PrototypeFactory.1 x1)
    {
      this(x0);
    }
  }

  static class PrototypeCloneFactory
    implements Factory, Serializable
  {
    static final long serialVersionUID = 5604271422565175555L;
    private final Object iPrototype;
    private transient Method iCloneMethod;

    private PrototypeCloneFactory(Object prototype, Method method)
    {
      iPrototype = prototype;
      iCloneMethod = method;
    }

    private void findCloneMethod()
    {
      try
      {
        iCloneMethod = iPrototype.getClass().getMethod("clone", null);
      }
      catch (NoSuchMethodException ex) {
        throw new IllegalArgumentException("PrototypeCloneFactory: The clone method must exist and be public ");
      }
    }

    public Object create()
    {
      if (iCloneMethod == null) {
        findCloneMethod();
      }
      try
      {
        return iCloneMethod.invoke(iPrototype, null);
      }
      catch (IllegalAccessException ex) {
        throw new FunctorException("PrototypeCloneFactory: Clone method must be public", ex); } catch (InvocationTargetException ex) {
      }
      throw new FunctorException("PrototypeCloneFactory: Clone method threw an exception", ex);
    }

    PrototypeCloneFactory(Object x0, Method x1, PrototypeFactory.1 x2)
    {
      this(x0, x1);
    }
  }
}