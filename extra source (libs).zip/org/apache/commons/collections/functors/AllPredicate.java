package org.apache.commons.collections.functors;

import java.io.Serializable;
import java.util.Collection;
import org.apache.commons.collections.Predicate;

public final class AllPredicate
  implements Predicate, PredicateDecorator, Serializable
{
  static final long serialVersionUID = -3094696765038308799L;
  private final Predicate[] iPredicates;

  public static Predicate getInstance(Predicate[] predicates)
  {
    FunctorUtils.validateMin2(predicates);
    predicates = FunctorUtils.copy(predicates);
    return new AllPredicate(predicates);
  }

  public static Predicate getInstance(Collection predicates)
  {
    Predicate[] preds = FunctorUtils.validate(predicates);
    return new AllPredicate(preds);
  }

  public AllPredicate(Predicate[] predicates)
  {
    iPredicates = predicates;
  }

  public boolean evaluate(Object object)
  {
    for (int i = 0; i < iPredicates.length; i++) {
      if (!iPredicates[i].evaluate(object)) {
        return false;
      }
    }
    return true;
  }

  public Predicate[] getPredicates()
  {
    return iPredicates;
  }
}