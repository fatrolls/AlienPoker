package org.apache.commons.collections;

import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

class CursorableSubList extends CursorableLinkedList
  implements List
{
  protected CursorableLinkedList _list = null;

  protected CursorableLinkedList.Listable _pre = null;

  protected CursorableLinkedList.Listable _post = null;

  CursorableSubList(CursorableLinkedList list, int from, int to)
  {
    if ((0 > from) || (list.size() < to))
      throw new IndexOutOfBoundsException();
    if (from > to) {
      throw new IllegalArgumentException();
    }
    _list = list;
    if (from < list.size()) {
      _head.setNext(_list.getListableAt(from));
      _pre = (null == _head.next() ? null : _head.next().prev());
    } else {
      _pre = _list.getListableAt(from - 1);
    }
    if (from == to) {
      _head.setNext(null);
      _head.setPrev(null);
      if (to < list.size())
        _post = _list.getListableAt(to);
      else
        _post = null;
    }
    else {
      _head.setPrev(_list.getListableAt(to - 1));
      _post = _head.prev().next();
    }
    _size = (to - from);
    _modCount = _list._modCount;
  }

  public void clear()
  {
    checkForComod();
    Iterator it = iterator();
    while (it.hasNext()) {
      it.next();
      it.remove();
    }
  }

  public Iterator iterator() {
    checkForComod();
    return super.iterator();
  }

  public int size() {
    checkForComod();
    return super.size();
  }

  public boolean isEmpty() {
    checkForComod();
    return super.isEmpty();
  }

  public Object[] toArray() {
    checkForComod();
    return super.toArray();
  }

  public Object[] toArray(Object[] a) {
    checkForComod();
    return super.toArray(a);
  }

  public boolean contains(Object o) {
    checkForComod();
    return super.contains(o);
  }

  public boolean remove(Object o) {
    checkForComod();
    return super.remove(o);
  }

  public Object removeFirst() {
    checkForComod();
    return super.removeFirst();
  }

  public Object removeLast() {
    checkForComod();
    return super.removeLast();
  }

  public boolean addAll(Collection c) {
    checkForComod();
    return super.addAll(c);
  }

  public boolean add(Object o) {
    checkForComod();
    return super.add(o);
  }

  public boolean addFirst(Object o) {
    checkForComod();
    return super.addFirst(o);
  }

  public boolean addLast(Object o) {
    checkForComod();
    return super.addLast(o);
  }

  public boolean removeAll(Collection c) {
    checkForComod();
    return super.removeAll(c);
  }

  public boolean containsAll(Collection c) {
    checkForComod();
    return super.containsAll(c);
  }

  public boolean addAll(int index, Collection c) {
    checkForComod();
    return super.addAll(index, c);
  }

  public int hashCode() {
    checkForComod();
    return super.hashCode();
  }

  public boolean retainAll(Collection c) {
    checkForComod();
    return super.retainAll(c);
  }

  public Object set(int index, Object element) {
    checkForComod();
    return super.set(index, element);
  }

  public boolean equals(Object o) {
    checkForComod();
    return super.equals(o);
  }

  public Object get(int index) {
    checkForComod();
    return super.get(index);
  }

  public Object getFirst() {
    checkForComod();
    return super.getFirst();
  }

  public Object getLast() {
    checkForComod();
    return super.getLast();
  }

  public void add(int index, Object element) {
    checkForComod();
    super.add(index, element);
  }

  public ListIterator listIterator(int index) {
    checkForComod();
    return super.listIterator(index);
  }

  public Object remove(int index) {
    checkForComod();
    return super.remove(index);
  }

  public int indexOf(Object o) {
    checkForComod();
    return super.indexOf(o);
  }

  public int lastIndexOf(Object o) {
    checkForComod();
    return super.lastIndexOf(o);
  }

  public ListIterator listIterator() {
    checkForComod();
    return super.listIterator();
  }

  public List subList(int fromIndex, int toIndex) {
    checkForComod();
    return super.subList(fromIndex, toIndex);
  }

  protected CursorableLinkedList.Listable insertListable(CursorableLinkedList.Listable before, CursorableLinkedList.Listable after, Object value)
  {
    _modCount += 1;
    _size += 1;
    CursorableLinkedList.Listable elt = _list.insertListable(null == before ? _pre : before, null == after ? _post : after, value);
    if (null == _head.next()) {
      _head.setNext(elt);
      _head.setPrev(elt);
    }
    if (before == _head.prev()) {
      _head.setPrev(elt);
    }
    if (after == _head.next()) {
      _head.setNext(elt);
    }
    broadcastListableInserted(elt);
    return elt;
  }

  protected void removeListable(CursorableLinkedList.Listable elt)
  {
    _modCount += 1;
    _size -= 1;
    if ((_head.next() == elt) && (_head.prev() == elt)) {
      _head.setNext(null);
      _head.setPrev(null);
    }
    if (_head.next() == elt) {
      _head.setNext(elt.next());
    }
    if (_head.prev() == elt) {
      _head.setPrev(elt.prev());
    }
    _list.removeListable(elt);
    broadcastListableRemoved(elt);
  }

  protected void checkForComod()
    throws ConcurrentModificationException
  {
    if (_modCount != _list._modCount)
      throw new ConcurrentModificationException();
  }
}