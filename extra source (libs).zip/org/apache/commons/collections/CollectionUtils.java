package org.apache.commons.collections;

import java.lang.reflect.Array;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import org.apache.commons.collections.collection.PredicatedCollection;
import org.apache.commons.collections.collection.SynchronizedCollection;
import org.apache.commons.collections.collection.TransformedCollection;
import org.apache.commons.collections.collection.TypedCollection;
import org.apache.commons.collections.collection.UnmodifiableBoundedCollection;
import org.apache.commons.collections.collection.UnmodifiableCollection;

public class CollectionUtils
{
  private static Integer INTEGER_ONE = new Integer(1);

  public static final Collection EMPTY_COLLECTION = UnmodifiableCollection.decorate(new ArrayList());

  public static Collection union(Collection a, Collection b)
  {
    ArrayList list = new ArrayList();
    Map mapa = getCardinalityMap(a);
    Map mapb = getCardinalityMap(b);
    Set elts = new HashSet(a);
    elts.addAll(b);
    Iterator it = elts.iterator();
    while (it.hasNext()) {
      Object obj = it.next();
      int i = 0; for (int m = Math.max(getFreq(obj, mapa), getFreq(obj, mapb)); i < m; i++) {
        list.add(obj);
      }
    }
    return list;
  }

  public static Collection intersection(Collection a, Collection b)
  {
    ArrayList list = new ArrayList();
    Map mapa = getCardinalityMap(a);
    Map mapb = getCardinalityMap(b);
    Set elts = new HashSet(a);
    elts.addAll(b);
    Iterator it = elts.iterator();
    while (it.hasNext()) {
      Object obj = it.next();
      int i = 0; for (int m = Math.min(getFreq(obj, mapa), getFreq(obj, mapb)); i < m; i++) {
        list.add(obj);
      }
    }
    return list;
  }

  public static Collection disjunction(Collection a, Collection b)
  {
    ArrayList list = new ArrayList();
    Map mapa = getCardinalityMap(a);
    Map mapb = getCardinalityMap(b);
    Set elts = new HashSet(a);
    elts.addAll(b);
    Iterator it = elts.iterator();
    while (it.hasNext()) {
      Object obj = it.next();
      int i = 0; for (int m = Math.max(getFreq(obj, mapa), getFreq(obj, mapb)) - Math.min(getFreq(obj, mapa), getFreq(obj, mapb)); i < m; i++) {
        list.add(obj);
      }
    }
    return list;
  }

  public static Collection subtract(Collection a, Collection b)
  {
    ArrayList list = new ArrayList(a);
    for (Iterator it = b.iterator(); it.hasNext(); ) {
      list.remove(it.next());
    }
    return list;
  }

  public static boolean containsAny(Collection coll1, Collection coll2)
  {
    if (coll1.size() < coll2.size()) {
      for (Iterator it = coll1.iterator(); it.hasNext(); ) {
        if (coll2.contains(it.next()))
          return true;
      }
    }
    else {
      for (Iterator it = coll2.iterator(); it.hasNext(); ) {
        if (coll1.contains(it.next())) {
          return true;
        }
      }
    }
    return false;
  }

  public static Map getCardinalityMap(Collection coll)
  {
    Map count = new HashMap();
    for (Iterator it = coll.iterator(); it.hasNext(); ) {
      Object obj = it.next();
      Integer c = (Integer)count.get(obj);
      if (c == null)
        count.put(obj, INTEGER_ONE);
      else {
        count.put(obj, new Integer(c.intValue() + 1));
      }
    }
    return count;
  }

  public static boolean isSubCollection(Collection a, Collection b)
  {
    Map mapa = getCardinalityMap(a);
    Map mapb = getCardinalityMap(b);
    Iterator it = a.iterator();
    while (it.hasNext()) {
      Object obj = it.next();
      if (getFreq(obj, mapa) > getFreq(obj, mapb)) {
        return false;
      }
    }
    return true;
  }

  public static boolean isProperSubCollection(Collection a, Collection b)
  {
    return (a.size() < b.size()) && (isSubCollection(a, b));
  }

  public static boolean isEqualCollection(Collection a, Collection b)
  {
    if (a.size() != b.size()) {
      return false;
    }
    Map mapa = getCardinalityMap(a);
    Map mapb = getCardinalityMap(b);
    if (mapa.size() != mapb.size()) {
      return false;
    }
    Iterator it = mapa.keySet().iterator();
    while (it.hasNext()) {
      Object obj = it.next();
      if (getFreq(obj, mapa) != getFreq(obj, mapb)) {
        return false;
      }
    }
    return true;
  }

  public static int cardinality(Object obj, Collection coll)
  {
    if ((coll instanceof Set)) {
      return coll.contains(obj) ? 1 : 0;
    }
    if ((coll instanceof Bag)) {
      return ((Bag)coll).getCount(obj);
    }
    int count = 0;
    if (obj == null) {
      for (Iterator it = coll.iterator(); it.hasNext(); ) {
        if (it.next() == null)
          count++;
      }
    }
    else {
      for (Iterator it = coll.iterator(); it.hasNext(); ) {
        if (obj.equals(it.next())) {
          count++;
        }
      }
    }
    return count;
  }

  public static Object find(Collection collection, Predicate predicate)
  {
    if ((collection != null) && (predicate != null)) {
      for (Iterator iter = collection.iterator(); iter.hasNext(); ) {
        Object item = iter.next();
        if (predicate.evaluate(item)) {
          return item;
        }
      }
    }
    return null;
  }

  public static void forAllDo(Collection collection, Closure closure)
  {
    if ((collection != null) && (closure != null))
      for (Iterator it = collection.iterator(); it.hasNext(); )
        closure.execute(it.next());
  }

  public static void filter(Collection collection, Predicate predicate)
  {
    if ((collection != null) && (predicate != null))
      for (Iterator it = collection.iterator(); it.hasNext(); )
        if (!predicate.evaluate(it.next()))
          it.remove();
  }

  public static void transform(Collection collection, Transformer transformer)
  {
    if ((collection != null) && (transformer != null))
      if ((collection instanceof List)) {
        List list = (List)collection;
        for (ListIterator it = list.listIterator(); it.hasNext(); )
          it.set(transformer.transform(it.next()));
      }
      else {
        Collection resultCollection = collect(collection, transformer);
        collection.clear();
        collection.addAll(resultCollection);
      }
  }

  public static int countMatches(Collection inputCollection, Predicate predicate)
  {
    int count = 0;
    if ((inputCollection != null) && (predicate != null)) {
      for (Iterator it = inputCollection.iterator(); it.hasNext(); ) {
        if (predicate.evaluate(it.next())) {
          count++;
        }
      }
    }
    return count;
  }

  public static boolean exists(Collection collection, Predicate predicate)
  {
    if ((collection != null) && (predicate != null)) {
      for (Iterator it = collection.iterator(); it.hasNext(); ) {
        if (predicate.evaluate(it.next())) {
          return true;
        }
      }
    }
    return false;
  }

  public static Collection select(Collection inputCollection, Predicate predicate)
  {
    ArrayList answer = new ArrayList(inputCollection.size());
    select(inputCollection, predicate, answer);
    return answer;
  }

  public static void select(Collection inputCollection, Predicate predicate, Collection outputCollection)
  {
    if ((inputCollection != null) && (predicate != null))
      for (Iterator iter = inputCollection.iterator(); iter.hasNext(); ) {
        Object item = iter.next();
        if (predicate.evaluate(item))
          outputCollection.add(item);
      }
  }

  public static Collection selectRejected(Collection inputCollection, Predicate predicate)
  {
    ArrayList answer = new ArrayList(inputCollection.size());
    selectRejected(inputCollection, predicate, answer);
    return answer;
  }

  public static void selectRejected(Collection inputCollection, Predicate predicate, Collection outputCollection)
  {
    if ((inputCollection != null) && (predicate != null))
      for (Iterator iter = inputCollection.iterator(); iter.hasNext(); ) {
        Object item = iter.next();
        if (!predicate.evaluate(item))
          outputCollection.add(item);
      }
  }

  public static Collection collect(Collection inputCollection, Transformer transformer)
  {
    ArrayList answer = new ArrayList(inputCollection.size());
    collect(inputCollection, transformer, answer);
    return answer;
  }

  public static Collection collect(Iterator inputIterator, Transformer transformer)
  {
    ArrayList answer = new ArrayList();
    collect(inputIterator, transformer, answer);
    return answer;
  }

  public static Collection collect(Collection inputCollection, Transformer transformer, Collection outputCollection)
  {
    if (inputCollection != null) {
      return collect(inputCollection.iterator(), transformer, outputCollection);
    }
    return outputCollection;
  }

  public static Collection collect(Iterator inputIterator, Transformer transformer, Collection outputCollection)
  {
    if ((inputIterator != null) && (transformer != null)) {
      while (inputIterator.hasNext()) {
        Object item = inputIterator.next();
        Object value = transformer.transform(item);
        outputCollection.add(value);
      }
    }
    return outputCollection;
  }

  public static void addAll(Collection collection, Iterator iterator)
  {
    while (iterator.hasNext())
      collection.add(iterator.next());
  }

  public static void addAll(Collection collection, Enumeration enumeration)
  {
    while (enumeration.hasMoreElements())
      collection.add(enumeration.nextElement());
  }

  public static void addAll(Collection collection, Object[] elements)
  {
    int i = 0; for (int size = elements.length; i < size; i++)
      collection.add(elements[i]);
  }

  /** @deprecated */
  public static Object index(Object obj, int idx)
  {
    return index(obj, new Integer(idx));
  }

  /** @deprecated */
  public static Object index(Object obj, Object index)
  {
    if ((obj instanceof Map)) {
      Map map = (Map)obj;
      if (map.containsKey(index)) {
        return map.get(index);
      }
    }
    int idx = -1;
    if ((index instanceof Integer)) {
      idx = ((Integer)index).intValue();
    }
    if (idx < 0) {
      return obj;
    }
    if ((obj instanceof Map)) {
      Map map = (Map)obj;
      Iterator iterator = map.keySet().iterator();
      return index(iterator, idx);
    }
    if ((obj instanceof List)) {
      return ((List)obj).get(idx);
    }
    if ((obj instanceof Object[])) {
      return ((Object[])obj)[idx];
    }
    if ((obj instanceof Enumeration)) {
      Enumeration it = (Enumeration)obj;
      while (it.hasMoreElements()) {
        idx--;
        if (idx == -1) {
          return it.nextElement();
        }
        it.nextElement();
      }
    }
    else {
      if ((obj instanceof Iterator)) {
        return index((Iterator)obj, idx);
      }
      if ((obj instanceof Collection)) {
        Iterator iterator = ((Collection)obj).iterator();
        return index(iterator, idx);
      }
    }
    return obj;
  }

  private static Object index(Iterator iterator, int idx) {
    while (iterator.hasNext()) {
      idx--;
      if (idx == -1) {
        return iterator.next();
      }
      iterator.next();
    }

    return iterator;
  }

  public static Object get(Object object, int index)
  {
    if (index < 0) {
      throw new IndexOutOfBoundsException("Index cannot be negative: " + index);
    }
    if ((object instanceof Map)) {
      Map map = (Map)object;
      Iterator iterator = map.entrySet().iterator();
      return get(iterator, index);
    }if ((object instanceof List))
      return ((List)object).get(index);
    if ((object instanceof Object[]))
      return ((Object[])object)[index];
    if ((object instanceof Iterator)) {
      Iterator it = (Iterator)object;
      while (it.hasNext()) {
        index--;
        if (index == -1) {
          return it.next();
        }
        it.next();
      }

      throw new IndexOutOfBoundsException("Entry does not exist: " + index);
    }if ((object instanceof Collection)) {
      Iterator iterator = ((Collection)object).iterator();
      return get(iterator, index);
    }if ((object instanceof Enumeration)) {
      Enumeration it = (Enumeration)object;
      while (it.hasMoreElements()) {
        index--;
        if (index == -1) {
          return it.nextElement();
        }
        it.nextElement();
      }

      throw new IndexOutOfBoundsException("Entry does not exist: " + index);
    }if (object == null)
      throw new IllegalArgumentException("Unsupported object type: null");
    try
    {
      return Array.get(object, index); } catch (IllegalArgumentException ex) {
    }
    throw new IllegalArgumentException("Unsupported object type: " + object.getClass().getName());
  }

  public static int size(Object object)
  {
    int total = 0;
    if ((object instanceof Map)) {
      total = ((Map)object).size();
    } else if ((object instanceof Collection)) {
      total = ((Collection)object).size();
    } else if ((object instanceof Object[])) {
      total = ((Object[])object).length;
    } else if ((object instanceof Iterator)) {
      Iterator it = (Iterator)object;
      while (it.hasNext()) {
        total++;
        it.next();
      }
    } else if ((object instanceof Enumeration)) {
      Enumeration it = (Enumeration)object;
      while (it.hasMoreElements()) {
        total++;
        it.nextElement();
      }
    } else {
      if (object == null)
        throw new IllegalArgumentException("Unsupported object type: null");
      try
      {
        total = Array.getLength(object);
      } catch (IllegalArgumentException ex) {
        throw new IllegalArgumentException("Unsupported object type: " + object.getClass().getName());
      }
    }
    return total;
  }

  public static void reverseArray(Object[] array)
  {
    int i = 0;
    int j = array.length - 1;

    while (j > i) {
      Object tmp = array[j];
      array[j] = array[i];
      array[i] = tmp;
      j--;
      i++;
    }
  }

  private static final int getFreq(Object obj, Map freqMap) {
    Integer count = (Integer)freqMap.get(obj);
    if (count != null) {
      return count.intValue();
    }
    return 0;
  }

  public static boolean isFull(Collection coll)
  {
    if (coll == null) {
      throw new NullPointerException("The collection must not be null");
    }
    if ((coll instanceof BoundedCollection))
      return ((BoundedCollection)coll).isFull();
    try
    {
      BoundedCollection bcoll = UnmodifiableBoundedCollection.decorateUsing(coll);
      return bcoll.isFull();
    } catch (IllegalArgumentException ex) {
    }
    return false;
  }

  public static int maxSize(Collection coll)
  {
    if (coll == null) {
      throw new NullPointerException("The collection must not be null");
    }
    if ((coll instanceof BoundedCollection))
      return ((BoundedCollection)coll).maxSize();
    try
    {
      BoundedCollection bcoll = UnmodifiableBoundedCollection.decorateUsing(coll);
      return bcoll.maxSize();
    } catch (IllegalArgumentException ex) {
    }
    return -1;
  }

  public static Collection synchronizedCollection(Collection collection)
  {
    return SynchronizedCollection.decorate(collection);
  }

  public static Collection unmodifiableCollection(Collection collection)
  {
    return UnmodifiableCollection.decorate(collection);
  }

  public static Collection predicatedCollection(Collection collection, Predicate predicate)
  {
    return PredicatedCollection.decorate(collection, predicate);
  }

  public static Collection typedCollection(Collection collection, Class type)
  {
    return TypedCollection.decorate(collection, type);
  }

  public static Collection transformedCollection(Collection collection, Transformer transformer)
  {
    return TransformedCollection.decorate(collection, transformer);
  }
}