package org.apache.commons.collections;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public class ExtendedProperties extends Hashtable
{
  private ExtendedProperties defaults;
  protected String file;
  protected String basePath;
  protected String fileSeparator = System.getProperty("file.separator");

  protected boolean isInitialized = false;

  protected static String include = "include";

  protected ArrayList keysAsListed = new ArrayList();
  protected static final String START_TOKEN = "${";
  protected static final String END_TOKEN = "}";

  protected String interpolate(String base)
  {
    return interpolateHelper(base, null);
  }

  protected String interpolateHelper(String base, List priorVariables)
  {
    if (base == null) {
      return null;
    }

    if (priorVariables == null) {
      priorVariables = new ArrayList();
      priorVariables.add(base);
    }

    int begin = -1;
    int end = -1;
    int prec = 0 - "}".length();
    String variable = null;
    StringBuffer result = new StringBuffer();

    while (((begin = base.indexOf("${", prec + "}".length())) > -1) && ((end = base.indexOf("}", begin)) > -1)) {
      result.append(base.substring(prec + "}".length(), begin));
      variable = base.substring(begin + "${".length(), end);

      if (priorVariables.contains(variable)) {
        String initialBase = priorVariables.remove(0).toString();
        priorVariables.add(variable);
        StringBuffer priorVariableSb = new StringBuffer();

        for (Iterator it = priorVariables.iterator(); it.hasNext(); ) {
          priorVariableSb.append(it.next());
          if (it.hasNext()) {
            priorVariableSb.append("->");
          }
        }

        throw new IllegalStateException("infinite loop in property interpolation of " + initialBase + ": " + priorVariableSb.toString());
      }

      priorVariables.add(variable);

      Object value = getProperty(variable);
      if (value != null) {
        result.append(interpolateHelper(value.toString(), priorVariables));

        priorVariables.remove(priorVariables.size() - 1);
      } else if ((defaults != null) && (defaults.getString(variable, null) != null)) {
        result.append(defaults.getString(variable));
      }
      else {
        result.append("${").append(variable).append("}");
      }
      prec = end;
    }
    result.append(base.substring(prec + "}".length(), base.length()));

    return result.toString();
  }

  private static String escape(String s)
  {
    StringBuffer buf = new StringBuffer(s);
    for (int i = 0; i < buf.length(); i++) {
      char c = buf.charAt(i);
      if ((c == ',') || (c == '\\')) {
        buf.insert(i, '\\');
        i++;
      }
    }
    return buf.toString();
  }

  private static String unescape(String s)
  {
    StringBuffer buf = new StringBuffer(s);
    for (int i = 0; i < buf.length() - 1; i++) {
      char c1 = buf.charAt(i);
      char c2 = buf.charAt(i + 1);
      if ((c1 == '\\') && (c2 == '\\')) {
        buf.deleteCharAt(i);
      }
    }
    return buf.toString();
  }

  private static int countPreceding(String line, int index, char ch)
  {
    for (int i = index - 1; i >= 0; i--) {
      if (line.charAt(i) != ch) {
        break;
      }
    }
    return index - 1 - i;
  }

  private static boolean endsWithSlash(String line)
  {
    if (!line.endsWith("\\")) {
      return false;
    }
    return countPreceding(line, line.length() - 1, '\\') % 2 == 0;
  }

  public ExtendedProperties()
  {
  }

  public ExtendedProperties(String file)
    throws IOException
  {
    this(file, null);
  }

  public ExtendedProperties(String file, String defaultFile)
    throws IOException
  {
    this.file = file;

    basePath = new File(file).getAbsolutePath();
    basePath = basePath.substring(0, basePath.lastIndexOf(fileSeparator) + 1);

    FileInputStream in = null;
    try {
      in = new FileInputStream(file);
      load(in);
    } finally {
      try {
        if (in != null)
          in.close();
      }
      catch (IOException ex) {
      }
    }
    if (defaultFile != null)
      defaults = new ExtendedProperties(defaultFile);
  }

  public boolean isInitialized()
  {
    return isInitialized;
  }

  public String getInclude()
  {
    return include;
  }

  public void setInclude(String inc)
  {
    include = inc;
  }

  public void load(InputStream input)
    throws IOException
  {
    load(input, null); } 
  // ERROR //
  public synchronized void load(InputStream input, String enc) throws IOException { // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_2
    //   3: ifnull +25 -> 28
    //   6: new 63	org/apache/commons/collections/ExtendedProperties$PropertiesReader
    //   9: dup
    //   10: new 64	java/io/InputStreamReader
    //   13: dup
    //   14: aload_1
    //   15: aload_2
    //   16: invokespecial 65	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/lang/String;)V
    //   19: invokespecial 66	org/apache/commons/collections/ExtendedProperties$PropertiesReader:<init>	(Ljava/io/Reader;)V
    //   22: astore_3
    //   23: goto +5 -> 28
    //   26: astore 4
    //   28: aload_3
    //   29: ifnonnull +42 -> 71
    //   32: new 63	org/apache/commons/collections/ExtendedProperties$PropertiesReader
    //   35: dup
    //   36: new 64	java/io/InputStreamReader
    //   39: dup
    //   40: aload_1
    //   41: ldc 68
    //   43: invokespecial 65	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/lang/String;)V
    //   46: invokespecial 66	org/apache/commons/collections/ExtendedProperties$PropertiesReader:<init>	(Ljava/io/Reader;)V
    //   49: astore_3
    //   50: goto +21 -> 71
    //   53: astore 4
    //   55: new 63	org/apache/commons/collections/ExtendedProperties$PropertiesReader
    //   58: dup
    //   59: new 64	java/io/InputStreamReader
    //   62: dup
    //   63: aload_1
    //   64: invokespecial 69	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;)V
    //   67: invokespecial 66	org/apache/commons/collections/ExtendedProperties$PropertiesReader:<init>	(Ljava/io/Reader;)V
    //   70: astore_3
    //   71: goto +3 -> 74
    //   74: aload_3
    //   75: invokevirtual 70	org/apache/commons/collections/ExtendedProperties$PropertiesReader:readProperty	()Ljava/lang/String;
    //   78: astore 4
    //   80: aload 4
    //   82: bipush 61
    //   84: invokevirtual 71	java/lang/String:indexOf	(I)I
    //   87: istore 5
    //   89: iload 5
    //   91: ifle +205 -> 296
    //   94: aload 4
    //   96: iconst_0
    //   97: iload 5
    //   99: invokevirtual 10	java/lang/String:substring	(II)Ljava/lang/String;
    //   102: invokevirtual 72	java/lang/String:trim	()Ljava/lang/String;
    //   105: astore 6
    //   107: aload 4
    //   109: iload 5
    //   111: iconst_1
    //   112: iadd
    //   113: invokevirtual 73	java/lang/String:substring	(I)Ljava/lang/String;
    //   116: invokevirtual 72	java/lang/String:trim	()Ljava/lang/String;
    //   119: astore 7
    //   121: ldc 74
    //   123: aload 7
    //   125: invokevirtual 75	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   128: ifeq +6 -> 134
    //   131: goto -57 -> 74
    //   134: aload_0
    //   135: invokevirtual 76	org/apache/commons/collections/ExtendedProperties:getInclude	()Ljava/lang/String;
    //   138: ifnull +150 -> 288
    //   141: aload 6
    //   143: aload_0
    //   144: invokevirtual 76	org/apache/commons/collections/ExtendedProperties:getInclude	()Ljava/lang/String;
    //   147: invokevirtual 77	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   150: ifeq +138 -> 288
    //   153: aconst_null
    //   154: astore 8
    //   156: aload 7
    //   158: aload_0
    //   159: getfield 44	org/apache/commons/collections/ExtendedProperties:fileSeparator	Ljava/lang/String;
    //   162: invokevirtual 78	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   165: ifeq +17 -> 182
    //   168: new 49	java/io/File
    //   171: dup
    //   172: aload 7
    //   174: invokespecial 50	java/io/File:<init>	(Ljava/lang/String;)V
    //   177: astore 8
    //   179: goto +72 -> 251
    //   182: aload 7
    //   184: new 8	java/lang/StringBuffer
    //   187: dup
    //   188: invokespecial 9	java/lang/StringBuffer:<init>	()V
    //   191: ldc 79
    //   193: invokevirtual 11	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   196: aload_0
    //   197: getfield 44	org/apache/commons/collections/ExtendedProperties:fileSeparator	Ljava/lang/String;
    //   200: invokevirtual 11	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   203: invokevirtual 24	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   206: invokevirtual 78	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   209: ifeq +11 -> 220
    //   212: aload 7
    //   214: iconst_2
    //   215: invokevirtual 73	java/lang/String:substring	(I)Ljava/lang/String;
    //   218: astore 7
    //   220: new 49	java/io/File
    //   223: dup
    //   224: new 8	java/lang/StringBuffer
    //   227: dup
    //   228: invokespecial 9	java/lang/StringBuffer:<init>	()V
    //   231: aload_0
    //   232: getfield 52	org/apache/commons/collections/ExtendedProperties:basePath	Ljava/lang/String;
    //   235: invokevirtual 11	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   238: aload 7
    //   240: invokevirtual 11	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   243: invokevirtual 24	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   246: invokespecial 50	java/io/File:<init>	(Ljava/lang/String;)V
    //   249: astore 8
    //   251: aload 8
    //   253: ifnull +32 -> 285
    //   256: aload 8
    //   258: invokevirtual 80	java/io/File:exists	()Z
    //   261: ifeq +24 -> 285
    //   264: aload 8
    //   266: invokevirtual 81	java/io/File:canRead	()Z
    //   269: ifeq +16 -> 285
    //   272: aload_0
    //   273: new 54	java/io/FileInputStream
    //   276: dup
    //   277: aload 8
    //   279: invokespecial 82	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   282: invokevirtual 56	org/apache/commons/collections/ExtendedProperties:load	(Ljava/io/InputStream;)V
    //   285: goto +11 -> 296
    //   288: aload_0
    //   289: aload 6
    //   291: aload 7
    //   293: invokevirtual 83	org/apache/commons/collections/ExtendedProperties:addProperty	(Ljava/lang/String;Ljava/lang/Object;)V
    //   296: goto -222 -> 74
    //   299: astore 4
    //   301: jsr +12 -> 313
    //   304: return
    //   305: astore 9
    //   307: jsr +6 -> 313
    //   310: aload 9
    //   312: athrow
    //   313: astore 10
    //   315: aload_0
    //   316: iconst_1
    //   317: putfield 45	org/apache/commons/collections/ExtendedProperties:isInitialized	Z
    //   320: ret 10
    //
    // Exception table:
    //   from	to	target	type
    //   6	23	26	java/io/UnsupportedEncodingException
    //   32	50	53	java/io/UnsupportedEncodingException
    //   71	299	299	java/lang/NullPointerException
    //   71	305	305	finally } 
  public Object getProperty(String key) { Object obj = get(key);

    if (obj == null)
    {
      if (defaults != null) {
        obj = defaults.get(key);
      }
    }

    return obj;
  }

  public void addProperty(String key, Object value)
  {
    if ((value instanceof String)) {
      String str = (String)value;
      if (str.indexOf(",") > 0)
      {
        PropertiesTokenizer tokenizer = new PropertiesTokenizer(str);
        while (tokenizer.hasMoreTokens()) {
          String token = tokenizer.nextToken();
          addPropertyInternal(key, unescape(token));
        }
      }
      else {
        addPropertyInternal(key, unescape(str));
      }
    } else {
      addPropertyInternal(key, value);
    }

    isInitialized = true;
  }

  private void addPropertyDirect(String key, Object value)
  {
    if (!containsKey(key)) {
      keysAsListed.add(key);
    }
    put(key, value);
  }

  private void addPropertyInternal(String key, Object value)
  {
    Object current = get(key);

    if ((current instanceof String))
    {
      Vector v = new Vector(2);
      v.addElement(current);
      v.addElement(value);
      put(key, v);
    }
    else if ((current instanceof Vector))
    {
      ((Vector)current).addElement(value);
    }
    else
    {
      if (!containsKey(key)) {
        keysAsListed.add(key);
      }
      put(key, value);
    }
  }

  public void setProperty(String key, Object value)
  {
    clearProperty(key);
    addProperty(key, value);
  }

  public synchronized void save(OutputStream output, String header)
    throws IOException
  {
    if (output == null) {
      return;
    }
    PrintWriter theWrtr = new PrintWriter(output);
    if (header != null) {
      theWrtr.println(header);
    }

    Enumeration theKeys = keys();
    while (theKeys.hasMoreElements()) {
      String key = (String)theKeys.nextElement();
      Object value = get(key);
      if (value != null) {
        if ((value instanceof String)) {
          StringBuffer currentOutput = new StringBuffer();
          currentOutput.append(key);
          currentOutput.append("=");
          currentOutput.append(escape((String)value));
          theWrtr.println(currentOutput.toString());
        }
        else if ((value instanceof Vector)) {
          Vector values = (Vector)value;
          Enumeration valuesEnum = values.elements();
          while (valuesEnum.hasMoreElements()) {
            String currentElement = (String)valuesEnum.nextElement();
            StringBuffer currentOutput = new StringBuffer();
            currentOutput.append(key);
            currentOutput.append("=");
            currentOutput.append(escape(currentElement));
            theWrtr.println(currentOutput.toString());
          }
        }
      }
      theWrtr.println();
      theWrtr.flush();
    }
  }

  public void combine(ExtendedProperties props)
  {
    for (Iterator it = props.getKeys(); it.hasNext(); ) {
      String key = (String)it.next();
      setProperty(key, props.get(key));
    }
  }

  public void clearProperty(String key)
  {
    if (containsKey(key))
    {
      for (int i = 0; i < keysAsListed.size(); i++) {
        if (keysAsListed.get(i).equals(key)) {
          keysAsListed.remove(i);
          break;
        }
      }
      remove(key);
    }
  }

  public Iterator getKeys()
  {
    return keysAsListed.iterator();
  }

  public Iterator getKeys(String prefix)
  {
    Iterator keys = getKeys();
    ArrayList matchingKeys = new ArrayList();

    while (keys.hasNext()) {
      Object key = keys.next();

      if (((key instanceof String)) && (((String)key).startsWith(prefix))) {
        matchingKeys.add(key);
      }
    }
    return matchingKeys.iterator();
  }

  public ExtendedProperties subset(String prefix)
  {
    ExtendedProperties c = new ExtendedProperties();
    Iterator keys = getKeys();
    boolean validSubset = false;

    while (keys.hasNext()) {
      Object key = keys.next();

      if (((key instanceof String)) && (((String)key).startsWith(prefix))) {
        if (!validSubset) {
          validSubset = true;
        }

        String newKey = null;
        if (((String)key).length() == prefix.length())
          newKey = prefix;
        else {
          newKey = ((String)key).substring(prefix.length() + 1);
        }

        c.addPropertyDirect(newKey, get(key));
      }
    }

    if (validSubset) {
      return c;
    }
    return null;
  }

  public void display()
  {
    Iterator i = getKeys();

    while (i.hasNext()) {
      String key = (String)i.next();
      Object value = get(key);
      System.out.println(key + " => " + value);
    }
  }

  public String getString(String key)
  {
    return getString(key, null);
  }

  public String getString(String key, String defaultValue)
  {
    Object value = get(key);

    if ((value instanceof String)) {
      return interpolate((String)value);
    }
    if (value == null) {
      if (defaults != null) {
        return interpolate(defaults.getString(key, defaultValue));
      }
      return interpolate(defaultValue);
    }
    if ((value instanceof Vector)) {
      return interpolate((String)((Vector)value).get(0));
    }
    throw new ClassCastException('\'' + key + "' doesn't map to a String object");
  }

  public Properties getProperties(String key)
  {
    return getProperties(key, new Properties());
  }

  public Properties getProperties(String key, Properties defaults)
  {
    String[] tokens = getStringArray(key);

    Properties props = new Properties(defaults);
    for (int i = 0; i < tokens.length; i++) {
      String token = tokens[i];
      int equalSign = token.indexOf('=');
      if (equalSign > 0) {
        String pkey = token.substring(0, equalSign).trim();
        String pvalue = token.substring(equalSign + 1).trim();
        props.put(pkey, pvalue);
      } else {
        throw new IllegalArgumentException('\'' + token + "' does not contain " + "an equals sign");
      }
    }
    return props;
  }

  public String[] getStringArray(String key)
  {
    Object value = get(key);
    Vector vector;
    if ((value instanceof String)) {
      vector = new Vector(1);
      vector.addElement(value);
    }
    else if ((value instanceof Vector)) {
      vector = (Vector)value;
    } else {
      if (value == null) {
        if (defaults != null) {
          return defaults.getStringArray(key);
        }
        return new String[0];
      }

      throw new ClassCastException('\'' + key + "' doesn't map to a String/Vector object");
    }

    String[] tokens = new String[vector.size()];
    for (int i = 0; i < tokens.length; i++) {
      tokens[i] = ((String)vector.elementAt(i));
    }

    return tokens;
  }

  public Vector getVector(String key)
  {
    return getVector(key, null);
  }

  public Vector getVector(String key, Vector defaultValue)
  {
    Object value = get(key);

    if ((value instanceof Vector)) {
      return (Vector)value;
    }
    if ((value instanceof String)) {
      Vector v = new Vector(1);
      v.addElement(value);
      put(key, v);
      return v;
    }
    if (value == null) {
      if (defaults != null) {
        return defaults.getVector(key, defaultValue);
      }
      return defaultValue == null ? new Vector() : defaultValue;
    }

    throw new ClassCastException('\'' + key + "' doesn't map to a Vector object");
  }

  public boolean getBoolean(String key)
  {
    Boolean b = getBoolean(key, null);
    if (b != null) {
      return b.booleanValue();
    }
    throw new NoSuchElementException('\'' + key + "' doesn't map to an existing object");
  }

  public boolean getBoolean(String key, boolean defaultValue)
  {
    return getBoolean(key, new Boolean(defaultValue)).booleanValue();
  }

  public Boolean getBoolean(String key, Boolean defaultValue)
  {
    Object value = get(key);

    if ((value instanceof Boolean)) {
      return (Boolean)value;
    }
    if ((value instanceof String)) {
      String s = testBoolean((String)value);
      Boolean b = new Boolean(s);
      put(key, b);
      return b;
    }
    if (value == null) {
      if (defaults != null) {
        return defaults.getBoolean(key, defaultValue);
      }
      return defaultValue;
    }

    throw new ClassCastException('\'' + key + "' doesn't map to a Boolean object");
  }

  public String testBoolean(String value)
  {
    String s = value.toLowerCase();

    if ((s.equals("true")) || (s.equals("on")) || (s.equals("yes")))
      return "true";
    if ((s.equals("false")) || (s.equals("off")) || (s.equals("no"))) {
      return "false";
    }
    return null;
  }

  public byte getByte(String key)
  {
    Byte b = getByte(key, null);
    if (b != null) {
      return b.byteValue();
    }
    throw new NoSuchElementException('\'' + key + " doesn't map to an existing object");
  }

  public byte getByte(String key, byte defaultValue)
  {
    return getByte(key, new Byte(defaultValue)).byteValue();
  }

  public Byte getByte(String key, Byte defaultValue)
  {
    Object value = get(key);

    if ((value instanceof Byte)) {
      return (Byte)value;
    }
    if ((value instanceof String)) {
      Byte b = new Byte((String)value);
      put(key, b);
      return b;
    }
    if (value == null) {
      if (defaults != null) {
        return defaults.getByte(key, defaultValue);
      }
      return defaultValue;
    }

    throw new ClassCastException('\'' + key + "' doesn't map to a Byte object");
  }

  public short getShort(String key)
  {
    Short s = getShort(key, null);
    if (s != null) {
      return s.shortValue();
    }
    throw new NoSuchElementException('\'' + key + "' doesn't map to an existing object");
  }

  public short getShort(String key, short defaultValue)
  {
    return getShort(key, new Short(defaultValue)).shortValue();
  }

  public Short getShort(String key, Short defaultValue)
  {
    Object value = get(key);

    if ((value instanceof Short)) {
      return (Short)value;
    }
    if ((value instanceof String)) {
      Short s = new Short((String)value);
      put(key, s);
      return s;
    }
    if (value == null) {
      if (defaults != null) {
        return defaults.getShort(key, defaultValue);
      }
      return defaultValue;
    }

    throw new ClassCastException('\'' + key + "' doesn't map to a Short object");
  }

  public int getInt(String name)
  {
    return getInteger(name);
  }

  public int getInt(String name, int def)
  {
    return getInteger(name, def);
  }

  public int getInteger(String key)
  {
    Integer i = getInteger(key, null);
    if (i != null) {
      return i.intValue();
    }
    throw new NoSuchElementException('\'' + key + "' doesn't map to an existing object");
  }

  public int getInteger(String key, int defaultValue)
  {
    Integer i = getInteger(key, null);

    if (i == null) {
      return defaultValue;
    }
    return i.intValue();
  }

  public Integer getInteger(String key, Integer defaultValue)
  {
    Object value = get(key);

    if ((value instanceof Integer)) {
      return (Integer)value;
    }
    if ((value instanceof String)) {
      Integer i = new Integer((String)value);
      put(key, i);
      return i;
    }
    if (value == null) {
      if (defaults != null) {
        return defaults.getInteger(key, defaultValue);
      }
      return defaultValue;
    }

    throw new ClassCastException('\'' + key + "' doesn't map to a Integer object");
  }

  public long getLong(String key)
  {
    Long l = getLong(key, null);
    if (l != null) {
      return l.longValue();
    }
    throw new NoSuchElementException('\'' + key + "' doesn't map to an existing object");
  }

  public long getLong(String key, long defaultValue)
  {
    return getLong(key, new Long(defaultValue)).longValue();
  }

  public Long getLong(String key, Long defaultValue)
  {
    Object value = get(key);

    if ((value instanceof Long)) {
      return (Long)value;
    }
    if ((value instanceof String)) {
      Long l = new Long((String)value);
      put(key, l);
      return l;
    }
    if (value == null) {
      if (defaults != null) {
        return defaults.getLong(key, defaultValue);
      }
      return defaultValue;
    }

    throw new ClassCastException('\'' + key + "' doesn't map to a Long object");
  }

  public float getFloat(String key)
  {
    Float f = getFloat(key, null);
    if (f != null) {
      return f.floatValue();
    }
    throw new NoSuchElementException('\'' + key + "' doesn't map to an existing object");
  }

  public float getFloat(String key, float defaultValue)
  {
    return getFloat(key, new Float(defaultValue)).floatValue();
  }

  public Float getFloat(String key, Float defaultValue)
  {
    Object value = get(key);

    if ((value instanceof Float)) {
      return (Float)value;
    }
    if ((value instanceof String)) {
      Float f = new Float((String)value);
      put(key, f);
      return f;
    }
    if (value == null) {
      if (defaults != null) {
        return defaults.getFloat(key, defaultValue);
      }
      return defaultValue;
    }

    throw new ClassCastException('\'' + key + "' doesn't map to a Float object");
  }

  public double getDouble(String key)
  {
    Double d = getDouble(key, null);
    if (d != null) {
      return d.doubleValue();
    }
    throw new NoSuchElementException('\'' + key + "' doesn't map to an existing object");
  }

  public double getDouble(String key, double defaultValue)
  {
    return getDouble(key, new Double(defaultValue)).doubleValue();
  }

  public Double getDouble(String key, Double defaultValue)
  {
    Object value = get(key);

    if ((value instanceof Double)) {
      return (Double)value;
    }
    if ((value instanceof String)) {
      Double d = new Double((String)value);
      put(key, d);
      return d;
    }
    if (value == null) {
      if (defaults != null) {
        return defaults.getDouble(key, defaultValue);
      }
      return defaultValue;
    }

    throw new ClassCastException('\'' + key + "' doesn't map to a Double object");
  }

  public static ExtendedProperties convertProperties(Properties props)
  {
    ExtendedProperties c = new ExtendedProperties();

    for (Enumeration e = props.keys(); e.hasMoreElements(); ) {
      String s = (String)e.nextElement();
      c.setProperty(s, props.getProperty(s));
    }

    return c;
  }

  static class PropertiesTokenizer extends StringTokenizer
  {
    static final String DELIMITER = ",";

    public PropertiesTokenizer(String string)
    {
      super(",");
    }

    public boolean hasMoreTokens()
    {
      return super.hasMoreTokens();
    }

    public String nextToken()
    {
      StringBuffer buffer = new StringBuffer();

      while (hasMoreTokens()) {
        String token = super.nextToken();
        if (ExtendedProperties.access$000(token)) {
          buffer.append(token.substring(0, token.length() - 1));
          buffer.append(",");
        } else {
          buffer.append(token);
          break;
        }
      }

      return buffer.toString().trim();
    }
  }

  static class PropertiesReader extends LineNumberReader
  {
    public PropertiesReader(Reader reader)
    {
      super();
    }

    public String readProperty()
      throws IOException
    {
      StringBuffer buffer = new StringBuffer();
      try
      {
        while (true) {
          String line = readLine().trim();
          if ((line.length() != 0) && (line.charAt(0) != '#'))
            if (ExtendedProperties.access$000(line)) {
              line = line.substring(0, line.length() - 1);
              buffer.append(line);
            } else {
              buffer.append(line);
              break;
            }
        }
      }
      catch (NullPointerException ex) {
        return null;
      }

      return buffer.toString();
    }
  }
}