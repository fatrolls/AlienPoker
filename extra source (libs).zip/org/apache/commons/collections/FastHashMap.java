package org.apache.commons.collections;

import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class FastHashMap extends HashMap
{
  protected HashMap map = null;

  protected boolean fast = false;

  public FastHashMap()
  {
    map = new HashMap();
  }

  public FastHashMap(int capacity)
  {
    map = new HashMap(capacity);
  }

  public FastHashMap(int capacity, float factor)
  {
    map = new HashMap(capacity, factor);
  }

  public FastHashMap(Map map)
  {
    this.map = new HashMap(map);
  }

  public boolean getFast()
  {
    return fast;
  }

  public void setFast(boolean fast)
  {
    this.fast = fast;
  }

  public Object get(Object key)
  {
    if (fast) {
      return map.get(key);
    }
    synchronized (map) {
      return map.get(key);
    }
  }

  public int size()
  {
    if (fast) {
      return map.size();
    }
    synchronized (map) {
      return map.size();
    }
  }

  public boolean isEmpty()
  {
    if (fast) {
      return map.isEmpty();
    }
    synchronized (map) {
      return map.isEmpty();
    }
  }

  public boolean containsKey(Object key)
  {
    if (fast) {
      return map.containsKey(key);
    }
    synchronized (map) {
      return map.containsKey(key);
    }
  }

  public boolean containsValue(Object value)
  {
    if (fast) {
      return map.containsValue(value);
    }
    synchronized (map) {
      return map.containsValue(value);
    }
  }

  public Object put(Object key, Object value)
  {
    HashMap temp;
    if (fast) {
      synchronized (this) {
        temp = (HashMap)map.clone();
        Object result = temp.put(key, value);
        map = temp;
        return result;
      }
    }
    synchronized (map) {
      return map.put(key, value);
    }
  }

  public void putAll(Map in)
  {
    if (fast) {
      synchronized (this) {
        HashMap temp = (HashMap)map.clone();
        temp.putAll(in);
        map = temp;
      }
    }
    synchronized (map) {
      map.putAll(in);
    }
  }

  public Object remove(Object key)
  {
    HashMap temp;
    if (fast) {
      synchronized (this) {
        temp = (HashMap)map.clone();
        Object result = temp.remove(key);
        map = temp;
        return result;
      }
    }
    synchronized (map) {
      return map.remove(key);
    }
  }

  public void clear()
  {
    if (fast) {
      synchronized (this) {
        map = new HashMap();
      }
    }
    synchronized (map) {
      map.clear();
    }
  }

  public boolean equals(Object o)
  {
    if (o == this)
      return true;
    if (!(o instanceof Map)) {
      return false;
    }
    Map mo = (Map)o;
    Map.Entry e;
    if (fast) {
      if (mo.size() != map.size()) {
        return false;
      }
      ??? = map.entrySet().iterator();
      while (???.hasNext()) {
        e = (Map.Entry)???.next();
        Object key = e.getKey();
        Object value = e.getValue();
        if (value == null) {
          if ((mo.get(key) != null) || (!mo.containsKey(key))) {
            return false;
          }
        }
        else if (!value.equals(mo.get(key))) {
          return false;
        }
      }

      return true;
    }

    synchronized (map) {
      if (mo.size() != map.size()) {
        return 0;
      }
      Iterator i = map.entrySet().iterator();
      Map.Entry e;
      while (i.hasNext()) {
        e = (Map.Entry)i.next();
        Object key = e.getKey();
        Object value = e.getValue();
        int i;
        if (value == null) {
          if ((mo.get(key) != null) || (!mo.containsKey(key))) {
            return 0;
          }
        }
        else if (!value.equals(mo.get(key))) {
          return 0;
        }
      }

      return 1;
    }
  }

  public int hashCode()
  {
    if (fast) {
      ??? = 0;
      Iterator i = map.entrySet().iterator();
      while (i.hasNext()) {
        ??? += i.next().hashCode();
      }
      return ???;
    }
    synchronized (map) {
      int h = 0;
      Iterator i = map.entrySet().iterator();
      while (i.hasNext()) {
        h += i.next().hashCode();
      }
      return h;
    }
  }

  public Object clone()
  {
    FastHashMap results = null;
    if (fast)
      results = new FastHashMap(map);
    else {
      synchronized (map) {
        results = new FastHashMap(map);
      }
    }
    results.setFast(getFast());
    return results;
  }

  public Set entrySet()
  {
    return new EntrySet(null);
  }

  public Set keySet()
  {
    return new KeySet(null);
  }

  public Collection values()
  {
    return new Values(null);
  }

  private class EntrySet extends FastHashMap.CollectionView
    implements Set
  {
    private final FastHashMap this$0;

    private EntrySet()
    {
      super(); this.this$0 = this$0;
    }
    protected Collection get(Map map) {
      return map.entrySet();
    }

    protected Object iteratorNext(Map.Entry entry) {
      return entry;
    }

    EntrySet(FastHashMap.1 x1)
    {
      this();
    }
  }

  private class Values extends FastHashMap.CollectionView
  {
    private final FastHashMap this$0;

    private Values()
    {
      super(); this.this$0 = this$0;
    }
    protected Collection get(Map map) {
      return map.values();
    }

    protected Object iteratorNext(Map.Entry entry) {
      return entry.getValue();
    }

    Values(FastHashMap.1 x1)
    {
      this();
    }
  }

  private class KeySet extends FastHashMap.CollectionView
    implements Set
  {
    private final FastHashMap this$0;

    private KeySet()
    {
      super(); this.this$0 = this$0;
    }
    protected Collection get(Map map) {
      return map.keySet();
    }

    protected Object iteratorNext(Map.Entry entry) {
      return entry.getKey();
    }

    KeySet(FastHashMap.1 x1)
    {
      this();
    }
  }

  private abstract class CollectionView
    implements Collection
  {
    public CollectionView()
    {
    }

    protected abstract Collection get(Map paramMap);

    protected abstract Object iteratorNext(Map.Entry paramEntry);

    public void clear()
    {
      if (fast) {
        synchronized (FastHashMap.this) {
          map = new HashMap();
        }
      }
      synchronized (map) {
        get(map).clear();
      }
    }

    public boolean remove(Object o)
    {
      HashMap temp;
      if (fast) {
        synchronized (FastHashMap.this) {
          temp = (HashMap)map.clone();
          boolean r = get(temp).remove(o);
          map = temp;
          return r;
        }
      }
      synchronized (map) {
        return get(map).remove(o);
      }
    }

    public boolean removeAll(Collection o)
    {
      HashMap temp;
      if (fast) {
        synchronized (FastHashMap.this) {
          temp = (HashMap)map.clone();
          boolean r = get(temp).removeAll(o);
          map = temp;
          return r;
        }
      }
      synchronized (map) {
        return get(map).removeAll(o);
      }
    }

    public boolean retainAll(Collection o)
    {
      HashMap temp;
      if (fast) {
        synchronized (FastHashMap.this) {
          temp = (HashMap)map.clone();
          boolean r = get(temp).retainAll(o);
          map = temp;
          return r;
        }
      }
      synchronized (map) {
        return get(map).retainAll(o);
      }
    }

    public int size()
    {
      if (fast) {
        return get(map).size();
      }
      synchronized (map) {
        return get(map).size();
      }
    }

    public boolean isEmpty()
    {
      if (fast) {
        return get(map).isEmpty();
      }
      synchronized (map) {
        return get(map).isEmpty();
      }
    }

    public boolean contains(Object o)
    {
      if (fast) {
        return get(map).contains(o);
      }
      synchronized (map) {
        return get(map).contains(o);
      }
    }

    public boolean containsAll(Collection o)
    {
      if (fast) {
        return get(map).containsAll(o);
      }
      synchronized (map) {
        return get(map).containsAll(o);
      }
    }

    public Object[] toArray(Object[] o)
    {
      if (fast) {
        return get(map).toArray(o);
      }
      synchronized (map) {
        return get(map).toArray(o);
      }
    }

    public Object[] toArray()
    {
      if (fast) {
        return get(map).toArray();
      }
      synchronized (map) {
        return get(map).toArray();
      }
    }

    public boolean equals(Object o)
    {
      if (o == this) return true;
      if (fast) {
        return get(map).equals(o);
      }
      synchronized (map) {
        return get(map).equals(o);
      }
    }

    public int hashCode()
    {
      if (fast) {
        return get(map).hashCode();
      }
      synchronized (map) {
        return get(map).hashCode();
      }
    }

    public boolean add(Object o)
    {
      throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection c) {
      throw new UnsupportedOperationException();
    }

    public Iterator iterator() {
      return new CollectionViewIterator();
    }
    private class CollectionViewIterator implements Iterator {
      private Map expected;
      private Map.Entry lastReturned = null;
      private Iterator iterator;

      public CollectionViewIterator() { expected = map;
        iterator = expected.entrySet().iterator(); }

      public boolean hasNext()
      {
        if (expected != map) {
          throw new ConcurrentModificationException();
        }
        return iterator.hasNext();
      }

      public Object next() {
        if (expected != map) {
          throw new ConcurrentModificationException();
        }
        lastReturned = ((Map.Entry)iterator.next());
        return iteratorNext(lastReturned);
      }

      public void remove() {
        if (lastReturned == null) {
          throw new IllegalStateException();
        }
        if (fast) {
          synchronized (FastHashMap.this) {
            if (expected != map) {
              throw new ConcurrentModificationException();
            }
            remove(lastReturned.getKey());
            lastReturned = null;
            expected = map;
          }
        }
        iterator.remove();
        lastReturned = null;
      }
    }
  }
}