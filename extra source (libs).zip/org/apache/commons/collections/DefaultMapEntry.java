package org.apache.commons.collections;

import java.util.Map.Entry;

/** @deprecated */
public class DefaultMapEntry
  implements Map.Entry, KeyValue
{
  private Object key;
  private Object value;

  public DefaultMapEntry()
  {
  }

  public DefaultMapEntry(Map.Entry entry)
  {
    key = entry.getKey();
    value = entry.getValue();
  }

  public DefaultMapEntry(Object key, Object value)
  {
    this.key = key;
    this.value = value;
  }

  public Object getKey()
  {
    return key;
  }

  public void setKey(Object key)
  {
    this.key = key;
  }

  public Object getValue()
  {
    return value;
  }

  public Object setValue(Object value)
  {
    Object answer = this.value;
    this.value = value;
    return answer;
  }

  public boolean equals(Object obj)
  {
    if (obj == this) {
      return true;
    }
    if (!(obj instanceof KeyValue)) {
      return false;
    }
    Map.Entry other = (KeyValue)obj;
    if ((getKey() == null ? false : other.getKey() == null ? true : getKey().equals(other.getKey())));
    return (getValue() == null ? false : other.getValue() == null ? true : getValue().equals(other.getValue()));
  }

  public int hashCode()
  {
    return (getKey() == null ? 0 : getKey().hashCode()) ^ (getValue() == null ? 0 : getValue().hashCode());
  }

  public String toString()
  {
    return "" + getKey() + "=" + getValue();
  }
}