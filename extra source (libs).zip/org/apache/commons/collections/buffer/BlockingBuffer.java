package org.apache.commons.collections.buffer;

import java.util.Collection;
import org.apache.commons.collections.Buffer;
import org.apache.commons.collections.BufferUnderflowException;
import org.apache.commons.collections.collection.SynchronizedCollection;

public class BlockingBuffer extends SynchronizedBuffer
{
  private static final long serialVersionUID = 1719328905017860541L;

  public static Buffer decorate(Buffer buffer)
  {
    return new BlockingBuffer(buffer);
  }

  protected BlockingBuffer(Buffer buffer)
  {
    super(buffer);
  }

  public boolean add(Object o)
  {
    synchronized (lock) {
      boolean result = collection.add(o);
      notifyAll();
      return result;
    }
  }

  public boolean addAll(Collection c) {
    synchronized (lock) {
      boolean result = collection.addAll(c);
      notifyAll();
      return result;
    }
  }

  public Object get() {
    synchronized (lock) {
      while (collection.isEmpty()) {
        try {
          wait();
        } catch (InterruptedException e) {
          throw new BufferUnderflowException();
        }
      }
      return getBuffer().get();
    }
  }

  public Object remove() {
    synchronized (lock) {
      while (collection.isEmpty()) {
        try {
          wait();
        } catch (InterruptedException e) {
          throw new BufferUnderflowException();
        }
      }
      return getBuffer().remove();
    }
  }
}