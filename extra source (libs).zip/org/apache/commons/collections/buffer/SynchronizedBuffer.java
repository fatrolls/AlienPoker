package org.apache.commons.collections.buffer;

import org.apache.commons.collections.Buffer;
import org.apache.commons.collections.collection.SynchronizedCollection;

public class SynchronizedBuffer extends SynchronizedCollection
  implements Buffer
{
  private static final long serialVersionUID = -6859936183953626253L;

  public static Buffer decorate(Buffer buffer)
  {
    return new SynchronizedBuffer(buffer);
  }

  protected SynchronizedBuffer(Buffer buffer)
  {
    super(buffer);
  }

  protected SynchronizedBuffer(Buffer buffer, Object lock)
  {
    super(buffer, lock);
  }

  protected Buffer getBuffer()
  {
    return (Buffer)collection;
  }

  public Object get()
  {
    synchronized (lock) {
      return getBuffer().get();
    }
  }

  public Object remove() {
    synchronized (lock) {
      return getBuffer().remove();
    }
  }
}