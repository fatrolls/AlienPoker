package org.apache.commons.collections.buffer;

import java.util.AbstractCollection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import org.apache.commons.collections.Buffer;
import org.apache.commons.collections.BufferUnderflowException;

public class PriorityBuffer extends AbstractCollection
  implements Buffer
{
  private static final int DEFAULT_CAPACITY = 13;
  protected Object[] elements;
  protected int size;
  protected boolean ascendingOrder;
  protected Comparator comparator;

  public PriorityBuffer()
  {
    this(13, true, null);
  }

  public PriorityBuffer(Comparator comparator)
  {
    this(13, true, comparator);
  }

  public PriorityBuffer(boolean ascendingOrder)
  {
    this(13, ascendingOrder, null);
  }

  public PriorityBuffer(boolean ascendingOrder, Comparator comparator)
  {
    this(13, ascendingOrder, comparator);
  }

  public PriorityBuffer(int capacity)
  {
    this(capacity, true, null);
  }

  public PriorityBuffer(int capacity, Comparator comparator)
  {
    this(capacity, true, comparator);
  }

  public PriorityBuffer(int capacity, boolean ascendingOrder)
  {
    this(capacity, ascendingOrder, null);
  }

  public PriorityBuffer(int capacity, boolean ascendingOrder, Comparator comparator)
  {
    if (capacity <= 0) {
      throw new IllegalArgumentException("invalid capacity");
    }
    this.ascendingOrder = ascendingOrder;

    elements = new Object[capacity + 1];
    this.comparator = comparator;
  }

  public boolean isAscendingOrder()
  {
    return ascendingOrder;
  }

  public Comparator comparator()
  {
    return comparator;
  }

  public int size()
  {
    return size;
  }

  public void clear()
  {
    elements = new Object[elements.length];
    size = 0;
  }

  public boolean add(Object element)
  {
    if (isAtCapacity()) {
      grow();
    }

    if (ascendingOrder)
      percolateUpMinHeap(element);
    else {
      percolateUpMaxHeap(element);
    }
    return true;
  }

  public Object get()
  {
    if (isEmpty()) {
      throw new BufferUnderflowException();
    }
    return elements[1];
  }

  public Object remove()
  {
    Object result = get();
    elements[1] = elements[(size--)];

    elements[(size + 1)] = null;

    if (size != 0)
    {
      if (ascendingOrder)
        percolateDownMinHeap(1);
      else {
        percolateDownMaxHeap(1);
      }
    }

    return result;
  }

  protected boolean isAtCapacity()
  {
    return elements.length == size + 1;
  }

  protected void percolateDownMinHeap(int index)
  {
    Object element = elements[index];
    int hole = index;

    while (hole * 2 <= size) {
      int child = hole * 2;

      if ((child != size) && (compare(elements[(child + 1)], elements[child]) < 0)) {
        child++;
      }

      if (compare(elements[child], element) >= 0)
      {
        break;
      }
      elements[hole] = elements[child];
      hole = child;
    }

    elements[hole] = element;
  }

  protected void percolateDownMaxHeap(int index)
  {
    Object element = elements[index];
    int hole = index;

    while (hole * 2 <= size) {
      int child = hole * 2;

      if ((child != size) && (compare(elements[(child + 1)], elements[child]) > 0)) {
        child++;
      }

      if (compare(elements[child], element) <= 0)
      {
        break;
      }
      elements[hole] = elements[child];
      hole = child;
    }

    elements[hole] = element;
  }

  protected void percolateUpMinHeap(int index)
  {
    int hole = index;
    Object element = elements[hole];
    while ((hole > 1) && (compare(element, elements[(hole / 2)]) < 0))
    {
      int next = hole / 2;
      elements[hole] = elements[next];
      hole = next;
    }
    elements[hole] = element;
  }

  protected void percolateUpMinHeap(Object element)
  {
    elements[(++size)] = element;
    percolateUpMinHeap(size);
  }

  protected void percolateUpMaxHeap(int index)
  {
    int hole = index;
    Object element = elements[hole];

    while ((hole > 1) && (compare(element, elements[(hole / 2)]) > 0))
    {
      int next = hole / 2;
      elements[hole] = elements[next];
      hole = next;
    }

    elements[hole] = element;
  }

  protected void percolateUpMaxHeap(Object element)
  {
    elements[(++size)] = element;
    percolateUpMaxHeap(size);
  }

  protected int compare(Object a, Object b)
  {
    if (comparator != null) {
      return comparator.compare(a, b);
    }
    return ((Comparable)a).compareTo(b);
  }

  protected void grow()
  {
    Object[] array = new Object[elements.length * 2];
    System.arraycopy(elements, 0, array, 0, elements.length);
    elements = array;
  }

  public Iterator iterator()
  {
    return new Iterator()
    {
      private int index = 1;
      private int lastReturnedIndex = -1;

      public boolean hasNext() {
        return index <= size;
      }

      public Object next() {
        if (!hasNext()) {
          throw new NoSuchElementException();
        }
        lastReturnedIndex = index;
        index += 1;
        return elements[lastReturnedIndex];
      }

      public void remove() {
        if (lastReturnedIndex == -1) {
          throw new IllegalStateException();
        }
        elements[lastReturnedIndex] = elements[size];
        elements[size] = null;
        size -= 1;
        if ((size != 0) && (lastReturnedIndex <= size)) {
          int compareToParent = 0;
          if (lastReturnedIndex > 1) {
            compareToParent = compare(elements[lastReturnedIndex], elements[(lastReturnedIndex / 2)]);
          }

          if (ascendingOrder) {
            if ((lastReturnedIndex > 1) && (compareToParent < 0))
              percolateUpMinHeap(lastReturnedIndex);
            else {
              percolateDownMinHeap(lastReturnedIndex);
            }
          }
          else if ((lastReturnedIndex > 1) && (compareToParent > 0))
            percolateUpMaxHeap(lastReturnedIndex);
          else {
            percolateDownMaxHeap(lastReturnedIndex);
          }
        }

        index -= 1;
        lastReturnedIndex = -1;
      }
    };
  }

  public String toString()
  {
    StringBuffer sb = new StringBuffer();

    sb.append("[ ");

    for (int i = 1; i < size + 1; i++) {
      if (i != 1) {
        sb.append(", ");
      }
      sb.append(elements[i]);
    }

    sb.append(" ]");

    return sb.toString();
  }
}