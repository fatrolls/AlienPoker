package org.apache.commons.collections.buffer;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.AbstractCollection;
import java.util.Iterator;
import java.util.NoSuchElementException;
import org.apache.commons.collections.Buffer;
import org.apache.commons.collections.BufferUnderflowException;

public class UnboundedFifoBuffer extends AbstractCollection
  implements Buffer, Serializable
{
  private static final long serialVersionUID = -3482960336579541419L;
  protected transient Object[] buffer;
  protected transient int head;
  protected transient int tail;

  public UnboundedFifoBuffer()
  {
    this(32);
  }

  public UnboundedFifoBuffer(int initialSize)
  {
    if (initialSize <= 0) {
      throw new IllegalArgumentException("The size must be greater than 0");
    }
    buffer = new Object[initialSize + 1];
    head = 0;
    tail = 0;
  }

  private void writeObject(ObjectOutputStream out)
    throws IOException
  {
    out.defaultWriteObject();
    out.writeInt(size());
    for (Iterator it = iterator(); it.hasNext(); )
      out.writeObject(it.next());
  }

  private void readObject(ObjectInputStream in)
    throws IOException, ClassNotFoundException
  {
    in.defaultReadObject();
    int size = in.readInt();
    buffer = new Object[size];
    for (int i = 0; i < size; i++) {
      buffer[i] = in.readObject();
    }
    head = 0;
    tail = size;
  }

  public int size()
  {
    int size = 0;

    if (tail < head)
      size = buffer.length - head + tail;
    else {
      size = tail - head;
    }

    return size;
  }

  public boolean isEmpty()
  {
    return size() == 0;
  }

  public boolean add(Object obj)
  {
    if (obj == null) {
      throw new NullPointerException("Attempted to add null object to buffer");
    }

    if (size() + 1 >= buffer.length) {
      Object[] tmp = new Object[(buffer.length - 1) * 2 + 1];

      int j = 0;
      for (int i = head; i != tail; ) {
        tmp[j] = buffer[i];
        buffer[i] = null;

        j++;
        i++;
        if (i == buffer.length) {
          i = 0;
        }
      }

      buffer = tmp;
      head = 0;
      tail = j;
    }

    buffer[tail] = obj;
    tail += 1;
    if (tail >= buffer.length) {
      tail = 0;
    }
    return true;
  }

  public Object get()
  {
    if (isEmpty()) {
      throw new BufferUnderflowException("The buffer is already empty");
    }

    return buffer[head];
  }

  public Object remove()
  {
    if (isEmpty()) {
      throw new BufferUnderflowException("The buffer is already empty");
    }

    Object element = buffer[head];

    if (null != element) {
      buffer[head] = null;

      head += 1;
      if (head >= buffer.length) {
        head = 0;
      }
    }

    return element;
  }

  private int increment(int index)
  {
    index++;
    if (index >= buffer.length) {
      index = 0;
    }
    return index;
  }

  private int decrement(int index)
  {
    index--;
    if (index < 0) {
      index = buffer.length - 1;
    }
    return index;
  }

  public Iterator iterator()
  {
    return new Iterator()
    {
      private int index = head;
      private int lastReturnedIndex = -1;

      public boolean hasNext() {
        return index != tail;
      }

      public Object next()
      {
        if (!hasNext()) {
          throw new NoSuchElementException();
        }
        lastReturnedIndex = index;
        index = UnboundedFifoBuffer.this.increment(index);
        return buffer[lastReturnedIndex];
      }

      public void remove() {
        if (lastReturnedIndex == -1) {
          throw new IllegalStateException();
        }

        if (lastReturnedIndex == head) {
          remove();
          lastReturnedIndex = -1;
          return;
        }

        int i = lastReturnedIndex + 1;
        while (i != tail) {
          if (i >= buffer.length) {
            buffer[(i - 1)] = buffer[0];
            i = 0;
          } else {
            buffer[(i - 1)] = buffer[i];
            i++;
          }
        }

        lastReturnedIndex = -1;
        tail = UnboundedFifoBuffer.this.decrement(tail);
        buffer[tail] = null;
        index = UnboundedFifoBuffer.this.decrement(index);
      }
    };
  }
}