package org.apache.commons.collections;

public abstract interface Factory
{
  public abstract Object create();
}