package org.apache.commons.collections;

import java.io.PrintStream;
import java.io.PrintWriter;

public class FunctorException extends RuntimeException
{
  private static final boolean JDK_SUPPORTS_NESTED;
  private final Throwable rootCause;

  public FunctorException()
  {
    rootCause = null;
  }

  public FunctorException(String msg)
  {
    super(msg);
    rootCause = null;
  }

  public FunctorException(Throwable rootCause)
  {
    super(rootCause == null ? null : rootCause.getMessage());
    this.rootCause = rootCause;
  }

  public FunctorException(String msg, Throwable rootCause)
  {
    super(msg);
    this.rootCause = rootCause;
  }

  public Throwable getCause()
  {
    return rootCause;
  }

  public void printStackTrace()
  {
    printStackTrace(System.err);
  }

  public void printStackTrace(PrintStream out)
  {
    synchronized (out) {
      PrintWriter pw = new PrintWriter(out, false);
      printStackTrace(pw);

      pw.flush();
    }
  }

  public void printStackTrace(PrintWriter out)
  {
    synchronized (out) {
      super.printStackTrace(out);
      if ((rootCause != null) && (!JDK_SUPPORTS_NESTED)) {
        out.print("Caused by: ");
        rootCause.printStackTrace(out);
      }
    }
  }

  static
  {
    boolean flag = false;
    try {
      Throwable.class.getDeclaredMethod("getCause", new Class[0]);
      flag = true;
    } catch (NoSuchMethodException ex) {
      flag = false;
    }
    JDK_SUPPORTS_NESTED = flag;
  }
}