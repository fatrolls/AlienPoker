package org.apache.commons.collections;

class DoubleOrderedMap$12 extends DoubleOrderedMap.DoubleOrderedMapIterator
{
  private final DoubleOrderedMap.11 this$1;

  protected Object doGetNext()
  {
    return lastReturnedNode;
  }
}