package org.apache.commons.collections;

class DoubleOrderedMap$2 extends DoubleOrderedMap.DoubleOrderedMapIterator
{
  private final DoubleOrderedMap.1 this$1;

  protected Object doGetNext()
  {
    return lastReturnedNode;
  }
}