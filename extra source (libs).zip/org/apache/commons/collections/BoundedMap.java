package org.apache.commons.collections;

import java.util.Map;

public abstract interface BoundedMap extends Map
{
  public abstract boolean isFull();

  public abstract int maxSize();
}