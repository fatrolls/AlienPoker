package javax.mail;

public class MessageRemovedException extends MessagingException
{
  public MessageRemovedException()
  {
  }

  public MessageRemovedException(String paramString)
  {
    super(paramString);
  }
}