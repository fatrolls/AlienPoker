package javax.mail;

import java.util.Vector;
import javax.mail.event.MailEvent;

class EventQueue
  implements Runnable
{
  private QueueElement head;
  private QueueElement tail;
  private Thread qThread;

  public EventQueue()
  {
    qThread = new Thread(this, "JavaMail-EventQueue");
    qThread.setDaemon(true);
    qThread.start();
  }

  public synchronized void enqueue(MailEvent paramMailEvent, Vector paramVector)
  {
    QueueElement localQueueElement = new QueueElement(paramMailEvent, paramVector);

    if (head == null) {
      head = localQueueElement;
      tail = localQueueElement;
    } else {
      localQueueElement.next = head;
      head.prev = localQueueElement;
      head = localQueueElement;
    }
    notify();
  }

  private synchronized QueueElement dequeue()
    throws InterruptedException
  {
    while (tail == null)
      wait();
    QueueElement localQueueElement = tail;
    tail = localQueueElement.prev;
    if (tail == null)
      head = null;
    else {
      tail.next = null;
    }
    localQueueElement.prev = (localQueueElement.next = null);
    return localQueueElement;
  }

  public void run()
  {
    try
    {
      QueueElement localQueueElement;
      while ((localQueueElement = dequeue()) != null) {
        MailEvent localMailEvent = localQueueElement.event;
        Vector localVector = localQueueElement.vector;

        for (int i = 0; i < localVector.size(); i++) {
          localMailEvent.dispatch(localVector.elementAt(i));
        }
        localQueueElement = null; localMailEvent = null; localVector = null;
      }
      return;
    }
    catch (InterruptedException localInterruptedException)
    {
    }
  }

  void stop()
  {
    if (qThread != null) {
      qThread.interrupt();
      qThread = null;
    }
  }

  class QueueElement
  {
    QueueElement next;
    QueueElement prev;
    MailEvent event;
    Vector vector;

    QueueElement(MailEvent paramVector, Vector arg3)
    {
      event = paramVector;
      Object localObject;
      vector = localObject;
    }
  }
}