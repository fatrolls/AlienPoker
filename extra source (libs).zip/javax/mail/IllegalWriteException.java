package javax.mail;

public class IllegalWriteException extends MessagingException
{
  public IllegalWriteException()
  {
  }

  public IllegalWriteException(String paramString)
  {
    super(paramString);
  }
}