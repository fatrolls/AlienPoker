package javax.mail.search;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Part;

public final class BodyTerm extends StringTerm
{
  public BodyTerm(String paramString)
  {
    super(paramString);
  }

  public boolean match(Message paramMessage)
  {
    return matchPart(paramMessage);
  }

  private boolean matchPart(Part paramPart)
  {
    try
    {
      Object localObject;
      if (paramPart.isMimeType("text/*")) {
        localObject = (String)paramPart.getContent();
        if (localObject == null) {
          return false;
        }

        return super.match((String)localObject);
      }if (paramPart.isMimeType("multipart/*")) {
        localObject = (Multipart)paramPart.getContent();
        int i = ((Multipart)localObject).getCount();
        for (int j = 0; j < i; j++)
          if (matchPart(((Multipart)localObject).getBodyPart(j)))
            return true;
      } else if (paramPart.isMimeType("message/rfc822")) {
        return matchPart((Part)paramPart.getContent());
      }
    } catch (Exception localException) {
    }
    return false;
  }

  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof BodyTerm))
      return false;
    return super.equals(paramObject);
  }
}