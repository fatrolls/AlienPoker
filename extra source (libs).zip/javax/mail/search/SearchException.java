package javax.mail.search;

import javax.mail.MessagingException;

public class SearchException extends MessagingException
{
  public SearchException()
  {
  }

  public SearchException(String paramString)
  {
    super(paramString);
  }
}