package javax.mail;

public class NoSuchProviderException extends MessagingException
{
  public NoSuchProviderException()
  {
  }

  public NoSuchProviderException(String paramString)
  {
    super(paramString);
  }
}