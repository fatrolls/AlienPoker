package javax.mail.internet;

import java.util.Enumeration;
import java.util.NoSuchElementException;
import java.util.Vector;
import javax.mail.Header;

class matchEnum
  implements Enumeration
{
  private Enumeration e;
  private String[] names;
  private boolean match;
  private boolean want_line;
  private hdr next_header;

  matchEnum(Vector paramVector, String[] paramArrayOfString, boolean paramBoolean1, boolean paramBoolean2)
  {
    e = paramVector.elements();
    names = paramArrayOfString;
    match = paramBoolean1;
    want_line = paramBoolean2;
    next_header = null;
  }

  public boolean hasMoreElements()
  {
    if (next_header == null)
      next_header = nextMatch();
    return next_header != null;
  }

  public Object nextElement()
  {
    if (next_header == null) {
      next_header = nextMatch();
    }
    if (next_header == null) {
      throw new NoSuchElementException("No more headers");
    }
    hdr localhdr = next_header;
    next_header = null;
    if (want_line) {
      return localhdr.line;
    }
    return new Header(localhdr.getName(), 
      localhdr.getValue());
  }

  private hdr nextMatch()
  {
    while (e.hasMoreElements()) {
      hdr localhdr = (hdr)e.nextElement();

      if (localhdr.line == null)
      {
        continue;
      }
      if (names == null) {
        if (match) return null; return localhdr;
      }

      int i = 0;
      while (true) if (names[i].equalsIgnoreCase(localhdr.name)) {
          if (!match) break;
          return localhdr;
        }
        else
        {
          i++; if (i < names.length)
          {
            continue;
          }

          if (match) break;
          return localhdr;
        } 
    }
    return null;
  }
}