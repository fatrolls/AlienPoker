package javax.mail;

public class AuthenticationFailedException extends MessagingException
{
  public AuthenticationFailedException()
  {
  }

  public AuthenticationFailedException(String paramString)
  {
    super(paramString);
  }
}