package javax.mail;

import com.sun.mail.util.LineInputStream;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.net.InetAddress;
import java.net.URL;
import java.util.Hashtable;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public final class Session
{
  private final Properties props;
  private final Authenticator authenticator;
  private final Hashtable authTable = new Hashtable();
  private boolean debug = false;
  private PrintStream out;
  private final Vector providers = new Vector();
  private final Hashtable providersByProtocol = new Hashtable();
  private final Hashtable providersByClassName = new Hashtable();
  private final Properties addressMap = new Properties();

  private static Session defaultSession = null;
  private static final String version = "1.3.1";

  private Session(Properties paramProperties, Authenticator paramAuthenticator)
  {
    props = paramProperties;
    authenticator = paramAuthenticator;

    if (Boolean.valueOf(paramProperties.getProperty("mail.debug")).booleanValue()) {
      debug = true;
    }
    if (debug)
      pr("DEBUG: JavaMail version 1.3.1");
    Class localClass;
    if (paramAuthenticator != null)
      localClass = paramAuthenticator.getClass();
    else {
      localClass = getClass();
    }
    loadProviders(localClass);
    loadAddressMap(localClass);
  }

  public static Session getInstance(Properties paramProperties, Authenticator paramAuthenticator)
  {
    return new Session(paramProperties, paramAuthenticator);
  }

  public static Session getInstance(Properties paramProperties)
  {
    return new Session(paramProperties, null);
  }

  public static synchronized Session getDefaultInstance(Properties paramProperties, Authenticator paramAuthenticator)
  {
    if (defaultSession == null) {
      defaultSession = new Session(paramProperties, paramAuthenticator);
    }
    else if (defaultSession.authenticator != paramAuthenticator)
    {
      if ((defaultSession.authenticator == null) || 
        (paramAuthenticator == null) || 
        (defaultSession.authenticator.getClass().getClassLoader() != 
        paramAuthenticator.getClass().getClassLoader()))
      {
        throw new SecurityException("Access to default session denied");
      }
    }
    return defaultSession;
  }

  public static Session getDefaultInstance(Properties paramProperties)
  {
    return getDefaultInstance(paramProperties, null);
  }

  public synchronized void setDebug(boolean paramBoolean)
  {
    debug = paramBoolean;
    if (paramBoolean)
      pr("DEBUG: setDebug: JavaMail version 1.3.1");
  }

  public synchronized boolean getDebug()
  {
    return debug;
  }

  public synchronized void setDebugOut(PrintStream paramPrintStream)
  {
    out = paramPrintStream;
  }

  public synchronized PrintStream getDebugOut()
  {
    if (out == null) {
      return System.out;
    }
    return out;
  }

  public synchronized Provider[] getProviders()
  {
    Provider[] arrayOfProvider = new Provider[providers.size()];
    providers.copyInto(arrayOfProvider);
    return arrayOfProvider;
  }

  public synchronized Provider getProvider(String paramString)
    throws NoSuchProviderException
  {
    if ((paramString == null) || (paramString.length() <= 0)) {
      throw new NoSuchProviderException("Invalid protocol: null");
    }

    Provider localProvider = null;

    String str = props.getProperty("mail." + paramString + ".class");
    if (str != null) {
      if (debug) {
        pr("DEBUG: mail." + paramString + 
          ".class property exists and points to " + 
          str);
      }
      localProvider = (Provider)providersByClassName.get(str);
    }

    if (localProvider != null) {
      return localProvider;
    }

    localProvider = (Provider)providersByProtocol.get(paramString);

    if (localProvider == null) {
      throw new NoSuchProviderException("No provider for " + paramString);
    }
    if (debug) {
      pr("DEBUG: getProvider() returning " + 
        localProvider.toString());
    }
    return localProvider;
  }

  public synchronized void setProvider(Provider paramProvider)
    throws NoSuchProviderException
  {
    if (paramProvider == null) {
      throw new NoSuchProviderException("Can't set null provider");
    }
    providersByProtocol.put(paramProvider.getProtocol(), paramProvider);
    props.put("mail." + paramProvider.getProtocol() + ".class", 
      paramProvider.getClassName());
  }

  public Store getStore()
    throws NoSuchProviderException
  {
    return getStore(getProperty("mail.store.protocol"));
  }

  public Store getStore(String paramString)
    throws NoSuchProviderException
  {
    return getStore(new URLName(paramString, null, -1, null, null, null));
  }

  public Store getStore(URLName paramURLName)
    throws NoSuchProviderException
  {
    String str = paramURLName.getProtocol();
    Provider localProvider = getProvider(str);
    return getStore(localProvider, paramURLName);
  }

  public Store getStore(Provider paramProvider)
    throws NoSuchProviderException
  {
    return getStore(paramProvider, null);
  }

  private Store getStore(Provider paramProvider, URLName paramURLName)
    throws NoSuchProviderException
  {
    if ((paramProvider == null) || (paramProvider.getType() != Provider.Type.STORE)) {
      throw new NoSuchProviderException("invalid provider");
    }
    try
    {
      return (Store)getService(paramProvider, paramURLName); } catch (ClassCastException localClassCastException) {
    }
    throw new NoSuchProviderException("incorrect class");
  }

  public Folder getFolder(URLName paramURLName)
    throws MessagingException
  {
    Store localStore = getStore(paramURLName);
    localStore.connect();
    return localStore.getFolder(paramURLName);
  }

  public Transport getTransport()
    throws NoSuchProviderException
  {
    return getTransport(getProperty("mail.transport.protocol"));
  }

  public Transport getTransport(String paramString)
    throws NoSuchProviderException
  {
    return getTransport(new URLName(paramString, null, -1, null, null, null));
  }

  public Transport getTransport(URLName paramURLName)
    throws NoSuchProviderException
  {
    String str = paramURLName.getProtocol();
    Provider localProvider = getProvider(str);
    return getTransport(localProvider, paramURLName);
  }

  public Transport getTransport(Provider paramProvider)
    throws NoSuchProviderException
  {
    return getTransport(paramProvider, null);
  }

  public Transport getTransport(Address paramAddress)
    throws NoSuchProviderException
  {
    String str = (String)addressMap.get(paramAddress.getType());
    if (str == null) {
      throw new NoSuchProviderException("No provider for Address type: " + 
        paramAddress.getType());
    }
    return getTransport(str);
  }

  private Transport getTransport(Provider paramProvider, URLName paramURLName)
    throws NoSuchProviderException
  {
    if ((paramProvider == null) || (paramProvider.getType() != Provider.Type.TRANSPORT)) {
      throw new NoSuchProviderException("invalid provider");
    }
    try
    {
      return (Transport)getService(paramProvider, paramURLName); } catch (ClassCastException localClassCastException) {
    }
    throw new NoSuchProviderException("incorrect class");
  }

  private Object getService(Provider paramProvider, URLName paramURLName)
    throws NoSuchProviderException
  {
    if (paramProvider == null) {
      throw new NoSuchProviderException("null");
    }

    if (paramURLName == null) {
      paramURLName = new URLName(paramProvider.getProtocol(), null, -1, 
        null, null, null);
    }

    Object localObject = null;
    ClassLoader localClassLoader1;
    if (authenticator != null)
      localClassLoader1 = authenticator.getClass().getClassLoader();
    else {
      localClassLoader1 = getClass().getClassLoader();
    }

    Class localClass = null;
    try
    {
      ClassLoader localClassLoader2 = 
        SecuritySupport.getInstance().getContextClassLoader();
      if (localClassLoader2 != null)
        try {
          localClass = localClassLoader2.loadClass(paramProvider.getClassName()); } catch (ClassNotFoundException localClassNotFoundException) {
        }
      if (localClass == null)
        localClass = localClassLoader1.loadClass(paramProvider.getClassName());
    }
    catch (Exception localException3)
    {
      try
      {
        localClass = Class.forName(paramProvider.getClassName());
      }
      catch (Exception localException1) {
        if (debug) localException1.printStackTrace(getDebugOut());
        throw new NoSuchProviderException(paramProvider.getProtocol());
      }
    }

    try
    {
      Class[] arrayOfClass = { Session.class, URLName.class };
      Constructor localConstructor = localClass.getConstructor(arrayOfClass);

      Object[] arrayOfObject = { this, paramURLName };
      localObject = localConstructor.newInstance(arrayOfObject);
    }
    catch (Exception localException2) {
      if (debug) localException2.printStackTrace(getDebugOut());
      throw new NoSuchProviderException(paramProvider.getProtocol());
    }

    return localObject;
  }

  public void setPasswordAuthentication(URLName paramURLName, PasswordAuthentication paramPasswordAuthentication)
  {
    if (paramPasswordAuthentication == null) {
      authTable.remove(paramURLName);

      return;
    }

    authTable.put(paramURLName, paramPasswordAuthentication);
  }

  public PasswordAuthentication getPasswordAuthentication(URLName paramURLName)
  {
    return (PasswordAuthentication)authTable.get(paramURLName);
  }

  public PasswordAuthentication requestPasswordAuthentication(InetAddress paramInetAddress, int paramInt, String paramString1, String paramString2, String paramString3)
  {
    if (authenticator != null) {
      return authenticator.requestPasswordAuthentication(
        paramInetAddress, paramInt, paramString1, paramString2, paramString3);
    }
    return null;
  }

  public Properties getProperties()
  {
    return props;
  }

  public String getProperty(String paramString)
  {
    return props.getProperty(paramString);
  }

  private void loadProviders(Class paramClass)
  {
    1 local1 = new StreamLoader() {
      public void load(InputStream paramInputStream) throws IOException {
        Session.this.loadProvidersFromStream(paramInputStream);
      }
    };
    try
    {
      String str = System.getProperty("java.home") + 
        File.separator + "lib" + 
        File.separator + "javamail.providers";
      loadFile(str, local1);
    } catch (SecurityException localSecurityException) {
      if (debug) {
        pr("DEBUG: can't get java.home: " + localSecurityException);
      }
    }

    loadAllResources("META-INF/javamail.providers", paramClass, local1);

    loadResource("/META-INF/javamail.default.providers", paramClass, local1);

    if (providers.size() == 0) {
      if (debug) {
        pr("DEBUG: failed to load any providers, using defaults");
      }
      addProvider(new Provider(Provider.Type.STORE, 
        "imap", "com.sun.mail.imap.IMAPStore", 
        "Sun Microsystems, Inc.", "1.3.1"));
      addProvider(new Provider(Provider.Type.STORE, 
        "pop3", "com.sun.mail.pop3.POP3Store", 
        "Sun Microsystems, Inc.", "1.3.1"));
      addProvider(new Provider(Provider.Type.TRANSPORT, 
        "smtp", "com.sun.mail.smtp.SMTPTransport", 
        "Sun Microsystems, Inc.", "1.3.1"));
    }

    if (debug)
    {
      pr("DEBUG: Tables of loaded providers");
      pr("DEBUG: Providers Listed By Class Name: " + 
        providersByClassName.toString());
      pr("DEBUG: Providers Listed By Protocol: " + 
        providersByProtocol.toString());
    }
  }

  private void loadProvidersFromStream(InputStream paramInputStream) throws IOException
  {
    if (paramInputStream != null) {
      LineInputStream localLineInputStream = new LineInputStream(paramInputStream);
      String str1;
      while ((str1 = localLineInputStream.readLine()) != null)
      {
        if (str1.startsWith("#"))
          continue;
        Provider.Type localType = null;
        String str2 = null; String str3 = null;
        String str4 = null; String str5 = null;

        StringTokenizer localStringTokenizer = new StringTokenizer(str1, ";");
        Object localObject;
        while (localStringTokenizer.hasMoreTokens()) {
          localObject = localStringTokenizer.nextToken().trim();

          int i = ((String)localObject).indexOf("=");
          if (((String)localObject).startsWith("protocol=")) {
            str2 = ((String)localObject).substring(i + 1);
          } else if (((String)localObject).startsWith("type=")) {
            String str6 = ((String)localObject).substring(i + 1);
            if (str6.equalsIgnoreCase("store"))
              localType = Provider.Type.STORE;
            else if (str6.equalsIgnoreCase("transport"))
              localType = Provider.Type.TRANSPORT;
          }
          else if (((String)localObject).startsWith("class=")) {
            str3 = ((String)localObject).substring(i + 1);
          } else if (((String)localObject).startsWith("vendor=")) {
            str4 = ((String)localObject).substring(i + 1);
          } else if (((String)localObject).startsWith("version=")) {
            str5 = ((String)localObject).substring(i + 1);
          }

        }

        if ((localType == null) || (str2 == null) || (str3 == null) || 
          (str2.length() <= 0) || (str3.length() <= 0))
        {
          if (debug)
            pr("DEBUG: Bad provider entry: " + str1);
        }
        else {
          localObject = new Provider(localType, str2, str3, 
            str4, str5);

          addProvider((Provider)localObject);
        }
      }
    }
  }

  private void addProvider(Provider paramProvider)
  {
    providers.addElement(paramProvider);
    providersByClassName.put(paramProvider.getClassName(), paramProvider);
    if (!providersByProtocol.containsKey(paramProvider.getProtocol()))
      providersByProtocol.put(paramProvider.getProtocol(), paramProvider);
  }

  private void loadAddressMap(Class paramClass)
  {
    2 local2 = new StreamLoader() {
      public void load(InputStream paramInputStream) throws IOException {
        addressMap.load(paramInputStream);
      }
    };
    loadResource("/META-INF/javamail.default.address.map", paramClass, local2);

    loadAllResources("META-INF/javamail.address.map", paramClass, local2);
    try
    {
      String str = System.getProperty("java.home") + 
        File.separator + "lib" + 
        File.separator + "javamail.address.map";
      loadFile(str, local2);
    } catch (SecurityException localSecurityException) {
      if (debug) {
        pr("DEBUG: can't get java.home: " + localSecurityException);
      }
    }
    if (addressMap.isEmpty()) {
      if (debug)
        pr("DEBUG: failed to load address map, using defaults");
      addressMap.put("rfc822", "smtp");
    }
  }

  private void loadFile(String paramString, StreamLoader paramStreamLoader)
  {
    BufferedInputStream localBufferedInputStream = null;
    try {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString));
      if (localBufferedInputStream != null) {
        paramStreamLoader.load(localBufferedInputStream);
        if (debug)
          pr("DEBUG: successfully loaded file: " + paramString);
      }
      else if (debug) {
        pr("DEBUG: not loading file: " + paramString);
      }
    } catch (IOException localIOException1) {
      if (debug)
        pr("DEBUG: " + localIOException1);
    } catch (SecurityException localSecurityException) {
      if (debug)
        pr("DEBUG: " + localSecurityException);
      return;
    }
    finally
    {
      try
      {
        if (localBufferedInputStream != null)
          localBufferedInputStream.close();
      }
      catch (IOException localIOException2)
      {
      }
    }
  }

  private void loadResource(String paramString, Class paramClass, StreamLoader paramStreamLoader) {
    InputStream localInputStream = null;
    try {
      localInputStream = SecuritySupport.getInstance().getResourceAsStream(paramClass, paramString);
      if (localInputStream != null) {
        paramStreamLoader.load(localInputStream);
        if (debug)
          pr("DEBUG: successfully loaded resource: " + paramString);
      }
      else if (debug) {
        pr("DEBUG: not loading resource: " + paramString);
      }
    } catch (IOException localIOException1) {
      if (debug)
        pr("DEBUG: " + localIOException1);
    } catch (SecurityException localSecurityException) {
      if (debug)
        pr("DEBUG: " + localSecurityException);
      return;
    }
    finally
    {
      try
      {
        if (localInputStream != null)
          localInputStream.close();
      }
      catch (IOException localIOException2)
      {
      }
    }
  }

  private void loadAllResources(String paramString, Class paramClass, StreamLoader paramStreamLoader) {
    int i = 0;
    try
    {
      ClassLoader localClassLoader = null;

      localClassLoader = SecuritySupport.getInstance().getContextClassLoader();
      if (localClassLoader == null)
        localClassLoader = paramClass.getClassLoader();
      URL[] arrayOfURL;
      if (localClassLoader != null)
        arrayOfURL = SecuritySupport.getInstance().getResources(localClassLoader, paramString);
      else
        arrayOfURL = SecuritySupport.getInstance().getSystemResources(paramString);
      if (arrayOfURL != null)
        for (int j = 0; j < arrayOfURL.length; j++) {
          URL localURL = arrayOfURL[j];
          InputStream localInputStream = null;
          if (debug)
            pr("DEBUG: URL " + localURL);
          try {
            localInputStream = SecuritySupport.getInstance().openStream(localURL);
            if (localInputStream != null) {
              paramStreamLoader.load(localInputStream);
              i = 1;
              if (debug)
                pr("DEBUG: successfully loaded resource: " + 
                  localURL);
            }
            else if (debug) {
              pr("DEBUG: not loading resource: " + localURL);
            }
          } catch (IOException localIOException1) {
            if (debug)
              pr("DEBUG: " + localIOException1);
          } catch (SecurityException localSecurityException) {
            if (debug)
              pr("DEBUG: " + localSecurityException);
          } finally {
            try {
              if (localInputStream != null)
                localInputStream.close();
            } catch (IOException localIOException2) {
            }
          }
        }
    } catch (Exception localException) {
      if (debug) {
        pr("DEBUG: " + localException);
      }
    }

    if (i == 0) {
      if (debug)
        pr("DEBUG: !anyLoaded");
      loadResource("/" + paramString, paramClass, paramStreamLoader);
    }
  }

  private void pr(String paramString) {
    getDebugOut().println(paramString);
  }
}